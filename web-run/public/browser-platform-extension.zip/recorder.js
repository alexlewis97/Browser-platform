// src/recorder.ts
(() => {
  if (window.__bpPageRecorder) return;
  const escape = window.CSS && CSS.escape ? CSS.escape : (s) => String(s).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
  function cssPath(node) {
    if (!node || node.nodeType !== 1) return "";
    if (node.id) return `#${escape(node.id)}`;
    const parts = [];
    let cur = node;
    while (cur && cur.nodeType === 1 && cur !== document.documentElement && parts.length < 6) {
      if (cur.id) {
        parts.unshift(`#${escape(cur.id)}`);
        break;
      }
      let part = cur.tagName.toLowerCase();
      const parent = cur.parentElement;
      if (parent) {
        const same = Array.from(parent.children).filter((c) => c.tagName === cur.tagName);
        if (same.length > 1) part += `:nth-of-type(${same.indexOf(cur) + 1})`;
      }
      parts.unshift(part);
      cur = parent;
    }
    return parts.join(" > ");
  }
  function xpath(node) {
    if (!node || node.nodeType !== 1) return "";
    if (node.id) return `//*[@id="${node.id}"]`;
    const parts = [];
    let cur = node;
    while (cur && cur.nodeType === 1 && cur !== document.documentElement) {
      let ix = 1;
      let sib = cur.previousElementSibling;
      while (sib) {
        if (sib.tagName === cur.tagName) ix += 1;
        sib = sib.previousElementSibling;
      }
      parts.unshift(`${cur.tagName.toLowerCase()}[${ix}]`);
      cur = cur.parentElement;
    }
    return "//" + parts.join("/");
  }
  function isSecretField(el) {
    if (!el || el.nodeType !== 1) return false;
    const input = el;
    const type = String(input.type || "").toLowerCase();
    if (type === "password") return true;
    const autocomplete = String(input.autocomplete || input.getAttribute("autocomplete") || "").toLowerCase();
    if (/(password|one-time-code|cc-|card|cvv|ssn|secret)/i.test(autocomplete)) return true;
    const name = String(input.name || input.id || input.getAttribute("aria-label") || "").toLowerCase();
    return /(password|passwd|secret|api[_-]?key|token|cvv|ssn)/i.test(name);
  }
  function describe(el) {
    if (!el || el.nodeType !== 1) return null;
    const html = el;
    const text = (html.innerText || el.textContent || "").replace(/\s+/g, " ").trim().slice(0, 160);
    const tag = el.tagName.toLowerCase();
    const role = el.getAttribute("role") || { a: "link", button: "button", input: "textbox", select: "combobox", textarea: "textbox" }[tag] || tag;
    const name = el.getAttribute("aria-label") || el.getAttribute("name") || el.getAttribute("placeholder") || text;
    const secret = isSecretField(el);
    const value = secret ? null : "value" in html ? String(html.value ?? "") : null;
    return {
      tag,
      id: html.id || null,
      role,
      name: (name || "").slice(0, 160),
      text,
      value,
      placeholder: el.getAttribute("placeholder"),
      ariaLabel: el.getAttribute("aria-label"),
      type: el.getAttribute("type"),
      href: el.getAttribute("href"),
      css: cssPath(el),
      xpath: xpath(el)
    };
  }
  const events = [];
  const lastValues = /* @__PURE__ */ new Map();
  let pending = 0;
  function emit(rec) {
    events.push(rec);
    try {
      chrome.runtime.sendMessage({ kind: "bp-record-event", event: rec }).catch(() => void 0);
    } catch {
    }
  }
  function fieldKey(el) {
    if (!el) return "";
    if (el.id) return "#" + el.id;
    return cssPath(el) || xpath(el) || "";
  }
  function skipField(el) {
    const typ = (el && el.getAttribute && el.getAttribute("type") || "").toLowerCase();
    return ["hidden", "submit", "button", "image", "file", "reset", "checkbox", "radio"].includes(typ);
  }
  function fieldValue(el) {
    const tag = (el.tagName || "").toLowerCase();
    const typ = (el.getAttribute("type") || "").toLowerCase();
    const input = el;
    if (typ === "checkbox" || typ === "radio") return input.checked ? input.value || "on" : "";
    if (tag === "select") {
      const sel = el;
      const opt = sel.options && sel.selectedIndex >= 0 ? sel.options[sel.selectedIndex] : null;
      return opt ? opt.text || sel.value : sel.value || "";
    }
    return input.value != null ? String(input.value) : "";
  }
  function noteField(el, reason) {
    if (!el || el.nodeType !== 1 || skipField(el)) return;
    const tag = (el.tagName || "").toLowerCase();
    if (!["input", "textarea", "select"].includes(tag)) return;
    const key = fieldKey(el);
    if (!key) return;
    const value = fieldValue(el);
    if (lastValues.get(key) === value) return;
    const had = lastValues.has(key);
    lastValues.set(key, value);
    if (!had && value === "") return;
    const type = tag === "select" ? "select_change" : "input";
    emit({ type, ts: Date.now(), url: location.href, value, text: describe(el)?.text, element: describe(el), changed: true });
    void reason;
  }
  function snapshotFields() {
    document.querySelectorAll("input, textarea, select").forEach((el) => noteField(el, "snapshot"));
  }
  function fingerprint() {
    return `${location.href}|${document.title}|${(document.body?.innerText || "").length}`;
  }
  document.addEventListener(
    "click",
    (e) => {
      const el = e.target;
      if (!el) return;
      snapshotFields();
      const before = fingerprint();
      const beforeUrl = location.href;
      const rec = { type: "click", ts: Date.now(), url: beforeUrl, text: describe(el)?.text, element: describe(el) };
      pending += 1;
      window.setTimeout(() => {
        rec.url_after = location.href;
        rec.changed = fingerprint() !== before;
        emit(rec);
        pending -= 1;
      }, 350);
    },
    true
  );
  document.addEventListener(
    "input",
    (e) => {
      const el = e.target;
      if (!el) return;
      const tag = (el.tagName || "").toLowerCase();
      if (tag === "select") return;
      lastValues.set(fieldKey(el), fieldValue(el));
      emit({
        type: "input",
        ts: Date.now(),
        url: location.href,
        value: el.value,
        text: describe(el)?.text,
        element: describe(el),
        changed: true
      });
    },
    true
  );
  document.addEventListener(
    "change",
    (e) => {
      const el = e.target;
      if (!el) return;
      const tag = (el.tagName || "").toLowerCase();
      lastValues.set(fieldKey(el), fieldValue(el));
      if (tag === "select") {
        const sel = el;
        const opt = sel.options[sel.selectedIndex];
        emit({
          type: "select_change",
          ts: Date.now(),
          url: location.href,
          value: opt ? opt.text : sel.value,
          text: opt ? opt.text : sel.value,
          element: describe(el),
          changed: true
        });
      } else {
        emit({
          type: "input",
          ts: Date.now(),
          url: location.href,
          value: el.value,
          text: describe(el)?.text,
          element: describe(el),
          changed: true
        });
      }
    },
    true
  );
  document.addEventListener(
    "keydown",
    (e) => {
      if (e.key === "Enter" || e.key === "Escape") {
        snapshotFields();
        emit({ type: "key_press", ts: Date.now(), url: location.href, key: e.key, element: describe(e.target), changed: true });
      }
    },
    true
  );
  window.__bpPageRecorder = {
    drain() {
      snapshotFields();
      const out = events.slice();
      events.length = 0;
      return out;
    },
    snapshot() {
      snapshotFields();
      return events.slice();
    }
  };
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message) return;
    if (message.kind === "bp-record-ping") {
      sendResponse({ ok: true });
      return true;
    }
    if (message.kind !== "bp-record-drain") return;
    const wait = pending > 0 ? 400 : 0;
    window.setTimeout(() => {
      snapshotFields();
      const out = events.map((ev) => {
        if (ev.element && isSecretField(document.querySelector(String(ev.element.css || "")))) {
          return { ...ev, value: null };
        }
        if (ev.value != null && /(password|passwd|secret)/i.test(String(ev.element?.name || ""))) {
          return { ...ev, value: null };
        }
        return ev;
      }).slice();
      events.length = 0;
      sendResponse({ ok: true, events: out });
    }, wait);
    return true;
  });
})();
