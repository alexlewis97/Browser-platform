// src/confirm.ts
function escapeHtml(value) {
  return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
var params = new URLSearchParams(location.search);
var requestId = params.get("id") || "";
var nameEl = document.getElementById("name");
var descriptionEl = document.getElementById("description");
var valuesEl = document.getElementById("values");
var errorEl = document.getElementById("error");
var confirmBtn = document.getElementById("confirm");
var cancelBtn = document.getElementById("cancel");
function showError(message) {
  errorEl.hidden = false;
  errorEl.textContent = message;
}
async function decide(accepted) {
  confirmBtn.disabled = true;
  cancelBtn.disabled = true;
  const result = await chrome.runtime.sendMessage({
    kind: "bp-confirm-decision",
    id: requestId,
    accepted
  });
  if (result && result.ok === false && result.error) {
    showError(result.error);
    confirmBtn.disabled = false;
    cancelBtn.disabled = false;
    return;
  }
  window.close();
}
confirmBtn.addEventListener("click", () => void decide(true));
cancelBtn.addEventListener("click", () => void decide(false));
void (async () => {
  if (!requestId) {
    showError("\u05D1\u05E7\u05E9\u05EA \u05D4\u05D0\u05D9\u05E9\u05D5\u05E8 \u05D7\u05E1\u05E8\u05D4.");
    confirmBtn.disabled = true;
    return;
  }
  const details = await chrome.runtime.sendMessage({
    kind: "bp-confirm-details",
    id: requestId
  });
  if (!details?.ok) {
    showError(details?.error || "\u05DC\u05D0 \u05E0\u05DE\u05E6\u05D0\u05D4 \u05D1\u05E7\u05E9\u05EA \u05D4\u05E8\u05E6\u05D4.");
    confirmBtn.disabled = true;
    return;
  }
  nameEl.textContent = details.name || "\u05D6\u05E8\u05D9\u05DE\u05D4";
  descriptionEl.textContent = details.description || "\u05D0\u05D9\u05DF \u05EA\u05D9\u05D0\u05D5\u05E8";
  const values = details.values || {};
  const entries = Object.entries(values);
  valuesEl.innerHTML = entries.length ? entries.map(
    ([key, value]) => `<div class="value"><span>${escapeHtml(key)}</span><b>${escapeHtml(value)}</b></div>`
  ).join("") : `<p class="muted" style="margin:0">\u05D0\u05D9\u05DF \u05E7\u05DC\u05D8\u05D9\u05DD \u05DC\u05D4\u05E8\u05E6\u05D4 \u05D4\u05D6\u05D5.</p>`;
})();
