// src/lib/locators.ts
var ROLE_ALIASES = {
  a: "link",
  link: "link",
  button: "button",
  btn: "button",
  heading: "heading",
  h1: "heading",
  h2: "heading",
  textbox: "textbox",
  input: "textbox",
  searchbox: "searchbox",
  checkbox: "checkbox",
  radio: "radio",
  combobox: "combobox",
  listbox: "listbox",
  option: "option",
  tab: "tab",
  menuitem: "menuitem"
};
function cssEscape(value) {
  if (typeof CSS !== "undefined" && CSS.escape) return CSS.escape(value);
  return String(value).replace(/[^a-zA-Z0-9_\-]/g, "\\$&");
}
function visible(el) {
  const html = el;
  if (!html.getBoundingClientRect) return true;
  const rect = html.getBoundingClientRect();
  const style = window.getComputedStyle(html);
  if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") return false;
  return rect.width > 0 || rect.height > 0 || html.getClientRects().length > 0;
}
function firstVisible(nodes) {
  const list = nodes.filter((n) => n.nodeType === 1);
  return list.find((n) => visible(n)) || list[0] || null;
}
function allBySelector(sel) {
  try {
    return Array.from(document.querySelectorAll(sel));
  } catch {
    return [];
  }
}
function allByXpath(expr) {
  const value = expr.startsWith("xpath=") ? expr.slice(6) : expr;
  const out = [];
  try {
    const snap = document.evaluate(value, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    for (let i = 0; i < snap.snapshotLength; i++) {
      const n = snap.snapshotItem(i);
      if (n instanceof Element) out.push(n);
    }
  } catch {
  }
  return out;
}
function textOf(el) {
  return (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
}
function allByText(value, exact) {
  const needle = exact ? value.trim() : value.trim().toLowerCase();
  if (!needle) return [];
  const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_ELEMENT);
  const hits = [];
  let node = walker.currentNode;
  while (node) {
    const el = node;
    const t = textOf(el);
    const ok = exact ? t === needle : t.toLowerCase().includes(needle.toLowerCase());
    if (ok) hits.push(el);
    node = walker.nextNode();
  }
  return hits.sort((a, b) => a.contains(b) ? 1 : b.contains(a) ? -1 : 0);
}
function accessibleName(el) {
  const lab = el.getAttribute("aria-label") || el.placeholder || el.getAttribute("title") || "";
  if (lab.trim()) return lab.trim();
  const id = el.getAttribute("id");
  if (id) {
    const via = document.querySelector(`label[for="${cssEscape(id)}"]`);
    if (via) return textOf(via);
  }
  const wrapped = el.closest("label");
  if (wrapped) return textOf(wrapped);
  return textOf(el);
}
function allByRole(role, name) {
  const mapped = ROLE_ALIASES[role] || role;
  const implicit = {
    link: "a[href]",
    button: "button, [type=submit], [type=button], input[type=submit]",
    heading: "h1,h2,h3,h4,h5,h6,[role=heading]",
    textbox: "input:not([type=hidden]):not([type=submit]):not([type=button]):not([type=checkbox]):not([type=radio]), textarea, [role=textbox]",
    searchbox: "input[type=search], [role=searchbox]",
    checkbox: "input[type=checkbox], [role=checkbox]",
    radio: "input[type=radio], [role=radio]",
    combobox: "select, [role=combobox]",
    option: "option, [role=option]"
  };
  const sel = `[role="${cssEscape(mapped)}"]` + (implicit[mapped] ? `, ${implicit[mapped]}` : "");
  const want = name.trim().toLowerCase();
  return allBySelector(sel).filter((el) => {
    const n = accessibleName(el).toLowerCase();
    return !want || n === want || n.includes(want);
  });
}
function elementsFor(strategy) {
  const typ = (strategy.type || "").toLowerCase();
  const value = strategy.value || "";
  const meta = strategy.metadata || {};
  let role = String(meta.role || meta.tag || "").toLowerCase();
  role = ROLE_ALIASES[role] || role;
  if (typ === "cached") {
    const inner = String(meta.original_type || "css");
    return elementsFor({ type: inner, value, metadata: meta, priority: 1 });
  }
  if (typ === "id" || typ === "css_id") {
    const sel = value.startsWith("#") ? value : `#${value.replace(/^#/, "")}`;
    return allBySelector(sel);
  }
  if (["css", "cssselector", "css_selector", "css_attr", "css_class"].includes(typ)) {
    return allBySelector(value);
  }
  if (typ === "xpath") return allByXpath(value);
  if (typ === "text_exact" || typ === "text") return allByText(value, true);
  if (typ === "text_fuzzy") return allByText(value, false);
  if (typ === "role_text" || typ === "role") return allByRole(role || "button", value);
  if (typ === "aria_label" || typ === "aria") return allBySelector(`[aria-label="${cssEscape(value)}"]`);
  if (typ === "placeholder") return allBySelector(`[placeholder="${cssEscape(value)}"]`);
  if (typ === "title") return allBySelector(`[title="${cssEscape(value)}"]`);
  if (typ === "alt_text" || typ === "alt") return allBySelector(`[alt="${cssEscape(value)}"]`);
  if (typ === "name" || typ === "attr_name") return allBySelector(`[name="${cssEscape(value)}"]`);
  if (typ === "label") {
    return allBySelector("input, textarea, select").filter((el) => accessibleName(el).toLowerCase().includes(value.trim().toLowerCase()));
  }
  if (typ === "test_id" || typ === "data_testid") return allBySelector(`[data-testid="${cssEscape(value)}"]`);
  if (value) return allBySelector(value);
  return [];
}
function resolveElement(strategy) {
  return firstVisible(elementsFor(strategy));
}
function setInputValue(el, value) {
  const input = el;
  const proto = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const desc = Object.getOwnPropertyDescriptor(proto, "value");
  if (desc?.set) desc.set.call(input, value);
  else input.value = value;
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
}
function selectOption(el, label, optionValue) {
  let select = el;
  if (el.tagName.toLowerCase() === "option") {
    select = el.closest("select") || select;
  }
  if (select && select.tagName.toLowerCase() === "select") {
    const want = (optionValue ?? label).trim();
    const opt = Array.from(select.options).find((o) => o.value === want || o.text.trim() === want || o.text.trim().includes(want));
    if (opt) {
      select.value = opt.value;
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }
  }
  el.click();
}
function pressKey(el, key) {
  el.focus();
  const ev = { key, code: key.length === 1 ? `Key${key.toUpperCase()}` : key, bubbles: true, cancelable: true };
  el.dispatchEvent(new KeyboardEvent("keydown", ev));
  el.dispatchEvent(new KeyboardEvent("keypress", ev));
  el.dispatchEvent(new KeyboardEvent("keyup", ev));
  if (key === "Enter" && el instanceof HTMLInputElement) {
    el.form?.requestSubmit();
  }
}
function extractContent(step) {
  const goal = (step.extractionGoal || step.goal || step.description || "").toLowerCase();
  if (step.cssSelector) {
    const el = document.querySelector(step.cssSelector);
    if (el && el.innerText.trim()) return el.innerText.trim();
  }
  if (goal.includes("heading") || goal.includes("title") || goal.includes("h1")) {
    const h1 = document.querySelector("h1");
    if (h1 && h1.innerText.trim()) return h1.innerText.trim();
    return document.title.trim();
  }
  if (goal.includes("paragraph") || goal.includes("article")) {
    const paras = document.querySelectorAll("main p, article p, #mw-content-text p, p");
    for (const p of Array.from(paras).slice(0, 8)) {
      const text = p.innerText.trim();
      if (text) return text.slice(0, 4e3);
    }
    const main2 = document.querySelector("main, article");
    if (main2 && main2.innerText.trim()) return main2.innerText.trim().slice(0, 4e3);
  }
  const main = document.querySelector("main, article");
  if (main && main.innerText.trim()) return main.innerText.trim().slice(0, 4e3);
  return (document.body?.innerText || "").trim().slice(0, 4e3);
}
function pageInfo() {
  const title = document.title || "";
  const body = (document.body?.innerText || "").slice(0, 800);
  const headings = Array.from(document.querySelectorAll("h1, h2, [role=heading]")).map((h) => h.innerText.trim());
  return {
    url: location.href,
    title,
    body,
    headings,
    wikimediaError: title.includes("Wikimedia Error") || body.includes("Too many requests")
  };
}
var DEFAULT_CANDIDATE_SELECTOR = [
  "option",
  "[role='option']",
  "tbody tr",
  "table tr",
  "[role='row']",
  "li",
  "[role='listitem']",
  "label",
  "button",
  "[role='button']",
  "a[href]",
  "[role='link']",
  "[role='menuitem']",
  "[role='tab']",
  "[role='radio']",
  "[role='checkbox']"
].join(",");
function shortPath(el) {
  if (el.id) return `#${cssEscape(el.id)}`;
  const dataName = el.getAttribute("data-name");
  if (dataName) return `${el.tagName.toLowerCase()}[data-name="${cssEscape(dataName)}"]`;
  const value = el.getAttribute("value");
  if (el.tagName === "OPTION" && value != null) {
    const sel = el.closest("select");
    const root = sel ? shortPath(sel) : "select";
    return `${root} option[value="${cssEscape(value)}"]`;
  }
  const parts = [];
  let cur = el;
  while (cur && cur !== document.documentElement && parts.length < 6) {
    if (cur.id) {
      parts.unshift(`#${cssEscape(cur.id)}`);
      break;
    }
    let part = cur.tagName.toLowerCase();
    const parentEl = cur.parentElement;
    if (parentEl) {
      const same = Array.from(parentEl.children).filter((c) => c.tagName === cur.tagName);
      if (same.length > 1) part += `:nth-of-type(${same.indexOf(cur) + 1})`;
    }
    parts.unshift(part);
    cur = parentEl;
  }
  return parts.join(" > ");
}
function collectCandidates(opts) {
  let selector = opts.selector || DEFAULT_CANDIDATE_SELECTOR;
  if (opts.typ === "select_change") selector = "option, [role='option']";
  let root = document;
  if (opts.containerHint) {
    try {
      const hit = document.querySelector(opts.containerHint);
      if (hit) root = hit;
    } catch {
    }
  }
  const nodes = Array.from(root.querySelectorAll(selector)).slice(0, opts.limit ?? 80);
  return nodes.map((el) => {
    const dataName = el.getAttribute("data-name");
    let text = "";
    if (dataName && dataName.trim()) text = dataName.trim();
    else if (el.tagName === "TR") {
      const cell = el.querySelector("th,td");
      text = (cell?.innerText || "").replace(/\s+/g, " ").trim();
    } else {
      text = (el.innerText || el.textContent || el.getAttribute("aria-label") || el.getAttribute("label") || el.value || "").replace(/\s+/g, " ").trim();
    }
    return {
      text,
      role: el.getAttribute("role") || el.tagName.toLowerCase(),
      tag: el.tagName.toLowerCase(),
      value: el.value != null ? String(el.value) : null,
      selector: shortPath(el),
      disabled: !!el.disabled || el.getAttribute("aria-disabled") === "true"
    };
  }).filter((c) => c.text);
}

// src/content.ts
function handle(action) {
  try {
    if (action.op === "ping") return { ok: true, data: { ready: true, url: location.href } };
    if (action.op === "pageInfo") return { ok: true, data: pageInfo() };
    if (action.op === "extract") return { ok: true, data: extractContent(action.step) };
    if (action.op === "scroll") {
      window.scrollBy(action.scrollX || 0, action.scrollY || 0);
      return { ok: true, data: { scrollX: action.scrollX || 0, scrollY: action.scrollY || 0 } };
    }
    if (action.op === "assert") {
      const expected = action.expected;
      if (!expected) return { ok: true };
      const info = pageInfo();
      if (expected.url_includes && !info.url.includes(expected.url_includes)) {
        return { ok: false, error: `url did not include ${JSON.stringify(expected.url_includes)} (was ${info.url})` };
      }
      if (expected.title_contains && !info.title.includes(expected.title_contains)) {
        return { ok: false, error: `title did not contain ${JSON.stringify(expected.title_contains)} (was ${JSON.stringify(info.title)})` };
      }
      const body = document.body?.innerText || "";
      if (expected.text_contains && !body.includes(expected.text_contains)) {
        return { ok: false, error: `page text did not contain ${JSON.stringify(expected.text_contains)}` };
      }
      if (expected.heading && !info.headings.some((h) => h.includes(expected.heading))) {
        return { ok: false, error: `heading ${JSON.stringify(expected.heading)} not found` };
      }
      return { ok: true };
    }
    if (action.op === "collect") {
      const raw = collectCandidates({ typ: action.typ, containerHint: action.containerHint, limit: action.limit });
      return { ok: true, data: raw.filter((c) => !c.disabled) };
    }
    if (action.op === "apply") {
      let el = null;
      if (action.selector) {
        try {
          el = document.querySelector(action.selector);
        } catch {
          el = null;
        }
      }
      if (!el) {
        const nodes = Array.from(document.querySelectorAll("body *")).filter((n) => {
          const t = (n.innerText || n.textContent || "").replace(/\s+/g, " ").trim();
          return t === action.text;
        });
        el = nodes.at(-1) || null;
      }
      if (!el) return { ok: false, error: `could not resolve candidate ${action.text}` };
      if (action.typ === "select_change") selectOption(el, action.text, action.value);
      else if (action.typ === "input") setInputValue(el, action.value ?? action.text);
      else el.click();
      return { ok: true, data: { selector: action.selector, text: action.text } };
    }
    if (action.op === "act") {
      const el = resolveElement(action.strategy);
      if (!el) return { ok: false, error: `no matching elements for ${action.strategy.type}:${action.strategy.value}` };
      if (action.typ === "click") el.click();
      else if (action.typ === "input") {
        if (action.value == null) return { ok: false, error: "input step is missing value" };
        setInputValue(el, String(action.value));
      } else if (action.typ === "select_change") {
        if (action.selected == null) return { ok: false, error: "select_change step is missing selectedText" };
        selectOption(el, String(action.selected));
      } else if (action.typ === "key_press") {
        if (!action.key) return { ok: false, error: "key_press step is missing key" };
        pressKey(el, String(action.key));
      } else {
        return { ok: false, error: `unsupported step type: ${action.typ}` };
      }
      return { ok: true, data: { type: action.strategy.type, value: action.strategy.value } };
    }
    return { ok: false, error: "unknown action" };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.kind !== "bp-action") return;
  sendResponse(handle(message.action));
  return false;
});
