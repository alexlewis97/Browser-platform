// src/copy/he.ts
var he = {
  brand: "\u05E4\u05DC\u05D8\u05E4\u05D5\u05E8\u05DE\u05EA \u05D3\u05E4\u05D3\u05E4\u05DF",
  tabs: {
    installed: "\u05DE\u05D5\u05EA\u05E7\u05DF",
    market: "\u05E9\u05D5\u05E7",
    record: "\u05D4\u05E7\u05DC\u05D8\u05D4",
    run: "\u05D4\u05E8\u05E6\u05D4",
    chat: "\u05E6\u05F3\u05D0\u05D8",
    settings: "\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA"
  },
  installed: {
    title: "\u05DE\u05D5\u05EA\u05E7\u05DF",
    run: "\u05D4\u05E8\u05E6\u05D4",
    publish: "\u05E4\u05E8\u05E1\u05D5\u05DD",
    remove: "\u05D4\u05E1\u05E8\u05D4",
    sourceMarket: "\u05E9\u05D5\u05E7",
    sourceRecord: "\u05D4\u05D5\u05E7\u05DC\u05D8",
    sourceImport: "\u05D9\u05D9\u05D1\u05D5\u05D0",
    empty: "\u05D0\u05D9\u05DF \u05E2\u05D3\u05D9\u05D9\u05DF \u05D6\u05E8\u05D9\u05DE\u05D5\u05EA. \u05D4\u05E7\u05DC\u05D9\u05D8\u05D5 \u05D6\u05E8\u05D9\u05DE\u05D4, \u05D9\u05D9\u05D1\u05D0\u05D5 JSON, \u05D0\u05D5 \u05D4\u05EA\u05E7\u05D9\u05E0\u05D5 \u05DE\u05D4\u05E9\u05D5\u05E7.",
    importTitle: "\u05D9\u05D9\u05D1\u05D5\u05D0 JSON \u05E9\u05DC \u05D6\u05E8\u05D9\u05DE\u05D4"
  },
  market: {
    title: "\u05E9\u05D5\u05E7",
    tokenRequired: "\u05D4\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD \u05E4\u05E8\u05D8\u05D9\u05D9\u05DD. \u05D4\u05D5\u05E1\u05D9\u05E4\u05D5 \u05D0\u05EA \u05D0\u05E1\u05D9\u05DE\u05D5\u05DF \u05D4\u05D2\u05D9\u05E9\u05D4 \u05D1\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA \u05D5\u05D0\u05D6 \u05E8\u05E2\u05E0\u05E0\u05D5 \u05D0\u05EA \u05D4\u05DC\u05E9\u05D5\u05E0\u05D9\u05EA.",
    openSettings: "\u05E4\u05EA\u05D9\u05D7\u05EA \u05D4\u05D2\u05D3\u05E8\u05D5\u05EA",
    codeWarning: "\u05D7\u05D1\u05D9\u05DC\u05D4 \u05D6\u05D5 \u05DE\u05DB\u05D9\u05DC\u05D4 \u05E7\u05D5\u05D3 \u05D0\u05D5\u05D8\u05D5\u05DE\u05E6\u05D9\u05D4 \u05DC\u05D4\u05E8\u05E6\u05D4. \u05D1\u05D3\u05E7\u05D5 \u05DC\u05E4\u05E0\u05D9 \u05D4\u05E8\u05E6\u05D4.",
    updateAvailable: (installed, latest) => `\u05E2\u05D3\u05DB\u05D5\u05DF \u05D6\u05DE\u05D9\u05DF (\u05DE\u05D5\u05EA\u05E7\u05DF v${installed} \u2192 v${latest}).`,
    inputs: "\u05E7\u05DC\u05D8\u05D9\u05DD:",
    inputsNone: "\u05D0\u05D9\u05DF \u05E7\u05DC\u05D8\u05D9\u05DD \u05DE\u05D5\u05E6\u05D4\u05E8\u05D9\u05DD",
    pomeradoUnsupported: "\u05D7\u05D1\u05D9\u05DC\u05D5\u05EA Pomerado \u05D0\u05D9\u05E0\u05DF \u05E0\u05EA\u05DE\u05DB\u05D5\u05EA \u05D1\u05EA\u05D5\u05E1\u05E3 (workflow-use \u05D1\u05DC\u05D1\u05D3).",
    install: "\u05D4\u05EA\u05E7\u05E0\u05D4",
    reinstall: "\u05D4\u05EA\u05E7\u05E0\u05D4 \u05DE\u05D7\u05D3\u05E9",
    update: "\u05E2\u05D3\u05DB\u05D5\u05DF",
    empty: "\u05D0\u05D9\u05DF \u05E4\u05E8\u05D9\u05D8\u05D9\u05DD (\u05D0\u05D5 \u05E9\u05D4\u05E9\u05D5\u05E7 \u05E8\u05D9\u05E7). \u05E4\u05E8\u05E1\u05DE\u05D5 \u05D7\u05D1\u05D9\u05DC\u05D5\u05EA workflow-use \u05DE\u05D4\u05D0\u05EA\u05E8 \u05D5\u05D0\u05D6 \u05E8\u05E2\u05E0\u05E0\u05D5.",
    publishTitle: "\u05E4\u05E8\u05E1\u05D5\u05DD",
    publishHint: "\u05D1\u05D7\u05E8\u05D5 \u05D6\u05E8\u05D9\u05DE\u05D4 \u05DE\u05D5\u05EA\u05E7\u05E0\u05EA \u05D0\u05D5 \u05DE\u05D9\u05D5\u05D1\u05D0\u05EA, \u05E2\u05E8\u05DB\u05D5 \u05E4\u05E8\u05D8\u05D9\u05DD \u05D0\u05DD \u05E6\u05E8\u05D9\u05DA, \u05D5\u05E4\u05E8\u05E1\u05DE\u05D5. \u05DB\u05D9\u05E0\u05D5\u05D9\u05D9 HITL \u05E9\u05E0\u05DC\u05DE\u05D3\u05D5 \u05E0\u05DB\u05DC\u05DC\u05D9\u05DD. \u05E4\u05E8\u05E1\u05D5\u05DD \u05D7\u05D5\u05D6\u05E8 \u05DE\u05E2\u05DC\u05D4 \u05D2\u05E8\u05E1\u05D4.",
    yourAutomations: "\u05D4\u05D0\u05D5\u05D8\u05D5\u05DE\u05E6\u05D9\u05D5\u05EA \u05E9\u05DC\u05DB\u05DD",
    chooseWorkflow: "\u05D1\u05D7\u05E8\u05D5 \u05D6\u05E8\u05D9\u05DE\u05D4\u2026",
    importFirst: "\u05D9\u05D9\u05D1\u05D0\u05D5 \u05D0\u05D5 \u05D4\u05EA\u05E7\u05D9\u05E0\u05D5 \u05D6\u05E8\u05D9\u05DE\u05D4 \u05E7\u05D5\u05D3\u05DD, \u05D5\u05D0\u05D6 \u05EA\u05D5\u05DB\u05DC\u05D5 \u05DC\u05E4\u05E8\u05E1\u05DD \u05DB\u05D0\u05DF.",
    name: "\u05E9\u05DD",
    description: "\u05EA\u05D9\u05D0\u05D5\u05E8",
    declaredInputs: "\u05E7\u05DC\u05D8\u05D9\u05DD \u05DE\u05D5\u05E6\u05D4\u05E8\u05D9\u05DD (\u05DC\u05E2\u05E8\u05D9\u05DB\u05D4)",
    publishedOption: (name, version) => `${name} (\u05E4\u05D5\u05E8\u05E1\u05DD v${version} \u2014 \u05E2\u05D3\u05DB\u05D5\u05DF)`,
    refresh: "\u05E8\u05E2\u05E0\u05D5\u05DF \u05E8\u05E9\u05D9\u05DE\u05EA \u05E4\u05E8\u05D9\u05D8\u05D9\u05DD"
  },
  run: {
    chooseFirst: "\u05D1\u05D7\u05E8\u05D5 \u05E7\u05D5\u05D3\u05DD \u05D6\u05E8\u05D9\u05DE\u05D4 \u05DE\u05D5\u05EA\u05E7\u05E0\u05EA.",
    playbackHint: "\u05DE\u05D5\u05E4\u05E2\u05DC \u05D1\u05DC\u05E9\u05D5\u05E0\u05D9\u05EA Chrome \u05D4\u05E0\u05D5\u05DB\u05D7\u05D9\u05EA. \u05D9\u05E9 \u05DC\u05DE\u05DC\u05D0 \u05E9\u05D3\u05D5\u05EA \u05D7\u05D5\u05D1\u05D4.",
    noInputs: "\u05DC\u05D6\u05E8\u05D9\u05DE\u05D4 \u05D6\u05D5 \u05D0\u05D9\u05DF \u05E7\u05DC\u05D8\u05D9\u05DD.",
    runInTab: "\u05D4\u05E8\u05E6\u05D4 \u05D1\u05DC\u05E9\u05D5\u05E0\u05D9\u05EA \u05D4\u05E0\u05D5\u05DB\u05D7\u05D9\u05EA",
    trace: "\u05E2\u05E7\u05D1\u05D5\u05EA",
    noSteps: "\u05D0\u05D9\u05DF \u05E2\u05D3\u05D9\u05D9\u05DF \u05E9\u05DC\u05D1\u05D9\u05DD.",
    hitlTitle: "\u05D1\u05D7\u05D9\u05E8\u05EA \u05D4\u05EA\u05D0\u05DE\u05D4",
    hitlBody: (query, reason) => `\u05D4\u05E9\u05D0\u05D9\u05DC\u05EA\u05D4 \xAB${query}\xBB \u2014 ${reason.replaceAll("_", " ")}. \u05D1\u05D7\u05E8\u05D5 \u05D4\u05EA\u05D0\u05DE\u05D4 \u05DC\u05D4\u05DE\u05E9\u05DA. \u05D4\u05D1\u05D5\u05E8\u05E8 \u05E0\u05E9\u05DE\u05E8 \u05D1\u05D6\u05E8\u05D9\u05DE\u05D4 \u05DC\u05E4\u05E2\u05DD \u05D4\u05D1\u05D0\u05D4.`,
    hitlScore: (score) => `\u05E6\u05D9\u05D5\u05DF ${score}`,
    hitlCancel: "\u05D1\u05D9\u05D8\u05D5\u05DC",
    hitlConfirm: "\u05E9\u05D9\u05DE\u05D5\u05E9 \u05D1\u05D4\u05EA\u05D0\u05DE\u05D4 \u05D6\u05D5",
    fillRequired: (names) => `\u05DE\u05DC\u05D0\u05D5 \u05E9\u05D3\u05D5\u05EA \u05D7\u05D5\u05D1\u05D4: ${names}`
  },
  record: {
    title: "\u05D4\u05E7\u05DC\u05D8\u05D4",
    tokenBanner: "\u05D4\u05D5\u05E1\u05D9\u05E4\u05D5 \u05D0\u05EA \u05D0\u05E1\u05D9\u05DE\u05D5\u05DF \u05D4\u05D2\u05D9\u05E9\u05D4 (\u05D5\u05DB\u05EA\u05D5\u05D1\u05EA \u05E9\u05E8\u05EA \u05D0\u05DD \u05E6\u05E8\u05D9\u05DA) \u05D1\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA \u05DB\u05D3\u05D9 \u05E9\u05E0\u05D9\u05EA\u05DF \u05D9\u05D4\u05D9\u05D4 \u05DC\u05E0\u05E7\u05D5\u05EA \u05D5\u05DC\u05E9\u05DE\u05D5\u05E8 \u05D4\u05E7\u05DC\u05D8\u05D4 \u05DC\u05E1\u05E4\u05E8\u05D9\u05D9\u05D4.",
    intro: "\u05D1\u05E6\u05E2\u05D5 \u05D0\u05EA \u05D4\u05DE\u05E9\u05D9\u05DE\u05D4 \u05D1\u05D7\u05DC\u05D5\u05DF Chrome \u05D4\u05D6\u05D4. \u05D4\u05EA\u05D7\u05D9\u05DC\u05D5 \u05D4\u05E7\u05DC\u05D8\u05D4, \u05DC\u05D7\u05E6\u05D5 \u05D5\u05D4\u05E7\u05DC\u05D9\u05D3\u05D5 \u05DB\u05E8\u05D2\u05D9\u05DC, \u05D5\u05D0\u05D6 \u05E2\u05E6\u05E8\u05D5. \u05DC\u05D7\u05D9\u05E6\u05D5\u05EA \u05DE\u05D9\u05D5\u05EA\u05E8\u05D5\u05EA \u05DE\u05D5\u05E1\u05E8\u05D5\u05EA; \u05D0\u05E4\u05E9\u05E8 \u05DC\u05E9\u05D7\u05D6\u05E8 \u05D0\u05D5 \u05DC\u05DE\u05D7\u05D5\u05E7 \u05E9\u05DC\u05D1\u05D9\u05DD \u05DC\u05E4\u05E0\u05D9 \u05E9\u05DE\u05D9\u05E8\u05D4.",
    goal: "\u05DE\u05D8\u05E8\u05D4 (\u05D0\u05D5\u05E4\u05E6\u05D9\u05D5\u05E0\u05DC\u05D9, \u05E9\u05D5\u05E8\u05D4 \u05D0\u05D7\u05EA)",
    goalPh: "\u05DE\u05E6\u05D0\u05D5 \u05D0\u05EA \u05DC\u05D5\u05D7 \u05D4\u05DE\u05E9\u05D7\u05E7\u05D9\u05DD \u05E9\u05DC \u05E7\u05D1\u05D5\u05E6\u05EA \u05DB\u05D3\u05D5\u05E8\u05D2\u05DC",
    name: "\u05E9\u05DD",
    namePh: "football_fixtures",
    start: "\u05D4\u05EA\u05D7\u05DC\u05EA \u05D4\u05E7\u05DC\u05D8\u05D4",
    stop: "\u05E2\u05E6\u05D9\u05E8\u05EA \u05D4\u05E7\u05DC\u05D8\u05D4",
    stopCount: (n) => `\u05E2\u05E6\u05D9\u05E8\u05EA \u05D4\u05E7\u05DC\u05D8\u05D4 (${n})`,
    recording: (count) => `\u05DE\u05E7\u05DC\u05D9\u05D8 \u05D1\u05DC\u05E9\u05D5\u05E0\u05D9\u05EA \u05D4\u05E0\u05D5\u05DB\u05D7\u05D9\u05EA\u2026 \u05E0\u05DC\u05DB\u05D3\u05D5 ${count} \u05D0\u05D9\u05E8\u05D5\u05E2${count === 1 ? "" : "\u05D9\u05DD"}.`,
    cleaning: "\u05DE\u05E0\u05E7\u05D9\u05DD \u05D0\u05EA \u05D4\u05D4\u05E7\u05DC\u05D8\u05D4\u2026",
    starting: "\u05DE\u05EA\u05D7\u05D9\u05DC\u05D9\u05DD\u2026",
    usagePrune: (inTok, outTok) => `\u05D2\u05D6\u05D9\u05E8\u05EA LLM \u05D4\u05E9\u05EA\u05DE\u05E9\u05D4 \u05D1\u05BE${inTok} in / ${outTok} out \u05D8\u05D5\u05E7\u05E0\u05D9\u05DD.`,
    usageExtract: (inTok, outTok) => `\u05D7\u05D9\u05DC\u05D5\u05E5 \u05E4\u05E8\u05DE\u05D8\u05E8\u05D9\u05DD \u05D4\u05E9\u05EA\u05DE\u05E9 \u05D1\u05BE${inTok} in / ${outTok} out \u05D8\u05D5\u05E7\u05E0\u05D9\u05DD (\u05D2\u05D6\u05D9\u05E8\u05D4 \u05D3\u05D8\u05E8\u05DE\u05D9\u05E0\u05D9\u05E1\u05D8\u05D9\u05EA \u05D1\u05DC\u05D1\u05D3).`,
    usageLlm: (inTok, outTok) => `LLM \u05D4\u05E9\u05EA\u05DE\u05E9 \u05D1\u05BE${inTok} in / ${outTok} out \u05D8\u05D5\u05E7\u05E0\u05D9\u05DD.`,
    usageDeterministic: "\u05D2\u05D6\u05D9\u05E8\u05D4 \u05D3\u05D8\u05E8\u05DE\u05D9\u05E0\u05D9\u05E1\u05D8\u05D9\u05EA \u05D1\u05DC\u05D1\u05D3 (\u05DC\u05DC\u05D0 \u05D8\u05D5\u05E7\u05E0\u05D9 LLM).",
    stats: (before, after) => `${before} \u05E9\u05DC\u05D1\u05D9\u05DD \u05D1\u05D4\u05E7\u05DC\u05D8\u05D4 \u2192 ${after} \u05E0\u05E9\u05DE\u05E8\u05D5.`,
    reviewTitle: "\u05D1\u05D3\u05D9\u05E7\u05EA \u05E9\u05DC\u05D1\u05D9\u05DD",
    restore: "\u05E9\u05D7\u05D6\u05D5\u05E8",
    delete: "\u05DE\u05D7\u05D9\u05E7\u05D4",
    inputsTitle: "\u05E7\u05DC\u05D8\u05D9\u05DD",
    inputsHint: "\u05D0\u05DC\u05D5 \u05D4\u05D5\u05E4\u05DB\u05D9\u05DD \u05DC\u05E9\u05D3\u05D5\u05EA \u05DE\u05EA\u05D5\u05D9\u05D2\u05D9\u05DD \u05D7\u05D5\u05D1\u05D4 \u05D1\u05D4\u05E8\u05E6\u05D4. \u05D0\u05E9\u05E8\u05D5 \u05D0\u05D5 \u05E2\u05E8\u05DB\u05D5.",
    paramName: "\u05E9\u05DD",
    paramLabel: "\u05EA\u05D5\u05D5\u05D9\u05EA",
    paramExample: "\u05D3\u05D5\u05D2\u05DE\u05D4",
    required: "\u05D7\u05D5\u05D1\u05D4",
    noParams: "\u05DC\u05D0 \u05D6\u05D5\u05D4\u05D5 \u05E4\u05E8\u05DE\u05D8\u05E8\u05D9\u05DD. \u05D0\u05E4\u05E9\u05E8 \u05E2\u05D3\u05D9\u05D9\u05DF \u05DC\u05E9\u05DE\u05D5\u05E8 \u05D6\u05E8\u05D9\u05DE\u05D4 \u05E7\u05D1\u05D5\u05E2\u05D4, \u05D0\u05D5 \u05DC\u05D4\u05D5\u05E1\u05D9\u05E3 \u05E9\u05DD \u05DB\u05DE\u05D5 team \u05D1\u05DE\u05D8\u05E8\u05D4 \u05D5\u05DC\u05D4\u05E7\u05DC\u05D9\u05D8 \u05E9\u05D5\u05D1.",
    addInput: "\u05D4\u05D5\u05E1\u05E4\u05EA \u05E7\u05DC\u05D8",
    save: "\u05E9\u05DE\u05D9\u05E8\u05EA \u05D6\u05E8\u05D9\u05DE\u05D4",
    defaultName: "\u05D6\u05E8\u05D9\u05DE\u05D4 \u05DE\u05D5\u05E7\u05DC\u05D8\u05EA",
    defaultParamName: "value",
    defaultParamLabel: "\u05E2\u05E8\u05DA",
    stepNav: (url) => `\u05DE\u05E2\u05D1\u05E8 \u05DC\u05BE${url}`,
    stepType: (value, target) => `\u05D4\u05E7\u05DC\u05D3\u05EA ${value} \u05D1\u05BE${target}`,
    stepChoose: (value) => `\u05D1\u05D7\u05D9\u05E8\u05EA ${value}`,
    stepKey: (key) => `\u05DC\u05D7\u05D9\u05E6\u05D4 \u05E2\u05DC ${key}`,
    stepClick: (target) => `\u05DC\u05D7\u05D9\u05E6\u05D4 \u05E2\u05DC ${target}`,
    stepExtract: (goal) => `\u05D7\u05D9\u05DC\u05D5\u05E5 ${goal}`,
    stepGeneric: "\u05E9\u05DC\u05D1"
  },
  settings: {
    title: "\u05D4\u05D2\u05D3\u05E8\u05D5\u05EA",
    marketOrigin: "\u05DE\u05E7\u05D5\u05E8 \u05D4\u05E9\u05D5\u05E7",
    backendUrl: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E9\u05E8\u05EA",
    accessToken: "\u05D0\u05E1\u05D9\u05DE\u05D5\u05DF \u05D2\u05D9\u05E9\u05D4 \u05DC\u05D0\u05EA\u05E8",
    hint: "\u05D0\u05D5\u05EA\u05D5 \u05D0\u05E1\u05D9\u05DE\u05D5\u05DF \u05DE\u05E9\u05D5\u05EA\u05E3 \u05DB\u05DE\u05D5 \u05D1\u05D0\u05EA\u05E8 \u05D4\u05E0\u05D9\u05D9\u05D3. \u05E0\u05E9\u05DE\u05E8 \u05E8\u05E7 \u05D1\u05E4\u05E8\u05D5\u05E4\u05D9\u05DC \u05D4\u05D3\u05E4\u05D3\u05E4\u05DF (chrome.storage.local). \u05E0\u05D3\u05E8\u05E9 \u05DC\u05E8\u05E9\u05D9\u05DE\u05D4 \u05D5\u05D4\u05EA\u05E7\u05E0\u05D4 \u05DE\u05D4\u05E9\u05D5\u05E7, \u05D5\u05DC\u05E0\u05D9\u05E7\u05D5\u05D9 \u05D5\u05E9\u05DE\u05D9\u05E8\u05EA \u05D4\u05E7\u05DC\u05D8\u05D4 \u05DC\u05E1\u05E4\u05E8\u05D9\u05D9\u05D4.",
    save: "\u05E9\u05DE\u05D9\u05E8\u05D4",
    show: "\u05D4\u05E6\u05D2",
    hide: "\u05D4\u05E1\u05EA\u05E8"
  },
  chat: {
    title: "\u05E6\u05F3\u05D0\u05D8",
    empty: "\u05D1\u05E7\u05E9\u05D5 \u05D6\u05E8\u05D9\u05DE\u05D4 \u05E9\u05DE\u05D5\u05E8\u05D4, \u05DB\u05DE\u05D4 \u05D1\u05D1\u05EA \u05D0\u05D7\u05EA, \u05D0\u05D5 \u05D0\u05D5\u05EA\u05D4 \u05D6\u05E8\u05D9\u05DE\u05D4 \u05E2\u05DC \u05E8\u05E9\u05D9\u05DE\u05D4. \u05D4\u05EA\u05DB\u05E0\u05D5\u05DF \u05E8\u05E5 \u05D1\u05E9\u05E8\u05EA; \u05D4\u05DB\u05DC\u05D9\u05DD \u05E8\u05E6\u05D9\u05DD \u05D1\u05DC\u05E9\u05D5\u05E0\u05D9\u05EA \u05D4\u05D6\u05D5.",
    message: "\u05D4\u05D5\u05D3\u05E2\u05D4",
    send: "\u05E9\u05DC\u05D9\u05D7\u05D4",
    roleUser: "\u05DE\u05E9\u05EA\u05DE\u05E9",
    roleAssistant: "\u05E2\u05D5\u05D6\u05E8",
    planning: "\u05DE\u05EA\u05DB\u05E0\u05DF\u2026",
    confirmRun: "\u05DC\u05D4\u05E8\u05D9\u05E5 \u05D0\u05EA \u05D4\u05D6\u05E8\u05D9\u05DE\u05D5\u05EA?",
    cancelled: "\u05D1\u05D5\u05D8\u05DC.",
    missingInputs: "\u05D7\u05E1\u05E8\u05D9\u05DD \u05E7\u05DC\u05D8\u05D9\u05DD \u05E0\u05D3\u05E8\u05E9\u05D9\u05DD.",
    runningTools: (n) => `\u05DE\u05E8\u05D9\u05E5 ${n} \u05E7\u05E8\u05D9\u05D0\u05D5\u05EA \u05DB\u05DC\u05D9 \u05D1\u05DC\u05E9\u05D5\u05E0\u05D9\u05EA\u2026`,
    done: "\u05D4\u05D5\u05E9\u05DC\u05DD.",
    failed: "\u05D4\u05E6\u05F3\u05D0\u05D8 \u05E0\u05DB\u05E9\u05DC"
  },
  common: {
    none: "\u05D0\u05D9\u05DF",
    score: "\u05E6\u05D9\u05D5\u05DF",
    v: "v",
    sha256: "sha256"
  },
  flash: {
    stateFailed: "\u05E7\u05E8\u05D9\u05D0\u05EA \u05DE\u05E6\u05D1 \u05D4\u05EA\u05D5\u05E1\u05E3 \u05E0\u05DB\u05E9\u05DC\u05D4",
    marketFailed: "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D8\u05E2\u05D5\u05DF \u05D0\u05EA \u05D4\u05E9\u05D5\u05E7",
    listingsRefreshed: "\u05D4\u05E8\u05E9\u05D9\u05DE\u05D4 \u05E8\u05D5\u05E2\u05E0\u05E0\u05D4.",
    removeConfirm: "\u05DC\u05D4\u05E1\u05D9\u05E8 \u05D0\u05EA \u05D4\u05D6\u05E8\u05D9\u05DE\u05D4 \u05D4\u05DE\u05D5\u05EA\u05E7\u05E0\u05EA \u05DE\u05D4\u05EA\u05D5\u05E1\u05E3?",
    removeLibraryConfirm: "\u05DC\u05DE\u05D7\u05D5\u05E7 \u05D0\u05EA \u05D4\u05D6\u05E8\u05D9\u05DE\u05D4 \u05DE\u05D4\u05EA\u05D5\u05E1\u05E3 \u05D5\u05DE\u05D4\u05E1\u05E4\u05E8\u05D9\u05D9\u05D4? \u05D4\u05E8\u05E6\u05D5\u05EA \u05E7\u05D5\u05D3\u05DE\u05D5\u05EA \u05D9\u05D9\u05E9\u05DE\u05E8\u05D5.",
    codeInstallConfirm: "\u05D7\u05D1\u05D9\u05DC\u05D4 \u05D6\u05D5 \u05DE\u05DB\u05D9\u05DC\u05D4 \u05E7\u05D5\u05D3 \u05D0\u05D5\u05D8\u05D5\u05DE\u05E6\u05D9\u05D4 \u05DC\u05D4\u05E8\u05E6\u05D4. \u05D1\u05D3\u05E7\u05D5 \u05DC\u05E4\u05E0\u05D9 \u05D4\u05E8\u05E6\u05D4. \u05DC\u05D4\u05EA\u05E7\u05D9\u05DF \u05D1\u05DB\u05DC \u05D6\u05D0\u05EA?",
    installFailed: "\u05D4\u05D4\u05EA\u05E7\u05E0\u05D4 \u05E0\u05DB\u05E9\u05DC\u05D4",
    updated: "\u05E2\u05D5\u05D3\u05DB\u05DF.",
    installedRun: "\u05D4\u05D5\u05EA\u05E7\u05DF. \u05E4\u05EA\u05D7\u05D5 \u05DE\u05DC\u05E9\u05D5\u05E0\u05D9\u05EA \u05DE\u05D5\u05EA\u05E7\u05DF \u05DB\u05D3\u05D9 \u05DC\u05D4\u05E8\u05D9\u05E5.",
    recordStartFailed: "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D4\u05E7\u05DC\u05D8\u05D4",
    recordingInfo: "\u05DE\u05E7\u05DC\u05D9\u05D8\u05D9\u05DD. \u05D4\u05E9\u05EA\u05DE\u05E9\u05D5 \u05D1\u05D7\u05DC\u05D5\u05DF Chrome \u05DC\u05D1\u05D9\u05E6\u05D5\u05E2 \u05D4\u05DE\u05E9\u05D9\u05DE\u05D4, \u05D5\u05D0\u05D6 \u05E2\u05E6\u05E8\u05D5.",
    recordStopFailed: "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E2\u05E6\u05D5\u05E8 \u05D4\u05E7\u05DC\u05D8\u05D4",
    recordCleanFailed: "\u05DC\u05D0 \u05E0\u05D9\u05EA\u05DF \u05DC\u05E0\u05E7\u05D5\u05EA \u05D4\u05E7\u05DC\u05D8\u05D4",
    recordCleaned: "\u05D4\u05D4\u05E7\u05DC\u05D8\u05D4 \u05E0\u05D5\u05E7\u05EA\u05D4. \u05D1\u05D3\u05E7\u05D5 \u05E9\u05DC\u05D1\u05D9\u05DD \u05D5\u05D0\u05D6 \u05E9\u05DE\u05E8\u05D5.",
    keepOneStep: "\u05D4\u05E9\u05D0\u05D9\u05E8\u05D5 \u05DC\u05E4\u05D7\u05D5\u05EA \u05E9\u05DC\u05D1 \u05D0\u05D7\u05D3 \u05DC\u05E4\u05E0\u05D9 \u05E9\u05DE\u05D9\u05E8\u05D4.",
    saveFailed: "\u05D4\u05E9\u05DE\u05D9\u05E8\u05D4 \u05E0\u05DB\u05E9\u05DC\u05D4",
    savedLibrary: "\u05E0\u05E9\u05DE\u05E8 \u05DC\u05E1\u05E4\u05E8\u05D9\u05D9\u05D4. \u05DE\u05D5\u05E4\u05D9\u05E2 \u05D2\u05DD \u05D1\u05EA\u05E4\u05E8\u05D9\u05D8 \u05D4\u05E4\u05E8\u05E1\u05D5\u05DD.",
    importFailed: "\u05D4\u05D9\u05D9\u05D1\u05D5\u05D0 \u05E0\u05DB\u05E9\u05DC",
    imported: "\u05D9\u05D5\u05D1\u05D0. \u05D0\u05E4\u05E9\u05E8 \u05DC\u05D4\u05E8\u05D9\u05E5 \u05DE\u05D4\u05E8\u05E9\u05D9\u05DE\u05D4.",
    inputsMustBeArray: "\u05D4\u05E7\u05DC\u05D8\u05D9\u05DD \u05D7\u05D9\u05D9\u05D1\u05D9\u05DD \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05E2\u05E8\u05DA JSON",
    publishFailed: "\u05D4\u05E4\u05E8\u05E1\u05D5\u05DD \u05E0\u05DB\u05E9\u05DC",
    published: (name, version) => `\u05E4\u05D5\u05E8\u05E1\u05DD ${name} v${version}.`,
    settingsSaveFailed: "\u05D4\u05E9\u05DE\u05D9\u05E8\u05D4 \u05E0\u05DB\u05E9\u05DC\u05D4",
    settingsSaved: "\u05E0\u05E9\u05DE\u05E8 \u05E8\u05E7 \u05D1\u05DE\u05D7\u05E9\u05D1 \u05D4\u05D6\u05D4."
  }
};

// src/lib/interpolate.ts
var BRACE = /\{\{?\s*([a-zA-Z_][\w]*)(?:\|([a-zA-Z0-9_]+))?\s*\}?\}/g;
function placeholdersIn(value, found = []) {
  if (typeof value === "string") {
    const re = new RegExp(BRACE.source, "g");
    let match;
    while (match = re.exec(value)) {
      if (!found.includes(match[1])) found.push(match[1]);
    }
  } else if (Array.isArray(value)) {
    for (const item of value) placeholdersIn(item, found);
  } else if (value && typeof value === "object") {
    for (const item of Object.values(value)) placeholdersIn(item, found);
  }
  return found;
}

// src/lib/inputs.ts
var LABELS = {
  term: "Search term",
  query: "Search query",
  q: "Search query",
  search: "Search term",
  name: "Name",
  status: "Status",
  url: "URL",
  email: "Email",
  title: "Title"
};
function prettyLabel(name, label) {
  if (label && label.trim()) return label.trim();
  const key = (name || "").trim();
  if (LABELS[key.toLowerCase()]) return LABELS[key.toLowerCase()];
  const text = key.replaceAll("_", " ").trim();
  return text ? text[0].toUpperCase() + text.slice(1) : "Input";
}
function deriveInputs(definition) {
  const byName = /* @__PURE__ */ new Map();
  for (const item of definition.input_schema || []) {
    if (!item?.name) continue;
    byName.set(item.name, { ...item, label: prettyLabel(item.name, item.label) });
  }
  for (const name of placeholdersIn(definition)) {
    if (byName.has(name)) continue;
    byName.set(name, { name, type: "string", required: true, label: prettyLabel(name) });
  }
  return [...byName.values()];
}
function missingRequired(inputs, values) {
  const missing = [];
  for (const input of inputs) {
    if (input.required === false) continue;
    const raw = values[input.name];
    if (raw == null || String(raw).trim() === "") missing.push(input.name);
  }
  return missing;
}

// src/lib/types.ts
var DEFAULT_MARKET_ORIGIN = "https://browser-platform-web.vercel.app";
var DEFAULT_BACKEND_URL = "https://browser.129-159-156-75.sslip.io";

// src/lib/market.ts
function listingIdForName(name) {
  const slug = name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);
  return slug || "listing";
}

// src/sidepanel.ts
var view = "installed";
var settings = { marketToken: "", marketOrigin: DEFAULT_MARKET_ORIGIN, backendUrl: DEFAULT_BACKEND_URL };
var workflows = [];
var listings = [];
var run = null;
var selectedId = "";
var inputValues = {};
var flash = null;
var hitlChoice = null;
var busy = false;
var publishId = "";
var chatDraft = "";
var chatBusy = false;
var chatLog = [];
var chatStatus = "";
var recordingActive = false;
var recordingCount = 0;
var recordGoal = "";
var recordName = "";
var recordBusy = false;
var recordEvents = [];
var reviewItems = [];
var recordParams = [];
var recordUsage = null;
var recordStats = null;
var app = () => document.getElementById("app");
function escapeHtml(value) {
  return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}
async function send(kind, payload = {}) {
  return await chrome.runtime.sendMessage({ kind, ...payload });
}
async function refreshState() {
  const res = await send("bp-get-state");
  if (!res.ok) throw new Error(res.error || he.flash.stateFailed);
  settings = res.settings;
  workflows = res.workflows;
  run = res.run;
  if (res.recording) {
    recordingActive = res.recording.active;
    recordingCount = res.recording.count;
  }
}
function banner() {
  return flash ? `<div class="banner ${flash.kind}">${escapeHtml(flash.text)}</div>` : "";
}
function shell(title, body) {
  const tab = (name, label) => `<button type="button" data-view="${name}" class="${view === name || view === "run" && name === "installed" && selectedId ? "active" : ""}">${label}</button>`;
  return `
    <header class="top"><div><p class="eyebrow">${he.brand}</p><h1>${title}</h1></div></header>
    <nav class="tabs">
      ${tab("installed", he.tabs.installed)}
      ${tab("market", he.tabs.market)}
      ${tab("record", he.tabs.record)}
      ${tab("run", he.tabs.run)}
      ${tab("chat", he.tabs.chat)}
      ${tab("settings", he.tabs.settings)}
    </nav>
    <div class="page">${banner()}${body}</div>
  `;
}
function renderInstalled() {
  const cards = workflows.length ? workflows.map(
    (w) => `<article class="card">
            <h2 style="margin:0 0 4px;font-size:1rem">${escapeHtml(w.name)}</h2>
            <div class="mono muted">v${escapeHtml(w.version)} \xB7 ${escapeHtml(w.type)} \xB7 ${w.source === "market" ? he.installed.sourceMarket : w.source === "record" ? he.installed.sourceRecord : he.installed.sourceImport}</div>
            <p class="sub">${escapeHtml(w.description || "")}</p>
            <div class="btn-row">
              <button class="btn primary" data-action="open-run" data-id="${escapeHtml(w.id)}">${he.installed.run}</button>
              <button class="btn" data-action="goto-publish" data-id="${escapeHtml(w.id)}">${he.installed.publish}</button>
              <button class="btn danger" data-action="remove" data-id="${escapeHtml(w.id)}">${he.installed.remove}</button>
            </div>
          </article>`
  ).join("") : `<div class="card"><p class="sub" style="margin:0">${he.installed.empty}</p></div>`;
  return shell(
    he.installed.title,
    `${cards}
    <div class="card">
      <h2 style="margin:0 0 8px;font-size:1rem">${he.installed.importTitle}</h2>
      <input type="file" accept="application/json,.json,.workflow.json" id="import-file" />
    </div>`
  );
}
function renderMarket() {
  if (!settings.marketToken) {
    return shell(
      he.market.title,
      `<div class="card"><p class="sub" style="margin:0">${he.market.tokenRequired}</p>
      <div class="btn-row"><button class="btn primary wide" data-view="settings">${he.market.openSettings}</button></div></div>`
    );
  }
  const cards = listings.length ? listings.map((l) => {
    const warning = l.contains_code ? `<div class="banner info">${he.market.codeWarning}</div>` : "";
    const update = l.updateAvailable ? `<div class="banner info">${escapeHtml(he.market.updateAvailable(l.installedVersion || "", l.version))}</div>` : "";
    const unsupported = l.type === "pomerado";
    return `<article class="card">
            <h2 style="margin:0 0 4px;font-size:1rem">${escapeHtml(l.name)}</h2>
            <div class="mono muted">${escapeHtml(l.type)} \xB7 v${escapeHtml(l.version)} \xB7 ${escapeHtml(l.created_at)}</div>
            <p class="sub">${escapeHtml(l.description || "")}</p>
            <p class="muted">${he.market.inputs} ${escapeHtml(l.inputs.length ? l.inputs.map((i) => i.label || i.name).join(", ") : he.market.inputsNone)}</p>
            <p class="mono muted">${he.common.sha256} ${escapeHtml(l.sha256)}</p>
            ${warning}${update}
            ${unsupported ? `<p class="muted">${he.market.pomeradoUnsupported}</p>` : ""}
            <div class="btn-row">
              <button class="btn primary wide" data-action="install" data-id="${escapeHtml(l.id)}" ${unsupported ? "disabled" : ""}>${l.updateAvailable ? he.market.update : l.installed ? he.market.reinstall : he.market.install}</button>
            </div>
          </article>`;
  }).join("") : `<div class="card"><p class="sub" style="margin:0">${he.market.empty}</p></div>`;
  const publishedFor = (w) => listings.find((l) => l.id === w.listingId || l.id === listingIdForName(w.name) || l.name === w.name);
  const options = workflows.map((w) => {
    const published2 = publishedFor(w);
    const label = published2 ? he.market.publishedOption(w.name, published2.version) : w.name;
    return `<option value="${escapeHtml(w.id)}" ${w.id === publishId ? "selected" : ""}>${escapeHtml(label)}</option>`;
  }).join("");
  const selected = workflows.find((w) => w.id === publishId);
  const published = selected ? publishedFor(selected) : void 0;
  const selectedInputs = selected ? JSON.stringify(
    deriveInputs(selected.definition).map((item) => ({
      name: item.name,
      label: prettyLabel(item.name, item.label),
      type: item.type || "string",
      required: item.required !== false
    })),
    null,
    2
  ) : "";
  const form = `<form id="ext-publish-form" class="card">
      <h2 style="margin:0 0 8px;font-size:1rem">${he.market.publishTitle}</h2>
      <p class="muted">${he.market.publishHint}</p>
      ${workflows.length ? `<label class="field"><span>${he.market.yourAutomations}</span>
        <select name="workflowId" id="ext-market-source">
          <option value="">${he.market.chooseWorkflow}</option>
          ${options}
        </select>
      </label>` : `<p class="muted">${he.market.importFirst}</p>`}
      ${selected ? `<label class="field"><span>${he.market.name}</span><input name="name" required value="${escapeHtml(selected.name)}" /></label>
      <label class="field"><span>${he.market.description}</span><textarea name="description" rows="3">${escapeHtml(selected.description || "")}</textarea></label>
      <label class="field"><span>${he.market.declaredInputs}</span><textarea name="inputs" rows="3">${escapeHtml(selectedInputs)}</textarea></label>
      <div class="btn-row"><button class="btn primary wide" type="submit">${published ? he.market.update : he.installed.publish}</button></div>` : ""}
    </form>`;
  return shell(he.market.title, `${form}<div class="btn-row" style="margin-bottom:10px"><button class="btn wide" data-action="refresh-market">${he.market.refresh}</button></div>${cards}`);
}
function renderRun() {
  const wf = workflows.find((w) => w.id === selectedId);
  if (!wf) {
    return shell(he.tabs.run, `<div class="card"><p class="sub" style="margin:0">${he.run.chooseFirst}</p></div>`);
  }
  const inputs = deriveInputs(wf.definition);
  const missing = missingRequired(inputs, inputValues);
  const fields = inputs.map((input) => {
    const label = prettyLabel(input.name, input.label);
    const req = input.required === false ? "" : " *";
    const value = inputValues[input.name] ?? (input.default != null ? String(input.default) : "");
    if (!(input.name in inputValues) && input.default != null) inputValues[input.name] = String(input.default);
    return `<label class="field"><span>${escapeHtml(label)}${req}</span>
        <input name="${escapeHtml(input.name)}" value="${escapeHtml(value)}" ${input.required === false ? "" : "required"} /></label>`;
  }).join("");
  const traces = (run && run.workflowId === wf.id ? run.traces : []).map((t) => {
    const extra = t.output != null ? `<div class="muted">${escapeHtml(typeof t.output === "string" ? t.output.slice(0, 280) : JSON.stringify(t.output))}</div>` : "";
    const attempt = t.attempt ? `<div class="mono muted">${escapeHtml(t.attempt.type)}: ${escapeHtml(t.attempt.value)}</div>` : "";
    return `<div class="step ${t.status}"><div class="idx">${t.index + 1}</div><div>
        <strong>${escapeHtml(t.type)}</strong> <span class="muted">${escapeHtml(t.description || t.status)}</span>
        ${t.message ? `<div class="muted">${escapeHtml(t.message)}</div>` : ""}
        ${attempt}${extra}
      </div></div>`;
  }).join("");
  const hitl = run?.status === "hitl" && run.hitl ? `<div class="card">
        <h2 style="margin:0 0 6px;font-size:1rem">${he.run.hitlTitle}</h2>
        <p class="sub">${escapeHtml(he.run.hitlBody(run.hitl.query, run.hitl.reason))}</p>
        ${run.hitl.candidates.map(
    (c) => `<button type="button" class="candidate ${hitlChoice === c.id ? "selected" : ""}" data-action="hitl-select" data-id="${escapeHtml(c.id)}">
              <strong>${escapeHtml(c.text)}</strong>
              <div class="mono muted">${escapeHtml(c.role || "")} \xB7 ${he.run.hitlScore(c.score ?? "?")} \xB7 ${escapeHtml(c.selector || "")}</div>
            </button>`
  ).join("")}
        <div class="btn-row">
          <button class="btn danger" data-action="hitl-cancel">${he.run.hitlCancel}</button>
          <button class="btn primary" data-action="hitl-confirm" ${hitlChoice ? "" : "disabled"}>${he.run.hitlConfirm}</button>
        </div>
      </div>` : "";
  const running = run?.status === "running" || run?.status === "hitl";
  return shell(
    escapeHtml(wf.name),
    `<form id="run-form" class="card" data-id="${escapeHtml(wf.id)}" novalidate>
      <p class="sub" style="margin-top:0">${he.run.playbackHint}</p>
      ${fields || `<p class="muted">${he.run.noInputs}</p>`}
      ${missing.length && busy === false ? "" : ""}
      <div class="btn-row">
        <button class="btn primary wide" type="submit" ${running ? "disabled" : ""}>${he.run.runInTab}</button>
      </div>
    </form>
    ${hitl}
    <div class="card">
      <h2 style="margin:0 0 6px;font-size:1rem">${he.run.trace}</h2>
      <div class="trace">${traces || `<p class="muted">${he.run.noSteps}</p>`}</div>
    </div>`
  );
}
function stepSummary(step) {
  const typ = String(step.type || "");
  if (typ === "navigation") return he.record.stepNav(String(step.url || ""));
  if (typ === "input") return he.record.stepType(String(step.value || ""), String(step.cssSelector || step.target_text || "field"));
  if (typ === "select_change" || typ === "select") return he.record.stepChoose(String(step.value || step.target_text || ""));
  if (typ === "key_press" || typ === "key") return he.record.stepKey(String(step.value || "Enter"));
  if (typ === "click") return he.record.stepClick(String(step.target_text || step.cssSelector || "element"));
  if (typ === "extract") return he.record.stepExtract(String(step.extractionGoal || "result"));
  return typ || he.record.stepGeneric;
}
function renderRecord() {
  const tokenReady = Boolean(settings.marketToken && (settings.backendUrl || DEFAULT_BACKEND_URL));
  const setup = tokenReady ? "" : `<div class="banner info">${he.record.tokenBanner}</div>`;
  const controls = `<div class="card">
      <p class="sub" style="margin-top:0">${he.record.intro}</p>
      <label class="field"><span>${he.record.goal}</span>
        <input id="record-goal" value="${escapeHtml(recordGoal)}" placeholder="${he.record.goalPh}" ${recordingActive || recordBusy ? "disabled" : ""} />
      </label>
      <label class="field"><span>${he.record.name}</span>
        <input id="record-name" value="${escapeHtml(recordName)}" placeholder="${he.record.namePh}" ${recordingActive || recordBusy ? "disabled" : ""} />
      </label>
      <div class="btn-row">
        ${recordingActive ? `<button class="btn danger wide" data-action="record-stop" ${recordBusy ? "disabled" : ""}>${recordingCount ? he.record.stopCount(recordingCount) : he.record.stop}</button>` : `<button class="btn primary wide" data-action="record-start" ${recordBusy ? "disabled" : ""}>${he.record.start}</button>`}
      </div>
      ${recordingActive ? `<p class="muted" data-record-status="recording">${he.record.recording(recordingCount)}</p>` : ""}
      ${recordBusy && !recordingActive ? `<p class="muted" data-record-status="${recordEvents.length ? "cleaning" : "starting"}">${recordEvents.length ? he.record.cleaning : he.record.starting}</p>` : ""}
    </div>`;
  const usage = recordUsage ? `<p class="muted">${escapeHtml(
    recordUsage.label || (recordUsage.prune_used ? he.record.usagePrune(recordUsage.tokens_in || 0, recordUsage.tokens_out || 0) : recordUsage.extract_used ? he.record.usageExtract(recordUsage.tokens_in || 0, recordUsage.tokens_out || 0) : recordUsage.used ? he.record.usageLlm(recordUsage.tokens_in || 0, recordUsage.tokens_out || 0) : he.record.usageDeterministic)
  )}</p>` : "";
  const stats = recordStats ? `<p class="muted">${escapeHtml(he.record.stats(String(recordStats.steps_before || 0), String(recordStats.steps_after || reviewItems.filter((i) => i.kept).length)))}</p>` : "";
  const steps = reviewItems.length ? `<div class="card">
        <h2 style="margin:0 0 8px;font-size:1rem">${he.record.reviewTitle}</h2>
        ${usage}${stats}
        <div class="trace">${reviewItems.map((item, i) => {
    const dropped = !item.kept;
    const reason = item.reason ? `<div class="muted">${escapeHtml(item.reason)}${item.stage ? ` \xB7 ${escapeHtml(item.stage)}` : ""}</div>` : "";
    return `<div class="step rec-step ${dropped ? "dropped" : "kept"}" data-rec-id="${escapeHtml(item.id)}">
              <span class="idx">${i + 1}</span>
              <div>
                <div>${escapeHtml(stepSummary(item.step))}</div>
                ${reason}
                <button type="button" class="btn" data-action="${dropped ? "record-restore" : "record-drop"}" data-rec-id="${escapeHtml(item.id)}">${dropped ? he.record.restore : he.record.delete}</button>
              </div>
            </div>`;
  }).join("")}</div>
      </div>` : "";
  const params = reviewItems.length ? `<div class="card">
        <h2 style="margin:0 0 8px;font-size:1rem">${he.record.inputsTitle}</h2>
        <p class="muted">${he.record.inputsHint}</p>
        ${recordParams.length ? recordParams.map(
    (p, i) => `<div class="param-row" data-param-index="${i}">
                    <label class="field"><span>${he.record.paramName}</span><input data-param="${i}" data-field="name" value="${escapeHtml(p.name)}" /></label>
                    <label class="field"><span>${he.record.paramLabel}</span><input data-param="${i}" data-field="label" value="${escapeHtml(p.label || p.name)}" /></label>
                    <label class="field"><span>${he.record.paramExample}</span><input data-param="${i}" data-field="example" value="${escapeHtml(p.example || "")}" /></label>
                    <label class="field check"><span><input type="checkbox" data-param="${i}" data-field="required" ${p.required === false ? "" : "checked"} /> ${he.record.required}</span></label>
                  </div>`
  ).join("") : `<p class="muted">${he.record.noParams}</p>`}
        <div class="btn-row"><button class="btn" data-action="record-add-param">${he.record.addInput}</button></div>
      </div>` : "";
  const save = reviewItems.some((i) => i.kept) ? `<div class="btn-row"><button class="btn primary wide" data-action="record-save" ${recordBusy || !tokenReady ? "disabled" : ""}>${he.record.save}</button></div>` : "";
  return shell(he.record.title, `${setup}${controls}${steps}${params}${save}`);
}
function renderSettings() {
  return shell(
    he.settings.title,
    `<form id="settings-form" class="card">
      <label class="field"><span>${he.settings.marketOrigin}</span>
        <input name="marketOrigin" value="${escapeHtml(settings.marketOrigin || DEFAULT_MARKET_ORIGIN)}" placeholder="${DEFAULT_MARKET_ORIGIN}" />
      </label>
      <label class="field"><span>${he.settings.backendUrl}</span>
        <input name="backendUrl" value="${escapeHtml(settings.backendUrl || DEFAULT_BACKEND_URL)}" placeholder="${DEFAULT_BACKEND_URL}" />
      </label>
      <label class="field"><span>${he.settings.accessToken}</span>
        <div class="secret-wrap">
          <input name="marketToken" type="password" autocomplete="off" value="${escapeHtml(settings.marketToken)}" />
          <button type="button" class="btn peek" data-action="peek">${he.settings.show}</button>
        </div>
      </label>
      <p class="muted">${he.settings.hint}</p>
      <div class="btn-row"><button class="btn primary wide" type="submit">${he.settings.save}</button></div>
    </form>`
  );
}
async function backendChat(payload) {
  const base = (settings.backendUrl || DEFAULT_BACKEND_URL).replace(/\/+$/, "");
  const headers = { "content-type": "application/json" };
  if (settings.marketToken) headers["X-Browser-Platform-Token"] = settings.marketToken;
  const res = await fetch(`${base}/api/chat`, { method: "POST", body: JSON.stringify(payload), headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(String(data.detail || res.statusText || he.chat.failed));
  return data;
}
function renderChat() {
  const roleLabel = (role) => role === "user" ? he.chat.roleUser : he.chat.roleAssistant;
  const history = chatLog.map((msg) => `<div class="card"><strong>${escapeHtml(roleLabel(msg.role))}</strong><p style="white-space:pre-wrap">${escapeHtml(msg.content)}</p></div>`).join("") || `<p class="muted">${he.chat.empty}</p>`;
  return shell(
    he.chat.title,
    `${history}
    ${chatStatus ? `<p class="muted">${escapeHtml(chatStatus)}</p>` : ""}
    <form id="ext-chat-form" class="card">
      <label class="field"><span>${he.chat.message}</span>
        <textarea name="message" required style="min-height:80px">${escapeHtml(chatDraft)}</textarea>
      </label>
      <button class="btn primary wide" type="submit" ${chatBusy ? "disabled" : ""}>${he.chat.send}</button>
    </form>`
  );
}
function render() {
  const usedFlash = flash;
  if (view === "market") app().innerHTML = renderMarket();
  else if (view === "record") app().innerHTML = renderRecord();
  else if (view === "run") app().innerHTML = renderRun();
  else if (view === "chat") app().innerHTML = renderChat();
  else if (view === "settings") app().innerHTML = renderSettings();
  else app().innerHTML = renderInstalled();
  if (usedFlash) flash = null;
}
async function loadMarket() {
  const res = await send("bp-list-market");
  if (!res.ok) throw new Error(res.error || he.flash.marketFailed);
  listings = res.listings;
}
document.addEventListener("submit", (event) => {
  const form = event.target;
  if (!form || form.id !== "ext-chat-form") return;
  event.preventDefault();
  const message = String(form.elements.namedItem("message")?.value || "").trim();
  if (!message || chatBusy) return;
  chatDraft = "";
  chatLog.push({ role: "user", content: message });
  chatBusy = true;
  chatStatus = he.chat.planning;
  render();
  void (async () => {
    try {
      const history = chatLog.slice(0, -1);
      let job = await backendChat({ message, history, target: "extension", stream: false });
      if (job.status === "needs_input" || job.status === "needs_confirmation") {
        if (job.status === "needs_confirmation") {
          if (!confirm(String(job.confirm_reason || he.chat.confirmRun))) {
            chatLog.push({ role: "assistant", content: String(job.confirm_reason || he.chat.cancelled) });
            return;
          }
          job = await backendChat({ message, job_id: job.id, confirm: true, target: "extension", stream: false });
        } else {
          chatLog.push({ role: "assistant", content: String(job.question || job.answer || he.chat.missingInputs) });
          return;
        }
      }
      if (job.status === "awaiting_results" || Array.isArray(job.calls)) {
        const calls = job.calls || [];
        chatStatus = he.chat.runningTools(calls.length);
        render();
        const results = [];
        for (const call of calls) {
          const res = await send("bp-run-definition", {
            definition: call.definition,
            values: call.arguments || {},
            id: call.workflow_id,
            name: call.workflow_name
          });
          results.push({
            id: call.id,
            tool: call.tool,
            workflow_id: call.workflow_id,
            workflow_name: call.workflow_name,
            inputs: call.arguments,
            status: res.ok ? "succeeded" : "failed",
            error: res.error,
            outputs: res.run && res.run.outputs || {},
            action_ending: call.action_ending
          });
        }
        job = await backendChat({ message, job_id: job.id, results, stream: false });
      }
      chatLog.push({ role: "assistant", content: String(job.answer || job.question || job.error || he.chat.done) });
    } catch (err) {
      flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
    } finally {
      chatBusy = false;
      chatStatus = "";
      render();
    }
  })();
});
document.addEventListener("click", (event) => {
  const target = event.target;
  if (!target) return;
  const tab = target.closest("[data-view]");
  if (tab?.dataset.view) {
    view = tab.dataset.view;
    if (view === "market") {
      void loadMarket().catch((err) => {
        flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
      }).finally(() => render());
      return;
    }
    render();
    return;
  }
  const action = target.closest("[data-action]")?.dataset.action;
  if (action === "peek") {
    const input = document.querySelector('input[name="marketToken"]');
    if (!input) return;
    input.type = input.type === "password" ? "text" : "password";
    target.closest("button").textContent = input.type === "password" ? he.settings.show : he.settings.hide;
    return;
  }
  if (action === "open-run") {
    selectedId = target.closest("[data-id]").dataset.id || "";
    view = "run";
    void send("bp-last-inputs", { id: selectedId }).then((res) => {
      inputValues = res.values || {};
      render();
    });
    return;
  }
  if (action === "goto-publish") {
    publishId = target.closest("[data-id]").dataset.id || "";
    view = "market";
    if (settings.marketToken) {
      void loadMarket().catch((err) => {
        flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
      }).finally(() => render());
    } else {
      render();
    }
    return;
  }
  if (action === "remove") {
    const id = target.closest("[data-id]").dataset.id || "";
    const installed = workflows.find((w) => w.id === id);
    const message = installed?.source === "record" ? he.flash.removeLibraryConfirm : he.flash.removeConfirm;
    if (!id || !confirm(message)) return;
    void send("bp-remove", { id }).then(async () => {
      if (selectedId === id) selectedId = "";
      await refreshState();
      render();
    });
    return;
  }
  if (action === "refresh-market") {
    void loadMarket().then(() => {
      flash = { kind: "ok", text: he.flash.listingsRefreshed };
    }).catch((err) => {
      flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
    }).finally(() => render());
    return;
  }
  if (action === "install") {
    const id = target.closest("[data-id]").dataset.id || "";
    const listing = listings.find((l) => l.id === id);
    if (listing?.contains_code && !confirm(he.flash.codeInstallConfirm)) return;
    const btn = target.closest("button");
    if (btn) btn.disabled = true;
    void send("bp-install", { id }).then(async (res) => {
      if (!res.ok) throw new Error(res.error || he.flash.installFailed);
      flash = { kind: "ok", text: listing?.updateAvailable ? he.flash.updated : he.flash.installedRun };
      await refreshState();
      await loadMarket().catch(() => void 0);
      render();
    }).catch((err) => {
      flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
      render();
    });
    return;
  }
  if (action === "record-start") {
    recordGoal = document.getElementById("record-goal")?.value || recordGoal;
    recordName = document.getElementById("record-name")?.value || recordName;
    reviewItems = [];
    recordParams = [];
    recordEvents = [];
    recordUsage = null;
    recordStats = null;
    recordBusy = true;
    render();
    void send("bp-record-start").then(async (res) => {
      if (!res.ok) throw new Error(res.error || he.flash.recordStartFailed);
      recordingActive = true;
      recordingCount = Number(res.count || 0);
      recordBusy = false;
      flash = { kind: "info", text: he.flash.recordingInfo };
      render();
    }).catch((err) => {
      recordBusy = false;
      recordingActive = false;
      flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
      render();
    });
    return;
  }
  if (action === "record-stop") {
    recordBusy = true;
    render();
    void send("bp-record-stop").then(async (res) => {
      if (!res.ok) throw new Error(res.error || he.flash.recordStopFailed);
      recordingActive = false;
      recordEvents = res.events || [];
      recordingCount = recordEvents.length;
      const clean = await send("bp-record-clean", {
        events: recordEvents,
        goal: recordGoal,
        name: recordName
      });
      if (!clean.ok) throw new Error(clean.error || he.flash.recordCleanFailed);
      const result = clean.result;
      reviewItems = result.review || [];
      recordParams = result.parameters || [];
      recordUsage = result.usage || null;
      recordStats = result.stats || null;
      if (!recordName && result.name) recordName = result.name;
      recordBusy = false;
      flash = { kind: "ok", text: he.flash.recordCleaned };
      render();
    }).catch((err) => {
      recordBusy = false;
      recordingActive = false;
      flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
      render();
    });
    return;
  }
  if (action === "record-drop" || action === "record-restore") {
    const id = target.closest("[data-rec-id]")?.dataset.recId || "";
    reviewItems = reviewItems.map((item) => item.id === id ? { ...item, kept: action === "record-restore" } : item);
    render();
    return;
  }
  if (action === "record-add-param") {
    recordParams = [...recordParams, { name: he.record.defaultParamName, label: he.record.defaultParamLabel, example: "", required: true }];
    render();
    return;
  }
  if (action === "record-save") {
    recordName = document.getElementById("record-name")?.value || recordName || he.record.defaultName;
    recordGoal = document.getElementById("record-goal")?.value || recordGoal;
    const kept = reviewItems.filter((i) => i.kept);
    if (!kept.length) {
      flash = { kind: "err", text: he.flash.keepOneStep };
      render();
      return;
    }
    recordBusy = true;
    render();
    void send("bp-record-save", {
      payload: {
        name: recordName || he.record.defaultName,
        goal: recordGoal,
        review: reviewItems,
        parameters: recordParams
      }
    }).then(async (res) => {
      if (!res.ok) throw new Error(res.error || he.flash.saveFailed);
      recordBusy = false;
      flash = { kind: "ok", text: he.flash.savedLibrary };
      await refreshState();
      if (res.workflow?.id) {
        selectedId = res.workflow.id;
        view = "run";
        inputValues = {};
        for (const p of recordParams) {
          if (p.example) inputValues[p.name] = String(p.example);
        }
      }
      render();
    }).catch((err) => {
      recordBusy = false;
      flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
      render();
    });
    return;
  }
  if (action === "hitl-select") {
    hitlChoice = target.closest("[data-id]").dataset.id || null;
    render();
    return;
  }
  if (action === "hitl-confirm" || action === "hitl-cancel") {
    const candidate = action === "hitl-confirm" ? run?.hitl?.candidates.find((c) => c.id === hitlChoice) || null : null;
    hitlChoice = null;
    void send("bp-hitl-choice", { candidate }).then(() => void 0);
    return;
  }
});
document.addEventListener("change", (event) => {
  const el = event.target;
  if (el && el.id === "ext-market-source") {
    publishId = el.value;
    render();
    return;
  }
  const input = event.target;
  if (input?.id === "import-file" && input.files?.[0]) {
    const file = input.files[0];
    void file.text().then(async (json) => {
      const res = await send("bp-import", { json });
      if (!res.ok) throw new Error(res.error || he.flash.importFailed);
      flash = { kind: "ok", text: he.flash.imported };
      await refreshState();
      render();
    }).catch((err) => {
      flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
      render();
    });
  }
});
document.addEventListener("input", (event) => {
  const el = event.target;
  if (!el) return;
  if (el.id === "record-goal") recordGoal = el.value;
  if (el.id === "record-name") recordName = el.value;
  if (el.dataset.param != null && el.dataset.field) {
    const i = Number(el.dataset.param);
    const field = el.dataset.field;
    const next = { ...recordParams[i] };
    if (field === "required") next.required = el.type === "checkbox" ? el.checked : el.value === "true";
    else next[field] = el.value;
    recordParams = recordParams.map((p, idx) => idx === i ? next : p);
    return;
  }
  if (view !== "run") return;
  if (el.name) inputValues[el.name] = el.value;
});
document.addEventListener("change", (event) => {
  const el = event.target;
  if (!el || el.dataset.param == null || el.dataset.field !== "required") return;
  const i = Number(el.dataset.param);
  recordParams = recordParams.map((p, idx) => idx === i ? { ...p, required: el.checked } : p);
}, true);
document.addEventListener("submit", (event) => {
  const form = event.target;
  if (!form) return;
  event.preventDefault();
  if (form.id === "ext-publish-form") {
    const data = new FormData(form);
    const id = String(data.get("workflowId") || publishId || "");
    if (!id) return;
    const inputsRaw = String(data.get("inputs") || "").trim();
    let inputs;
    if (inputsRaw) {
      try {
        inputs = JSON.parse(inputsRaw);
        if (!Array.isArray(inputs)) throw new Error(he.flash.inputsMustBeArray);
      } catch (err) {
        flash = { kind: "err", text: err instanceof Error ? err.message : he.flash.inputsMustBeArray };
        render();
        return;
      }
    }
    const button = form.querySelector("button[type=submit]");
    if (button) button.disabled = true;
    void send("bp-publish", {
      id,
      name: String(data.get("name") || ""),
      description: String(data.get("description") || ""),
      inputs
    }).then(async (res) => {
      if (!res.ok) throw new Error(res.error || he.flash.publishFailed);
      const listing = res.listing;
      flash = { kind: "ok", text: he.flash.published(listing?.name || "workflow", listing?.version || "") };
      await refreshState();
      await loadMarket().catch(() => void 0);
      render();
    }).catch((err) => {
      flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
      render();
    });
    return;
  }
  if (form.id === "settings-form") {
    const data = new FormData(form);
    void send("bp-save-settings", {
      settings: {
        marketOrigin: String(data.get("marketOrigin") || DEFAULT_MARKET_ORIGIN),
        marketToken: String(data.get("marketToken") || ""),
        backendUrl: String(data.get("backendUrl") || DEFAULT_BACKEND_URL)
      }
    }).then(async (res) => {
      if (!res.ok) throw new Error(res.error || he.flash.settingsSaveFailed);
      await refreshState();
      flash = { kind: "ok", text: he.flash.settingsSaved };
      render();
    });
    return;
  }
  if (form.id === "run-form") {
    const wf = workflows.find((w) => w.id === selectedId);
    if (!wf) return;
    const inputs = deriveInputs(wf.definition);
    const data = new FormData(form);
    for (const [k, v] of data.entries()) inputValues[k] = String(v);
    const missing = missingRequired(inputs, inputValues);
    if (missing.length) {
      flash = { kind: "err", text: he.run.fillRequired(missing.map((n) => prettyLabel(n)).join(", ")) };
      render();
      return;
    }
    busy = true;
    render();
    void send("bp-run-workflow", { id: wf.id, values: inputValues }).then(async () => {
      await refreshState();
      busy = false;
      render();
    }).catch((err) => {
      busy = false;
      flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
      render();
    });
  }
});
chrome.runtime.onMessage.addListener((message) => {
  if (message && message.kind === "bp-run") {
    run = message.run;
    if (view === "run") render();
  }
  if (message && message.kind === "bp-record-state") {
    const rec = message.recording;
    if (rec) {
      recordingActive = rec.active;
      recordingCount = rec.count;
      if (view === "record" && !recordBusy) render();
    }
  }
});
void refreshState().then(() => render()).catch((err) => {
  flash = { kind: "err", text: err instanceof Error ? err.message : String(err) };
  render();
});
