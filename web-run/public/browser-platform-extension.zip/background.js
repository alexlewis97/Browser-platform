// src/lib/normalize.ts
var HEBREW_LO = 1425;
var HEBREW_HI = 1479;
var BIDI = /* @__PURE__ */ new Set([8206, 8207, 8234, 8235, 8236, 8237, 8238, 8294, 8295, 8296, 8297]);
var PUNCT_TO_SPACE = /[,;|/\-_·•]+/g;
var WS = /\s+/g;
var APOS = /['’`´]/g;
function isHebrewPoint(code) {
  return code >= HEBREW_LO && code <= HEBREW_HI;
}
function isArabicMark(code) {
  return code >= 1611 && code <= 1631 || code === 1648 || code >= 1750 && code <= 1772;
}
function stripMarks(text) {
  const decomposed = text.normalize("NFKD");
  let out = "";
  for (const ch of decomposed) {
    const code = ch.codePointAt(0) ?? 0;
    if (new RegExp("\\p{M}", "u").test(ch)) continue;
    if (isHebrewPoint(code) || isArabicMark(code) || BIDI.has(code)) continue;
    out += ch;
  }
  return out;
}
function normalizeText(text) {
  if (!text) return "";
  let value = String(text).normalize("NFKC");
  value = stripMarks(value);
  value = value.replace(APOS, "");
  value = value.replace(PUNCT_TO_SPACE, " ");
  value = value.replace(WS, " ").trim().toLocaleLowerCase();
  return value;
}
function nameVariants(text) {
  const raw = String(text || "").trim();
  const variants = /* @__PURE__ */ new Set();
  const norm = normalizeText(raw);
  if (norm) variants.add(norm);
  if (raw.includes(",")) {
    const parts = raw.split(",").map((p2) => p2.trim()).filter(Boolean);
    if (parts.length === 2) {
      const swapped = normalizeText(`${parts[1]} ${parts[0]}`);
      if (swapped) variants.add(swapped);
    }
  }
  const tokens = norm.split(" ").filter(Boolean);
  if (tokens.length >= 2) {
    variants.add([...tokens].reverse().join(" "));
    variants.add(`${tokens[tokens.length - 1]} ${tokens.slice(0, -1).join(" ")}`);
    variants.add(`${tokens.slice(1).join(" ")} ${tokens[0]}`);
    variants.add([...tokens].sort().join(" "));
  }
  return variants.size ? variants : /* @__PURE__ */ new Set([""]);
}

// src/lib/aliases.ts
function findAlias(aliases, stepIndex, query) {
  const qVars = nameVariants(query);
  const qNorm = normalizeText(query);
  for (const alias of aliases || []) {
    if (alias.step_index !== stepIndex) continue;
    const stored = /* @__PURE__ */ new Set([alias.query_normalized, normalizeText(alias.query), ...nameVariants(alias.query)]);
    if (stored.has(qNorm)) return alias;
    for (const v2 of qVars) {
      if (stored.has(v2)) return alias;
    }
  }
  return null;
}
function makeAlias(stepIndex, query, candidate) {
  return {
    step_index: stepIndex,
    query,
    query_normalized: normalizeText(query),
    chosen_text: candidate.text,
    chosen_id: candidate.id,
    cssSelector: !candidate.selector_type || candidate.selector_type === "css" ? candidate.selector : null,
    xpath: candidate.selector_type === "xpath" ? candidate.selector : null,
    role: candidate.role
  };
}
function aliasToStrategy(alias) {
  if (alias.cssSelector) return { type: "css", value: alias.cssSelector };
  if (alias.xpath) return { type: "xpath", value: alias.xpath };
  return { type: "text_exact", value: alias.chosen_text, metadata: alias.role ? { role: alias.role } : {} };
}

// src/lib/interpolate.ts
var BRACE = /\{\{?\s*([a-zA-Z_][\w]*)(?:\|([a-zA-Z0-9_]+(?::[^{}|]*)?))?\s*\}?\}/g;
function joinList(values, fmt, sep) {
  let itemFmt = fmt;
  if (fmt && (fmt === "join" || fmt.startsWith("join:"))) {
    sep = fmt.includes(":") ? fmt.slice(fmt.indexOf(":") + 1) : sep;
    itemFmt = void 0;
  }
  return values.filter((v2) => v2 != null && String(v2).trim()).map((v2) => formatValue(String(v2), itemFmt)).join(sep);
}
function pathSlug(value) {
  return String(value || "").trim().replace(/\s+/g, "-").toLowerCase();
}
function formatValue(value, fmt) {
  const text = String(value || "");
  if (!fmt) return text;
  if (fmt === "slug") return pathSlug(text);
  if (fmt === "slug_" || fmt === "underscore") return text.trim().replace(/\s+/g, "_").toLowerCase();
  if (fmt === "head") {
    const tokens = text.trim().split(/\W+/).filter(Boolean);
    return (tokens[0] || text).toLowerCase();
  }
  return text;
}
function interpolate(value, variables, listSep = ", ") {
  if (!variables || typeof value !== "string") return value;
  return value.replace(BRACE, (match, key, fmt) => {
    if (Object.prototype.hasOwnProperty.call(variables, key) && variables[key] != null) {
      const found = variables[key];
      if (Array.isArray(found)) return joinList(found, fmt, listSep);
      if (fmt && (fmt === "join" || fmt.startsWith("join:"))) fmt = void 0;
      return formatValue(String(found), fmt);
    }
    return match;
  });
}
function interpolateUrl(url, variables) {
  if (typeof url !== "string") return interpolate(url, variables);
  let updated = interpolate(url, variables, ",");
  if (typeof updated === "string" && updated.includes("?")) {
    const [base, query] = [updated.slice(0, updated.indexOf("?")), updated.slice(updated.indexOf("?") + 1)];
    const kept = query.split("&").filter((pair) => pair && !/^[^=]+=(\{[^}]*\})?$/.test(pair));
    updated = base + (kept.length ? "?" + kept.join("&") : "");
  }
  if (typeof updated !== "string" || !variables) return updated;
  try {
    const parsed = new URL(updated);
    const host = parsed.hostname.toLowerCase();
    if (host.includes("wikipedia.org") || host.includes("wikimedia.org")) return updated;
    const rawValues = Object.values(variables).filter((v2) => v2 != null && !Array.isArray(v2) && String(v2).trim()).map((v2) => String(v2).trim());
    const parts = parsed.pathname.split("/");
    let changed = false;
    for (let i2 = 0; i2 < parts.length; i2 += 1) {
      const part = parts[i2];
      if (!part) continue;
      const decoded = decodeURIComponent(part);
      for (const text of rawValues) {
        const candidates = /* @__PURE__ */ new Set([text, text.replaceAll(" ", "_"), text.replaceAll(" ", "-"), text.replaceAll(" ", "+")]);
        const lowered = new Set([...candidates].map((item) => item.toLowerCase()));
        if (candidates.has(decoded) || lowered.has(decoded.toLowerCase())) {
          const slug = pathSlug(text);
          if (parts[i2] !== slug) {
            parts[i2] = slug;
            changed = true;
          }
          break;
        }
      }
    }
    if (!changed) return updated;
    parsed.pathname = parts.join("/");
    return parsed.toString();
  } catch {
    return updated;
  }
}
function placeholdersIn(value, found = []) {
  if (typeof value === "string") {
    const re2 = new RegExp(BRACE.source, "g");
    let match;
    while (match = re2.exec(value)) {
      if (!found.includes(match[1])) found.push(match[1]);
    }
  } else if (Array.isArray(value)) {
    for (const item of value) placeholdersIn(item, found);
  } else if (value && typeof value === "object") {
    for (const item of Object.values(value)) placeholdersIn(item, found);
  }
  return found;
}

// src/lib/inputs.ts
var LABELS = {
  term: "Search term",
  query: "Search query",
  q: "Search query",
  search: "Search term",
  name: "Name",
  status: "Status",
  url: "URL",
  email: "Email",
  title: "Title"
};
function prettyLabel(name, label) {
  if (label && label.trim()) return label.trim();
  const key = (name || "").trim();
  if (LABELS[key.toLowerCase()]) return LABELS[key.toLowerCase()];
  const text = key.replaceAll("_", " ").trim();
  return text ? text[0].toUpperCase() + text.slice(1) : "Input";
}
function deriveInputs(definition) {
  const byName = /* @__PURE__ */ new Map();
  for (const item of definition.input_schema || []) {
    if (!item?.name) continue;
    byName.set(item.name, { ...item, label: prettyLabel(item.name, item.label) });
  }
  for (const name of placeholdersIn(definition)) {
    if (byName.has(name)) continue;
    byName.set(name, { name, type: "string", required: true, label: prettyLabel(name) });
  }
  return [...byName.values()];
}

// src/lib/types.ts
var DEFAULT_MARKET_ORIGIN = "https://browser-platform-web.vercel.app";
var DEFAULT_BACKEND_URL = "https://browser.129-159-156-75.sslip.io";
var DEFAULT_FUZZY = {
  enabled: true,
  threshold: 90,
  margin: 8,
  top_n: 5
};

// src/lib/storage.ts
var SETTINGS = "bp.settings";
var WORKFLOWS = "bp.workflows";
var INPUTS = "bp.lastInputs";
async function loadSettings() {
  const raw = await chrome.storage.local.get(SETTINGS);
  const s2 = raw[SETTINGS] || {};
  return {
    marketToken: String(s2.marketToken || ""),
    marketOrigin: String(s2.marketOrigin || DEFAULT_MARKET_ORIGIN).replace(/\/+$/, ""),
    backendUrl: String(s2.backendUrl || DEFAULT_BACKEND_URL).replace(/\/+$/, "")
  };
}
async function saveSettings(next) {
  await chrome.storage.local.set({
    [SETTINGS]: {
      marketToken: next.marketToken.trim(),
      marketOrigin: (next.marketOrigin || DEFAULT_MARKET_ORIGIN).replace(/\/+$/, ""),
      backendUrl: (next.backendUrl || DEFAULT_BACKEND_URL).replace(/\/+$/, "")
    }
  });
}
async function listInstalled() {
  const raw = await chrome.storage.local.get(WORKFLOWS);
  const map = raw[WORKFLOWS] || {};
  return Object.values(map).sort((a2, b3) => b3.installedAt.localeCompare(a2.installedAt));
}
async function getInstalled(id) {
  const raw = await chrome.storage.local.get(WORKFLOWS);
  const map = raw[WORKFLOWS] || {};
  return map[id] || null;
}
async function putInstalled(item) {
  const raw = await chrome.storage.local.get(WORKFLOWS);
  const map = raw[WORKFLOWS] || {};
  map[item.id] = item;
  await chrome.storage.local.set({ [WORKFLOWS]: map });
}
async function removeInstalled(id) {
  const raw = await chrome.storage.local.get(WORKFLOWS);
  const map = raw[WORKFLOWS] || {};
  delete map[id];
  await chrome.storage.local.set({ [WORKFLOWS]: map });
}
async function loadLastInputs(workflowId) {
  const raw = await chrome.storage.local.get(INPUTS);
  const map = raw[INPUTS] || {};
  return { ...map[workflowId] || {} };
}
async function saveLastInputs(workflowId, values) {
  const raw = await chrome.storage.local.get(INPUTS);
  const map = raw[INPUTS] || {};
  const clean = {};
  for (const [k2, v2] of Object.entries(values)) {
    if (k2 && String(v2).trim()) clean[k2] = String(v2);
  }
  if (Object.keys(clean).length) map[workflowId] = clean;
  else delete map[workflowId];
  await chrome.storage.local.set({ [INPUTS]: map });
}

// src/lib/market.ts
var MarketError = class extends Error {
  status;
  constructor(status, message) {
    super(message);
    this.status = status;
  }
};
async function request(path, init = {}) {
  const settings = await loadSettings();
  const headers = new Headers(init.headers);
  if (settings.marketToken) headers.set("X-Browser-Platform-Token", settings.marketToken);
  const res = await fetch(`${settings.marketOrigin}${path}`, { ...init, headers });
  if (!res.ok) {
    let detail = `Marketplace request failed (${res.status})`;
    try {
      const data = await res.clone().json();
      if (data && typeof data === "object" && "error" in data) detail = String(data.error);
    } catch {
    }
    if (res.status === 401) detail = "Marketplace is private. Add the site access token in Settings.";
    throw new MarketError(res.status, detail);
  }
  return res;
}
async function listMarket() {
  const res = await request("/api/market");
  const data = await res.json();
  return data.listings || [];
}
async function downloadPackage(id) {
  const res = await request(`/api/market/${encodeURIComponent(id)}/package`);
  return { bytes: await res.arrayBuffer(), sha256Header: res.headers.get("x-package-sha256") };
}
async function sha256Hex(data) {
  const buf = data instanceof Uint8Array ? data : new Uint8Array(data);
  const copy = new Uint8Array(buf.byteLength);
  copy.set(buf);
  const digest = await crypto.subtle.digest("SHA-256", copy);
  return Array.from(new Uint8Array(digest)).map((b3) => b3.toString(16).padStart(2, "0")).join("");
}
function listingIdForName(name) {
  const slug = name.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);
  return slug || "listing";
}
async function publishWorkflow(payload) {
  const res = await request("/api/market", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
  const data = await res.json();
  return data.listing;
}

// node_modules/fflate/esm/browser.js
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]);
var fdeb = new u8([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]);
var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var freb = function(eb, start) {
  var b3 = new u16(31);
  for (var i2 = 0; i2 < 31; ++i2) {
    b3[i2] = start += 1 << eb[i2 - 1];
  }
  var r2 = new i32(b3[30]);
  for (var i2 = 1; i2 < 30; ++i2) {
    for (var j2 = b3[i2]; j2 < b3[i2 + 1]; ++j2) {
      r2[j2] = j2 - b3[i2] << 5 | i2;
    }
  }
  return { b: b3, r: r2 };
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (i2 = 0; i2 < 32768; ++i2) {
  x2 = (i2 & 43690) >> 1 | (i2 & 21845) << 1;
  x2 = (x2 & 52428) >> 2 | (x2 & 13107) << 2;
  x2 = (x2 & 61680) >> 4 | (x2 & 3855) << 4;
  rev[i2] = ((x2 & 65280) >> 8 | (x2 & 255) << 8) >> 1;
}
var x2;
var i2;
var hMap = (function(cd, mb, r2) {
  var s2 = cd.length;
  var i2 = 0;
  var l2 = new u16(mb);
  for (; i2 < s2; ++i2) {
    if (cd[i2])
      ++l2[cd[i2] - 1];
  }
  var le2 = new u16(mb);
  for (i2 = 1; i2 < mb; ++i2) {
    le2[i2] = le2[i2 - 1] + l2[i2 - 1] << 1;
  }
  var co2;
  if (r2) {
    co2 = new u16(1 << mb);
    var rvb = 15 - mb;
    for (i2 = 0; i2 < s2; ++i2) {
      if (cd[i2]) {
        var sv = i2 << 4 | cd[i2];
        var r_1 = mb - cd[i2];
        var v2 = le2[cd[i2] - 1]++ << r_1;
        for (var m2 = v2 | (1 << r_1) - 1; v2 <= m2; ++v2) {
          co2[rev[v2] >> rvb] = sv;
        }
      }
    }
  } else {
    co2 = new u16(s2);
    for (i2 = 0; i2 < s2; ++i2) {
      if (cd[i2]) {
        co2[i2] = rev[le2[cd[i2] - 1]++] >> 15 - cd[i2];
      }
    }
  }
  return co2;
});
var flt = new u8(288);
for (i2 = 0; i2 < 144; ++i2)
  flt[i2] = 8;
var i2;
for (i2 = 144; i2 < 256; ++i2)
  flt[i2] = 9;
var i2;
for (i2 = 256; i2 < 280; ++i2)
  flt[i2] = 7;
var i2;
for (i2 = 280; i2 < 288; ++i2)
  flt[i2] = 8;
var i2;
var fdt = new u8(32);
for (i2 = 0; i2 < 32; ++i2)
  fdt[i2] = 5;
var i2;
var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
var max = function(a2) {
  var m2 = a2[0];
  for (var i2 = 1; i2 < a2.length; ++i2) {
    if (a2[i2] > m2)
      m2 = a2[i2];
  }
  return m2;
};
var bits = function(d2, p2, m2) {
  var o2 = p2 / 8 | 0;
  return (d2[o2] | d2[o2 + 1] << 8) >> (p2 & 7) & m2;
};
var bits16 = function(d2, p2) {
  var o2 = p2 / 8 | 0;
  return (d2[o2] | d2[o2 + 1] << 8 | d2[o2 + 2] << 16) >> (p2 & 7);
};
var shft = function(p2) {
  return (p2 + 7) / 8 | 0;
};
var slc = function(v2, s2, e2) {
  if (s2 == null || s2 < 0)
    s2 = 0;
  if (e2 == null || e2 > v2.length)
    e2 = v2.length;
  return new u8(v2.subarray(s2, e2));
};
var ec = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
];
var err = function(ind, msg, nt2) {
  var e2 = new Error(msg || ec[ind]);
  e2.code = ind;
  if (Error.captureStackTrace)
    Error.captureStackTrace(e2, err);
  if (!nt2)
    throw e2;
  return e2;
};
var inflt = function(dat, st2, buf, dict) {
  var sl = dat.length, dl = dict ? dict.length : 0;
  if (!sl || st2.f && !st2.l)
    return buf || new u8(0);
  var noBuf = !buf;
  var resize = noBuf || st2.i != 2;
  var noSt = st2.i;
  if (noBuf)
    buf = new u8(sl * 3);
  var cbuf = function(l3) {
    var bl = buf.length;
    if (l3 > bl) {
      var nbuf = new u8(Math.max(bl * 2, l3));
      nbuf.set(buf);
      buf = nbuf;
    }
  };
  var final = st2.f || 0, pos = st2.p || 0, bt2 = st2.b || 0, lm = st2.l, dm = st2.d, lbt = st2.m, dbt = st2.n;
  var tbts = sl * 8;
  do {
    if (!lm) {
      final = bits(dat, pos, 1);
      var type = bits(dat, pos + 1, 3);
      pos += 3;
      if (!type) {
        var s2 = shft(pos) + 4, l2 = dat[s2 - 4] | dat[s2 - 3] << 8, t2 = s2 + l2;
        if (t2 > sl) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt2 + l2);
        buf.set(dat.subarray(s2, t2), bt2);
        st2.b = bt2 += l2, st2.p = pos = t2 * 8, st2.f = final;
        continue;
      } else if (type == 1)
        lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
      else if (type == 2) {
        var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
        var tl = hLit + bits(dat, pos + 5, 31) + 1;
        pos += 14;
        var ldt = new u8(tl);
        var clt = new u8(19);
        for (var i2 = 0; i2 < hcLen; ++i2) {
          clt[clim[i2]] = bits(dat, pos + i2 * 3, 7);
        }
        pos += hcLen * 3;
        var clb = max(clt), clbmsk = (1 << clb) - 1;
        var clm = hMap(clt, clb, 1);
        for (var i2 = 0; i2 < tl; ) {
          var r2 = clm[bits(dat, pos, clbmsk)];
          pos += r2 & 15;
          var s2 = r2 >> 4;
          if (s2 < 16) {
            ldt[i2++] = s2;
          } else {
            var c2 = 0, n2 = 0;
            if (s2 == 16)
              n2 = 3 + bits(dat, pos, 3), pos += 2, c2 = ldt[i2 - 1];
            else if (s2 == 17)
              n2 = 3 + bits(dat, pos, 7), pos += 3;
            else if (s2 == 18)
              n2 = 11 + bits(dat, pos, 127), pos += 7;
            while (n2--)
              ldt[i2++] = c2;
          }
        }
        var lt2 = ldt.subarray(0, hLit), dt2 = ldt.subarray(hLit);
        lbt = max(lt2);
        dbt = max(dt2);
        lm = hMap(lt2, lbt, 1);
        dm = hMap(dt2, dbt, 1);
      } else
        err(1);
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
    }
    if (resize)
      cbuf(bt2 + 131072);
    var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
    var lpos = pos;
    for (; ; lpos = pos) {
      var c2 = lm[bits16(dat, pos) & lms], sym = c2 >> 4;
      pos += c2 & 15;
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
      if (!c2)
        err(2);
      if (sym < 256)
        buf[bt2++] = sym;
      else if (sym == 256) {
        lpos = pos, lm = null;
        break;
      } else {
        var add = sym - 254;
        if (sym > 264) {
          var i2 = sym - 257, b3 = fleb[i2];
          add = bits(dat, pos, (1 << b3) - 1) + fl[i2];
          pos += b3;
        }
        var d2 = dm[bits16(dat, pos) & dms], dsym = d2 >> 4;
        if (!d2)
          err(3);
        pos += d2 & 15;
        var dt2 = fd[dsym];
        if (dsym > 3) {
          var b3 = fdeb[dsym];
          dt2 += bits16(dat, pos) & (1 << b3) - 1, pos += b3;
        }
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt2 + 131072);
        var end = bt2 + add;
        if (bt2 < dt2) {
          var shift = dl - dt2, dend = Math.min(dt2, end);
          if (shift + bt2 < 0)
            err(3);
          for (; bt2 < dend; ++bt2)
            buf[bt2] = dict[shift + bt2];
        }
        for (; bt2 < end; ++bt2)
          buf[bt2] = buf[bt2 - dt2];
      }
    }
    st2.l = lm, st2.p = lpos, st2.b = bt2, st2.f = final;
    if (lm)
      final = 1, st2.m = lbt, st2.d = dm, st2.n = dbt;
  } while (!final);
  return bt2 != buf.length && noBuf ? slc(buf, 0, bt2) : buf.subarray(0, bt2);
};
var et = /* @__PURE__ */ new u8(0);
var b2 = function(d2, b3) {
  return d2[b3] | d2[b3 + 1] << 8;
};
var b4 = function(d2, b3) {
  return (d2[b3] | d2[b3 + 1] << 8 | d2[b3 + 2] << 16 | d2[b3 + 3] << 24) >>> 0;
};
var b8 = function(d2, b3) {
  return b4(d2, b3) + b4(d2, b3 + 4) * 4294967296;
};
function inflateSync(data, opts) {
  return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
var tds = 0;
try {
  td.decode(et, { stream: true });
  tds = 1;
} catch (e2) {
}
var dutf8 = function(d2) {
  for (var r2 = "", i2 = 0; ; ) {
    var c2 = d2[i2++];
    var eb = (c2 > 127) + (c2 > 223) + (c2 > 239);
    if (i2 + eb > d2.length)
      return { s: r2, r: slc(d2, i2 - 1) };
    if (!eb)
      r2 += String.fromCharCode(c2);
    else if (eb == 3) {
      c2 = ((c2 & 15) << 18 | (d2[i2++] & 63) << 12 | (d2[i2++] & 63) << 6 | d2[i2++] & 63) - 65536, r2 += String.fromCharCode(55296 | c2 >> 10, 56320 | c2 & 1023);
    } else if (eb & 1)
      r2 += String.fromCharCode((c2 & 31) << 6 | d2[i2++] & 63);
    else
      r2 += String.fromCharCode((c2 & 15) << 12 | (d2[i2++] & 63) << 6 | d2[i2++] & 63);
  }
};
function strFromU8(dat, latin1) {
  if (latin1) {
    var r2 = "";
    for (var i2 = 0; i2 < dat.length; i2 += 16384)
      r2 += String.fromCharCode.apply(null, dat.subarray(i2, i2 + 16384));
    return r2;
  } else if (td) {
    return td.decode(dat);
  } else {
    var _a2 = dutf8(dat), s2 = _a2.s, r2 = _a2.r;
    if (r2.length)
      err(8);
    return s2;
  }
}
var slzh = function(d2, b3) {
  return b3 + 30 + b2(d2, b3 + 26) + b2(d2, b3 + 28);
};
var zh = function(d2, b3, z2) {
  var fnl = b2(d2, b3 + 28), efl = b2(d2, b3 + 30), fn2 = strFromU8(d2.subarray(b3 + 46, b3 + 46 + fnl), !(b2(d2, b3 + 8) & 2048)), es = b3 + 46 + fnl;
  var _a2 = z64hs(d2, es, efl, z2, b4(d2, b3 + 20), b4(d2, b3 + 24), b4(d2, b3 + 42)), sc = _a2[0], su = _a2[1], off = _a2[2];
  return [b2(d2, b3 + 10), sc, su, fn2, es + efl + b2(d2, b3 + 32), off];
};
var z64hs = function(d2, b3, l2, z2, sc, su, off) {
  var nsc = sc == 4294967295, nsu = su == 4294967295, noff = off == 4294967295, e2 = b3 + l2;
  var nf = nsc + nsu + noff;
  if (z2 && nf) {
    for (; b3 + 4 < e2; b3 += 4 + b2(d2, b3 + 2)) {
      if (b2(d2, b3) == 1) {
        return [
          nsc ? b8(d2, b3 + 4 + 8 * nsu) : sc,
          nsu ? b8(d2, b3 + 4) : su,
          noff ? b8(d2, b3 + 4 + 8 * (nsu + nsc)) : off,
          1
        ];
      }
    }
    if (z2 < 2)
      err(13);
  }
  return [sc, su, off, 0];
};
function unzipSync(data, opts) {
  var files = {};
  var e2 = data.length - 22;
  for (; b4(data, e2) != 101010256; --e2) {
    if (!e2 || data.length - e2 > 65558)
      err(13);
  }
  ;
  var c2 = b2(data, e2 + 8);
  if (!c2)
    return {};
  var o2 = b4(data, e2 + 16);
  var z2 = b4(data, e2 - 20) == 117853008;
  if (z2) {
    var ze2 = b4(data, e2 - 12);
    z2 = b4(data, ze2) == 101075792;
    if (z2) {
      c2 = b4(data, ze2 + 32);
      o2 = b4(data, ze2 + 48);
    }
  }
  var fltr = opts && opts.filter;
  for (var i2 = 0; i2 < c2; ++i2) {
    var _a2 = zh(data, o2, z2), c_2 = _a2[0], sc = _a2[1], su = _a2[2], fn2 = _a2[3], no2 = _a2[4], off = _a2[5], b3 = slzh(data, off);
    o2 = no2;
    if (!fltr || fltr({
      name: fn2,
      size: sc,
      originalSize: su,
      compression: c_2
    })) {
      if (!c_2)
        files[fn2] = slc(data, b3, b3 + sc);
      else if (c_2 == 8)
        files[fn2] = inflateSync(data.subarray(b3, b3 + sc), { out: new u8(su) });
      else
        err(14, "unknown compression type " + c_2);
    }
  }
  return files;
}

// src/lib/package.ts
function parseWorkflowPackage(bytes) {
  const files = unzipSync(bytes);
  const names = Object.keys(files).filter((n2) => !n2.endsWith("/") && !n2.includes("__MACOSX"));
  const preferred = names.find((n2) => n2.endsWith("workflow.json") || n2.endsWith(".workflow.json")) || names.find((n2) => n2.endsWith("manifest.json") && names.some((x2) => x2.includes("workflow"))) || names.find((n2) => n2.toLowerCase().endsWith(".json") && !n2.endsWith("manifest.json"));
  const manifestName = names.find((n2) => n2.split("/").pop() === "manifest.json");
  let path = preferred || "";
  if (manifestName) {
    try {
      const manifest = JSON.parse(strFromU8(files[manifestName]));
      const rel = manifest.workflow || manifest.definition;
      if (rel) {
        const hit = names.find((n2) => n2 === rel || n2.endsWith("/" + rel) || n2.endsWith(rel));
        if (hit) path = hit;
      }
    } catch {
    }
  }
  if (!path) {
    throw new Error("Package does not contain a workflow JSON file.");
  }
  const raw = JSON.parse(strFromU8(files[path]));
  const definition = raw.definition && typeof raw.definition === "object" ? raw.definition : raw;
  if (!definition?.name || !Array.isArray(definition.steps)) {
    throw new Error("workflow JSON is missing name or steps.");
  }
  return { definition, path };
}
function parseWorkflowJson(text) {
  const raw = JSON.parse(text);
  const definition = raw.definition && typeof raw.definition === "object" ? raw.definition : raw;
  if (!definition?.name || !Array.isArray(definition.steps)) {
    throw new Error("workflow JSON is missing name or steps.");
  }
  return definition;
}

// node_modules/fuzzball/dist/esm/fuzzball.esm.min.js
var e;
var t = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
var r = { exports: {} };
var n = Math.floor;
var o = Math.max;
var a = Math.min;
var _calculateRatio = function(e2, t2) {
  return t2 ? 2 * e2 / t2 : 1;
};
var _arrayCmp = function(e2, t2) {
  var r2, n2, o2, i2, s2, c2;
  for (s2 = [e2.length, t2.length], r2 = i2 = 0, c2 = a(n2 = s2[0], o2 = s2[1]); 0 <= c2 ? i2 < c2 : i2 > c2; r2 = 0 <= c2 ? ++i2 : --i2) {
    if (e2[r2] < t2[r2]) return -1;
    if (e2[r2] > t2[r2]) return 1;
  }
  return n2 - o2;
};
var _has = function(e2, t2) {
  return Object.prototype.hasOwnProperty.call(e2, t2);
};
var i = (function() {
  function SequenceMatcher(e2, t2, r2, n2) {
    this.isjunk = e2, null == t2 && (t2 = ""), null == r2 && (r2 = ""), this.autojunk = null == n2 || n2, this.a = this.b = null, this.setSeqs(t2, r2);
  }
  return SequenceMatcher.prototype.setSeqs = function(e2, t2) {
    return this.setSeq1(e2), this.setSeq2(t2);
  }, SequenceMatcher.prototype.setSeq1 = function(e2) {
    if (e2 !== this.a) return this.a = e2, this.matchingBlocks = this.opcodes = null;
  }, SequenceMatcher.prototype.setSeq2 = function(e2) {
    if (e2 !== this.b) return this.b = e2, this.matchingBlocks = this.opcodes = null, this.fullbcount = null, this._chainB();
  }, SequenceMatcher.prototype._chainB = function() {
    var e2, t2, r2, o2, a2, i2, s2, c2, u2, l2, f2, p2, h2, v2;
    for (e2 = this.b, this.b2j = t2 = {}, o2 = l2 = 0, p2 = e2.length; l2 < p2; o2 = ++l2) r2 = e2[o2], (_has(t2, r2) ? t2[r2] : t2[r2] = []).push(o2);
    if (i2 = {}, a2 = this.isjunk) for (f2 = 0, h2 = (v2 = Object.keys(t2)).length; f2 < h2; f2++) a2(r2 = v2[f2]) && (i2[r2] = true, delete t2[r2]);
    if (u2 = {}, s2 = e2.length, this.autojunk && s2 >= 200) for (r2 in c2 = n(s2 / 100) + 1, t2) t2[r2].length > c2 && (u2[r2] = true, delete t2[r2]);
    return this.isbjunk = function(e3) {
      return _has(i2, e3);
    }, this.isbpopular = function(e3) {
      return _has(u2, e3);
    };
  }, SequenceMatcher.prototype.findLongestMatch = function(e2, t2, r2, n2) {
    var o2, a2, i2, s2, c2, u2, l2, f2, p2, h2, v2, _2, d2, y2, g2, m2, b3, k2, j2, $2, w2;
    for (o2 = (m2 = [this.a, this.b, this.b2j, this.isbjunk])[0], a2 = m2[1], i2 = m2[2], f2 = m2[3], s2 = (b3 = [e2, r2, 0])[0], c2 = b3[1], u2 = b3[2], h2 = {}, l2 = d2 = e2; e2 <= t2 ? d2 < t2 : d2 > t2; l2 = e2 <= t2 ? ++d2 : --d2) {
      for (_2 = {}, y2 = 0, g2 = (k2 = _has(i2, o2[l2]) ? i2[o2[l2]] : []).length; y2 < g2; y2++) if (!((p2 = k2[y2]) < r2)) {
        if (p2 >= n2) break;
        (v2 = _2[p2] = (h2[p2 - 1] || 0) + 1) > u2 && (s2 = (j2 = [l2 - v2 + 1, p2 - v2 + 1, v2])[0], c2 = j2[1], u2 = j2[2]);
      }
      h2 = _2;
    }
    for (; s2 > e2 && c2 > r2 && !f2(a2[c2 - 1]) && o2[s2 - 1] === a2[c2 - 1]; ) s2 = ($2 = [s2 - 1, c2 - 1, u2 + 1])[0], c2 = $2[1], u2 = $2[2];
    for (; s2 + u2 < t2 && c2 + u2 < n2 && !f2(a2[c2 + u2]) && o2[s2 + u2] === a2[c2 + u2]; ) u2++;
    for (; s2 > e2 && c2 > r2 && f2(a2[c2 - 1]) && o2[s2 - 1] === a2[c2 - 1]; ) s2 = (w2 = [s2 - 1, c2 - 1, u2 + 1])[0], c2 = w2[1], u2 = w2[2];
    for (; s2 + u2 < t2 && c2 + u2 < n2 && f2(a2[c2 + u2]) && o2[s2 + u2] === a2[c2 + u2]; ) u2++;
    return [s2, c2, u2];
  }, SequenceMatcher.prototype.getMatchingBlocks = function() {
    var e2, t2, r2, n2, o2, a2, i2, s2, c2, u2, l2, f2, p2, h2, v2, _2, d2, y2, g2, m2, b3, k2, j2, $2, w2, O2;
    if (this.matchingBlocks) return this.matchingBlocks;
    for (y2 = [[0, h2 = (k2 = [this.a.length, this.b.length])[0], 0, v2 = k2[1]]], _2 = []; y2.length; ) t2 = (j2 = y2.pop())[0], e2 = j2[1], n2 = j2[2], r2 = j2[3], o2 = ($2 = g2 = this.findLongestMatch(t2, e2, n2, r2))[0], s2 = $2[1], (l2 = $2[2]) && (_2.push(g2), t2 < o2 && n2 < s2 && y2.push([t2, o2, n2, s2]), o2 + l2 < e2 && s2 + l2 < r2 && y2.push([o2 + l2, e2, s2 + l2, r2]));
    for (_2.sort(_arrayCmp), a2 = c2 = f2 = 0, d2 = [], m2 = 0, b3 = _2.length; m2 < b3; m2++) i2 = (w2 = _2[m2])[0], u2 = w2[1], p2 = w2[2], a2 + f2 === i2 && c2 + f2 === u2 ? f2 += p2 : (f2 && d2.push([a2, c2, f2]), a2 = (O2 = [i2, u2, p2])[0], c2 = O2[1], f2 = O2[2]);
    return f2 && d2.push([a2, c2, f2]), d2.push([h2, v2, 0]), this.matchingBlocks = d2;
  }, SequenceMatcher.prototype.getOpcodes = function() {
    var e2, t2, r2, n2, o2, a2, i2, s2, c2, u2, l2, f2;
    if (this.opcodes) return this.opcodes;
    for (n2 = o2 = 0, this.opcodes = t2 = [], s2 = 0, c2 = (u2 = this.getMatchingBlocks()).length; s2 < c2; s2++) e2 = (l2 = u2[s2])[0], r2 = l2[1], a2 = l2[2], i2 = "", n2 < e2 && o2 < r2 ? i2 = "replace" : n2 < e2 ? i2 = "delete" : o2 < r2 && (i2 = "insert"), i2 && t2.push([i2, n2, e2, o2, r2]), n2 = (f2 = [e2 + a2, r2 + a2])[0], o2 = f2[1], a2 && t2.push(["equal", e2, n2, r2, o2]);
    return t2;
  }, SequenceMatcher.prototype.getGroupedOpcodes = function(e2) {
    var t2, r2, n2, i2, s2, c2, u2, l2, f2, p2, h2, v2, _2, d2, y2;
    for (null == e2 && (e2 = 3), (t2 = this.getOpcodes()).length || (t2 = [["equal", 0, 1, 0, 1]]), "equal" === t2[0][0] && (f2 = (v2 = t2[0])[0], i2 = v2[1], s2 = v2[2], c2 = v2[3], u2 = v2[4], t2[0] = [f2, o(i2, s2 - e2), s2, o(c2, u2 - e2), u2]), "equal" === t2[t2.length - 1][0] && (f2 = (_2 = t2[t2.length - 1])[0], i2 = _2[1], s2 = _2[2], c2 = _2[3], u2 = _2[4], t2[t2.length - 1] = [f2, i2, a(s2, i2 + e2), c2, a(u2, c2 + e2)]), l2 = e2 + e2, n2 = [], r2 = [], p2 = 0, h2 = t2.length; p2 < h2; p2++) f2 = (d2 = t2[p2])[0], i2 = d2[1], s2 = d2[2], c2 = d2[3], u2 = d2[4], "equal" === f2 && s2 - i2 > l2 && (r2.push([f2, i2, a(s2, i2 + e2), c2, a(u2, c2 + e2)]), n2.push(r2), r2 = [], i2 = (y2 = [o(i2, s2 - e2), o(c2, u2 - e2)])[0], c2 = y2[1]), r2.push([f2, i2, s2, c2, u2]);
    return !r2.length || 1 === r2.length && "equal" === r2[0][0] || n2.push(r2), n2;
  }, SequenceMatcher.prototype.ratio = function() {
    var e2, t2, r2, n2;
    for (e2 = 0, t2 = 0, r2 = (n2 = this.getMatchingBlocks()).length; t2 < r2; t2++) e2 += n2[t2][2];
    return _calculateRatio(e2, this.a.length + this.b.length);
  }, SequenceMatcher.prototype.quickRatio = function() {
    var e2, t2, r2, n2, o2, a2, i2, s2, c2, u2, l2;
    if (!this.fullbcount) for (this.fullbcount = r2 = {}, a2 = 0, s2 = (u2 = this.b).length; a2 < s2; a2++) r2[t2 = u2[a2]] = (r2[t2] || 0) + 1;
    for (r2 = this.fullbcount, e2 = {}, n2 = 0, i2 = 0, c2 = (l2 = this.a).length; i2 < c2; i2++) t2 = l2[i2], o2 = _has(e2, t2) ? e2[t2] : r2[t2] || 0, e2[t2] = o2 - 1, o2 > 0 && n2++;
    return _calculateRatio(n2, this.a.length + this.b.length);
  }, SequenceMatcher.prototype.realQuickRatio = function() {
    var e2, t2, r2;
    return r2 = [this.a.length, this.b.length], _calculateRatio(a(e2 = r2[0], t2 = r2[1]), e2 + t2);
  }, SequenceMatcher;
})();
var s = { exports: {} };
e = s, function() {
  var t2, r2, n2, o2, a2, i2, s2, c2, u2, l2, f2, p2, h2, v2, _2;
  n2 = Math.floor, l2 = Math.min, r2 = function(e2, t3) {
    return e2 < t3 ? -1 : e2 > t3 ? 1 : 0;
  }, u2 = function(e2, t3, o3, a3, i3) {
    var s3;
    if (null == o3 && (o3 = 0), null == i3 && (i3 = r2), o3 < 0) throw new Error("lo must be non-negative");
    for (null == a3 && (a3 = e2.length); o3 < a3; ) i3(t3, e2[s3 = n2((o3 + a3) / 2)]) < 0 ? a3 = s3 : o3 = s3 + 1;
    return [].splice.apply(e2, [o3, o3 - o3].concat(t3)), t3;
  }, i2 = function(e2, t3, n3) {
    return null == n3 && (n3 = r2), e2.push(t3), v2(e2, 0, e2.length - 1, n3);
  }, a2 = function(e2, t3) {
    var n3, o3;
    return null == t3 && (t3 = r2), n3 = e2.pop(), e2.length ? (o3 = e2[0], e2[0] = n3, _2(e2, 0, t3)) : o3 = n3, o3;
  }, c2 = function(e2, t3, n3) {
    var o3;
    return null == n3 && (n3 = r2), o3 = e2[0], e2[0] = t3, _2(e2, 0, n3), o3;
  }, s2 = function(e2, t3, n3) {
    var o3;
    return null == n3 && (n3 = r2), e2.length && n3(e2[0], t3) < 0 && (t3 = (o3 = [e2[0], t3])[0], e2[0] = o3[1], _2(e2, 0, n3)), t3;
  }, o2 = function(e2, t3) {
    var o3, a3, i3, s3, c3, u3;
    for (null == t3 && (t3 = r2), c3 = [], a3 = 0, i3 = (s3 = function() {
      u3 = [];
      for (var t4 = 0, r3 = n2(e2.length / 2); 0 <= r3 ? t4 < r3 : t4 > r3; 0 <= r3 ? t4++ : t4--) u3.push(t4);
      return u3;
    }.apply(this).reverse()).length; a3 < i3; a3++) o3 = s3[a3], c3.push(_2(e2, o3, t3));
    return c3;
  }, h2 = function(e2, t3, n3) {
    var o3;
    if (null == n3 && (n3 = r2), -1 !== (o3 = e2.indexOf(t3))) return v2(e2, 0, o3, n3), _2(e2, o3, n3);
  }, f2 = function(e2, t3, n3) {
    var a3, i3, c3, u3, l3;
    if (null == n3 && (n3 = r2), !(i3 = e2.slice(0, t3)).length) return i3;
    for (o2(i3, n3), c3 = 0, u3 = (l3 = e2.slice(t3)).length; c3 < u3; c3++) a3 = l3[c3], s2(i3, a3, n3);
    return i3.sort(n3).reverse();
  }, p2 = function(e2, t3, n3) {
    var i3, s3, c3, f3, p3, h3, v3, _3, d2;
    if (null == n3 && (n3 = r2), 10 * t3 <= e2.length) {
      if (!(c3 = e2.slice(0, t3).sort(n3)).length) return c3;
      for (s3 = c3[c3.length - 1], f3 = 0, h3 = (v3 = e2.slice(t3)).length; f3 < h3; f3++) n3(i3 = v3[f3], s3) < 0 && (u2(c3, i3, 0, null, n3), c3.pop(), s3 = c3[c3.length - 1]);
      return c3;
    }
    for (o2(e2, n3), d2 = [], p3 = 0, _3 = l2(t3, e2.length); 0 <= _3 ? p3 < _3 : p3 > _3; 0 <= _3 ? ++p3 : --p3) d2.push(a2(e2, n3));
    return d2;
  }, v2 = function(e2, t3, n3, o3) {
    var a3, i3, s3;
    for (null == o3 && (o3 = r2), a3 = e2[n3]; n3 > t3 && o3(a3, i3 = e2[s3 = n3 - 1 >> 1]) < 0; ) e2[n3] = i3, n3 = s3;
    return e2[n3] = a3;
  }, _2 = function(e2, t3, n3) {
    var o3, a3, i3, s3, c3;
    for (null == n3 && (n3 = r2), a3 = e2.length, c3 = t3, i3 = e2[t3], o3 = 2 * t3 + 1; o3 < a3; ) (s3 = o3 + 1) < a3 && !(n3(e2[o3], e2[s3]) < 0) && (o3 = s3), e2[t3] = e2[o3], o3 = 2 * (t3 = o3) + 1;
    return e2[t3] = i3, v2(e2, c3, t3, n3);
  }, t2 = (function() {
    function Heap(e2) {
      this.cmp = null != e2 ? e2 : r2, this.nodes = [];
    }
    return Heap.push = i2, Heap.pop = a2, Heap.replace = c2, Heap.pushpop = s2, Heap.heapify = o2, Heap.updateItem = h2, Heap.nlargest = f2, Heap.nsmallest = p2, Heap.prototype.push = function(e2) {
      return i2(this.nodes, e2, this.cmp);
    }, Heap.prototype.pop = function() {
      return a2(this.nodes, this.cmp);
    }, Heap.prototype.peek = function() {
      return this.nodes[0];
    }, Heap.prototype.contains = function(e2) {
      return -1 !== this.nodes.indexOf(e2);
    }, Heap.prototype.replace = function(e2) {
      return c2(this.nodes, e2, this.cmp);
    }, Heap.prototype.pushpop = function(e2) {
      return s2(this.nodes, e2, this.cmp);
    }, Heap.prototype.heapify = function() {
      return o2(this.nodes, this.cmp);
    }, Heap.prototype.updateItem = function(e2) {
      return h2(this.nodes, e2, this.cmp);
    }, Heap.prototype.clear = function() {
      return this.nodes = [];
    }, Heap.prototype.empty = function() {
      return 0 === this.nodes.length;
    }, Heap.prototype.size = function() {
      return this.nodes.length;
    }, Heap.prototype.clone = function() {
      var e2;
      return (e2 = new Heap()).nodes = this.nodes.slice(0), e2;
    }, Heap.prototype.toArray = function() {
      return this.nodes.slice(0);
    }, Heap.prototype.insert = Heap.prototype.push, Heap.prototype.top = Heap.prototype.peek, Heap.prototype.front = Heap.prototype.peek, Heap.prototype.has = Heap.prototype.contains, Heap.prototype.copy = Heap.prototype.clone, Heap;
  })(), e.exports = t2;
}.call(t);
var c = s.exports;
var u = function arrayMap$2(e2, t2) {
  for (var r2 = -1, n2 = null == e2 ? 0 : e2.length, o2 = Array(n2); ++r2 < n2; ) o2[r2] = t2(e2[r2], r2, e2);
  return o2;
};
var l = Array.isArray;
var f = "object" == typeof t && t && t.Object === Object && t;
var p = f;
var h = "object" == typeof self && self && self.Object === Object && self;
var v = p || h || Function("return this")();
var _ = v.Symbol;
var d = _;
var y = Object.prototype;
var g = y.hasOwnProperty;
var m = y.toString;
var b = d ? d.toStringTag : void 0;
var k = function getRawTag$1(e2) {
  var t2 = g.call(e2, b), r2 = e2[b];
  try {
    e2[b] = void 0;
    var n2 = true;
  } catch (e3) {
  }
  var o2 = m.call(e2);
  return n2 && (t2 ? e2[b] = r2 : delete e2[b]), o2;
};
var j = Object.prototype.toString;
var $ = k;
var w = function objectToString$1(e2) {
  return j.call(e2);
};
var O = _ ? _.toStringTag : void 0;
var S = function baseGetTag$5(e2) {
  return null == e2 ? void 0 === e2 ? "[object Undefined]" : "[object Null]" : O && O in Object(e2) ? $(e2) : w(e2);
};
var C = function isObjectLike$5(e2) {
  return null != e2 && "object" == typeof e2;
};
var z = S;
var A = C;
var x = function isSymbol$4(e2) {
  return "symbol" == typeof e2 || A(e2) && "[object Symbol]" == z(e2);
};
var M = l;
var I = x;
var E = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
var P = /^\w*$/;
var q = function isKey$3(e2, t2) {
  if (M(e2)) return false;
  var r2 = typeof e2;
  return !("number" != r2 && "symbol" != r2 && "boolean" != r2 && null != e2 && !I(e2)) || (P.test(e2) || !E.test(e2) || null != t2 && e2 in Object(t2));
};
var H = function isObject$3(e2) {
  var t2 = typeof e2;
  return null != e2 && ("object" == t2 || "function" == t2);
};
var L = S;
var R = H;
var T;
var B = function isFunction$2(e2) {
  if (!R(e2)) return false;
  var t2 = L(e2);
  return "[object Function]" == t2 || "[object GeneratorFunction]" == t2 || "[object AsyncFunction]" == t2 || "[object Proxy]" == t2;
};
var W = v["__core-js_shared__"];
var F = (T = /[^.]+$/.exec(W && W.keys && W.keys.IE_PROTO || "")) ? "Symbol(src)_1." + T : "";
var D = function isMasked$1(e2) {
  return !!F && F in e2;
};
var N = Function.prototype.toString;
var U = function toSource$2(e2) {
  if (null != e2) {
    try {
      return N.call(e2);
    } catch (e3) {
    }
    try {
      return e2 + "";
    } catch (e3) {
    }
  }
  return "";
};
var G = B;
var K = D;
var Q = H;
var V = U;
var Z = /^\[object .+?Constructor\]$/;
var J = Function.prototype;
var X = Object.prototype;
var Y = J.toString;
var ee = X.hasOwnProperty;
var te = RegExp("^" + Y.call(ee).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
var re = function baseIsNative$1(e2) {
  return !(!Q(e2) || K(e2)) && (G(e2) ? te : Z).test(V(e2));
};
var ne = function getValue$1(e2, t2) {
  return null == e2 ? void 0 : e2[t2];
};
var oe = function getNative$6(e2, t2) {
  var r2 = ne(e2, t2);
  return re(r2) ? r2 : void 0;
};
var ae = oe(Object, "create");
var ie = ae;
var se = function hashClear$1() {
  this.__data__ = ie ? ie(null) : {}, this.size = 0;
};
var ce = function hashDelete$1(e2) {
  var t2 = this.has(e2) && delete this.__data__[e2];
  return this.size -= t2 ? 1 : 0, t2;
};
var ue = ae;
var le = Object.prototype.hasOwnProperty;
var fe = function hashGet$1(e2) {
  var t2 = this.__data__;
  if (ue) {
    var r2 = t2[e2];
    return "__lodash_hash_undefined__" === r2 ? void 0 : r2;
  }
  return le.call(t2, e2) ? t2[e2] : void 0;
};
var pe = ae;
var he = Object.prototype.hasOwnProperty;
var ve = ae;
var _e = se;
var de = ce;
var ye = fe;
var ge = function hashHas$1(e2) {
  var t2 = this.__data__;
  return pe ? void 0 !== t2[e2] : he.call(t2, e2);
};
var me = function hashSet$1(e2, t2) {
  var r2 = this.__data__;
  return this.size += this.has(e2) ? 0 : 1, r2[e2] = ve && void 0 === t2 ? "__lodash_hash_undefined__" : t2, this;
};
function Hash$1(e2) {
  var t2 = -1, r2 = null == e2 ? 0 : e2.length;
  for (this.clear(); ++t2 < r2; ) {
    var n2 = e2[t2];
    this.set(n2[0], n2[1]);
  }
}
Hash$1.prototype.clear = _e, Hash$1.prototype.delete = de, Hash$1.prototype.get = ye, Hash$1.prototype.has = ge, Hash$1.prototype.set = me;
var be = Hash$1;
var ke = function listCacheClear$1() {
  this.__data__ = [], this.size = 0;
};
var je = function eq$2(e2, t2) {
  return e2 === t2 || e2 != e2 && t2 != t2;
};
var $e = je;
var we = function assocIndexOf$4(e2, t2) {
  for (var r2 = e2.length; r2--; ) if ($e(e2[r2][0], t2)) return r2;
  return -1;
};
var Oe = we;
var Se = Array.prototype.splice;
var Ce = we;
var ze = we;
var Ae = we;
var xe = ke;
var Me = function listCacheDelete$1(e2) {
  var t2 = this.__data__, r2 = Oe(t2, e2);
  return !(r2 < 0) && (r2 == t2.length - 1 ? t2.pop() : Se.call(t2, r2, 1), --this.size, true);
};
var Ie = function listCacheGet$1(e2) {
  var t2 = this.__data__, r2 = Ce(t2, e2);
  return r2 < 0 ? void 0 : t2[r2][1];
};
var Ee = function listCacheHas$1(e2) {
  return ze(this.__data__, e2) > -1;
};
var Pe = function listCacheSet$1(e2, t2) {
  var r2 = this.__data__, n2 = Ae(r2, e2);
  return n2 < 0 ? (++this.size, r2.push([e2, t2])) : r2[n2][1] = t2, this;
};
function ListCache$4(e2) {
  var t2 = -1, r2 = null == e2 ? 0 : e2.length;
  for (this.clear(); ++t2 < r2; ) {
    var n2 = e2[t2];
    this.set(n2[0], n2[1]);
  }
}
ListCache$4.prototype.clear = xe, ListCache$4.prototype.delete = Me, ListCache$4.prototype.get = Ie, ListCache$4.prototype.has = Ee, ListCache$4.prototype.set = Pe;
var qe = ListCache$4;
var He = oe(v, "Map");
var Le = be;
var Re = qe;
var Te = He;
var Be = function isKeyable$1(e2) {
  var t2 = typeof e2;
  return "string" == t2 || "number" == t2 || "symbol" == t2 || "boolean" == t2 ? "__proto__" !== e2 : null === e2;
};
var We = function getMapData$4(e2, t2) {
  var r2 = e2.__data__;
  return Be(t2) ? r2["string" == typeof t2 ? "string" : "hash"] : r2.map;
};
var Fe = We;
var De = We;
var Ne = We;
var Ue = We;
var Ge = function mapCacheClear$1() {
  this.size = 0, this.__data__ = { hash: new Le(), map: new (Te || Re)(), string: new Le() };
};
var Ke = function mapCacheDelete$1(e2) {
  var t2 = Fe(this, e2).delete(e2);
  return this.size -= t2 ? 1 : 0, t2;
};
var Qe = function mapCacheGet$1(e2) {
  return De(this, e2).get(e2);
};
var Ve = function mapCacheHas$1(e2) {
  return Ne(this, e2).has(e2);
};
var Ze = function mapCacheSet$1(e2, t2) {
  var r2 = Ue(this, e2), n2 = r2.size;
  return r2.set(e2, t2), this.size += r2.size == n2 ? 0 : 1, this;
};
function MapCache$3(e2) {
  var t2 = -1, r2 = null == e2 ? 0 : e2.length;
  for (this.clear(); ++t2 < r2; ) {
    var n2 = e2[t2];
    this.set(n2[0], n2[1]);
  }
}
MapCache$3.prototype.clear = Ge, MapCache$3.prototype.delete = Ke, MapCache$3.prototype.get = Qe, MapCache$3.prototype.has = Ve, MapCache$3.prototype.set = Ze;
var Je = MapCache$3;
var Xe = Je;
function memoize$1(e2, t2) {
  if ("function" != typeof e2 || null != t2 && "function" != typeof t2) throw new TypeError("Expected a function");
  var memoized = function() {
    var r2 = arguments, n2 = t2 ? t2.apply(this, r2) : r2[0], o2 = memoized.cache;
    if (o2.has(n2)) return o2.get(n2);
    var a2 = e2.apply(this, r2);
    return memoized.cache = o2.set(n2, a2) || o2, a2;
  };
  return memoized.cache = new (memoize$1.Cache || Xe)(), memoized;
}
memoize$1.Cache = Xe;
var Ye = memoize$1;
var et2 = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
var tt = /\\(\\)?/g;
var rt = (function memoizeCapped$1(e2) {
  var t2 = Ye(e2, (function(e3) {
    return 500 === r2.size && r2.clear(), e3;
  })), r2 = t2.cache;
  return t2;
})((function(e2) {
  var t2 = [];
  return 46 === e2.charCodeAt(0) && t2.push(""), e2.replace(et2, (function(e3, r2, n2, o2) {
    t2.push(n2 ? o2.replace(tt, "$1") : r2 || e3);
  })), t2;
}));
var nt = u;
var ot = l;
var at = x;
var it = _ ? _.prototype : void 0;
var st = it ? it.toString : void 0;
var ct = function baseToString$1(e2) {
  if ("string" == typeof e2) return e2;
  if (ot(e2)) return nt(e2, baseToString$1) + "";
  if (at(e2)) return st ? st.call(e2) : "";
  var t2 = e2 + "";
  return "0" == t2 && 1 / e2 == -Infinity ? "-0" : t2;
};
var ut = ct;
var lt = l;
var ft = q;
var pt = rt;
var ht = function toString$1(e2) {
  return null == e2 ? "" : ut(e2);
};
var vt = function castPath$2(e2, t2) {
  return lt(e2) ? e2 : ft(e2, t2) ? [e2] : pt(ht(e2));
};
var _t = x;
var dt = function toKey$4(e2) {
  if ("string" == typeof e2 || _t(e2)) return e2;
  var t2 = e2 + "";
  return "0" == t2 && 1 / e2 == -Infinity ? "-0" : t2;
};
var yt = vt;
var gt = dt;
var mt = function baseGet$3(e2, t2) {
  for (var r2 = 0, n2 = (t2 = yt(t2, e2)).length; null != e2 && r2 < n2; ) e2 = e2[gt(t2[r2++])];
  return r2 && r2 == n2 ? e2 : void 0;
};
var bt = qe;
var kt = qe;
var jt = He;
var $t = Je;
var wt = qe;
var Ot = function stackClear$1() {
  this.__data__ = new bt(), this.size = 0;
};
var St = function stackDelete$1(e2) {
  var t2 = this.__data__, r2 = t2.delete(e2);
  return this.size = t2.size, r2;
};
var Ct = function stackGet$1(e2) {
  return this.__data__.get(e2);
};
var zt = function stackHas$1(e2) {
  return this.__data__.has(e2);
};
var At = function stackSet$1(e2, t2) {
  var r2 = this.__data__;
  if (r2 instanceof kt) {
    var n2 = r2.__data__;
    if (!jt || n2.length < 199) return n2.push([e2, t2]), this.size = ++r2.size, this;
    r2 = this.__data__ = new $t(n2);
  }
  return r2.set(e2, t2), this.size = r2.size, this;
};
function Stack$2(e2) {
  var t2 = this.__data__ = new wt(e2);
  this.size = t2.size;
}
Stack$2.prototype.clear = Ot, Stack$2.prototype.delete = St, Stack$2.prototype.get = Ct, Stack$2.prototype.has = zt, Stack$2.prototype.set = At;
var xt = Stack$2;
var Mt = Je;
var It = function setCacheAdd$1(e2) {
  return this.__data__.set(e2, "__lodash_hash_undefined__"), this;
};
var Et = function setCacheHas$1(e2) {
  return this.__data__.has(e2);
};
function SetCache$1(e2) {
  var t2 = -1, r2 = null == e2 ? 0 : e2.length;
  for (this.__data__ = new Mt(); ++t2 < r2; ) this.add(e2[t2]);
}
SetCache$1.prototype.add = SetCache$1.prototype.push = It, SetCache$1.prototype.has = Et;
var Pt = SetCache$1;
var qt = function arraySome$1(e2, t2) {
  for (var r2 = -1, n2 = null == e2 ? 0 : e2.length; ++r2 < n2; ) if (t2(e2[r2], r2, e2)) return true;
  return false;
};
var Ht = function cacheHas$1(e2, t2) {
  return e2.has(t2);
};
var Lt = function equalArrays$2(e2, t2, r2, n2, o2, a2) {
  var i2 = 1 & r2, s2 = e2.length, c2 = t2.length;
  if (s2 != c2 && !(i2 && c2 > s2)) return false;
  var u2 = a2.get(e2), l2 = a2.get(t2);
  if (u2 && l2) return u2 == t2 && l2 == e2;
  var f2 = -1, p2 = true, h2 = 2 & r2 ? new Pt() : void 0;
  for (a2.set(e2, t2), a2.set(t2, e2); ++f2 < s2; ) {
    var v2 = e2[f2], _2 = t2[f2];
    if (n2) var d2 = i2 ? n2(_2, v2, f2, t2, e2, a2) : n2(v2, _2, f2, e2, t2, a2);
    if (void 0 !== d2) {
      if (d2) continue;
      p2 = false;
      break;
    }
    if (h2) {
      if (!qt(t2, (function(e3, t3) {
        if (!Ht(h2, t3) && (v2 === e3 || o2(v2, e3, r2, n2, a2))) return h2.push(t3);
      }))) {
        p2 = false;
        break;
      }
    } else if (v2 !== _2 && !o2(v2, _2, r2, n2, a2)) {
      p2 = false;
      break;
    }
  }
  return a2.delete(e2), a2.delete(t2), p2;
};
var Rt = v.Uint8Array;
var Tt = je;
var Bt = Lt;
var Wt = function mapToArray$1(e2) {
  var t2 = -1, r2 = Array(e2.size);
  return e2.forEach((function(e3, n2) {
    r2[++t2] = [n2, e3];
  })), r2;
};
var Ft = function setToArray$1(e2) {
  var t2 = -1, r2 = Array(e2.size);
  return e2.forEach((function(e3) {
    r2[++t2] = e3;
  })), r2;
};
var Dt = _ ? _.prototype : void 0;
var Nt = Dt ? Dt.valueOf : void 0;
var Ut = function equalByTag$1(e2, t2, r2, n2, o2, a2, i2) {
  switch (r2) {
    case "[object DataView]":
      if (e2.byteLength != t2.byteLength || e2.byteOffset != t2.byteOffset) return false;
      e2 = e2.buffer, t2 = t2.buffer;
    case "[object ArrayBuffer]":
      return !(e2.byteLength != t2.byteLength || !a2(new Rt(e2), new Rt(t2)));
    case "[object Boolean]":
    case "[object Date]":
    case "[object Number]":
      return Tt(+e2, +t2);
    case "[object Error]":
      return e2.name == t2.name && e2.message == t2.message;
    case "[object RegExp]":
    case "[object String]":
      return e2 == t2 + "";
    case "[object Map]":
      var s2 = Wt;
    case "[object Set]":
      var c2 = 1 & n2;
      if (s2 || (s2 = Ft), e2.size != t2.size && !c2) return false;
      var u2 = i2.get(e2);
      if (u2) return u2 == t2;
      n2 |= 2, i2.set(e2, t2);
      var l2 = Bt(s2(e2), s2(t2), n2, o2, a2, i2);
      return i2.delete(e2), l2;
    case "[object Symbol]":
      if (Nt) return Nt.call(e2) == Nt.call(t2);
  }
  return false;
};
var Gt = function arrayPush$1(e2, t2) {
  for (var r2 = -1, n2 = t2.length, o2 = e2.length; ++r2 < n2; ) e2[o2 + r2] = t2[r2];
  return e2;
};
var Kt = l;
var Qt = function baseGetAllKeys$1(e2, t2, r2) {
  var n2 = t2(e2);
  return Kt(e2) ? n2 : Gt(n2, r2(e2));
};
var Vt = function arrayFilter$1(e2, t2) {
  for (var r2 = -1, n2 = null == e2 ? 0 : e2.length, o2 = 0, a2 = []; ++r2 < n2; ) {
    var i2 = e2[r2];
    t2(i2, r2, e2) && (a2[o2++] = i2);
  }
  return a2;
};
var Zt = function stubArray$1() {
  return [];
};
var Jt = Object.prototype.propertyIsEnumerable;
var Xt = Object.getOwnPropertySymbols;
var Yt = Xt ? function(e2) {
  return null == e2 ? [] : (e2 = Object(e2), Vt(Xt(e2), (function(t2) {
    return Jt.call(e2, t2);
  })));
} : Zt;
var er = function baseTimes$1(e2, t2) {
  for (var r2 = -1, n2 = Array(e2); ++r2 < e2; ) n2[r2] = t2(r2);
  return n2;
};
var tr = S;
var rr = C;
var nr = function baseIsArguments$1(e2) {
  return rr(e2) && "[object Arguments]" == tr(e2);
};
var or = C;
var ar = Object.prototype;
var ir = ar.hasOwnProperty;
var sr = ar.propertyIsEnumerable;
var cr = nr(/* @__PURE__ */ (function() {
  return arguments;
})()) ? nr : function(e2) {
  return or(e2) && ir.call(e2, "callee") && !sr.call(e2, "callee");
};
var ur = { exports: {} };
var lr = function stubFalse() {
  return false;
};
!(function(e2, t2) {
  var r2 = v, n2 = lr, o2 = t2 && !t2.nodeType && t2, a2 = o2 && e2 && !e2.nodeType && e2, i2 = a2 && a2.exports === o2 ? r2.Buffer : void 0, s2 = (i2 ? i2.isBuffer : void 0) || n2;
  e2.exports = s2;
})(ur, ur.exports);
var fr = /^(?:0|[1-9]\d*)$/;
var pr = function isIndex$2(e2, t2) {
  var r2 = typeof e2;
  return !!(t2 = null == t2 ? 9007199254740991 : t2) && ("number" == r2 || "symbol" != r2 && fr.test(e2)) && e2 > -1 && e2 % 1 == 0 && e2 < t2;
};
var hr = function isLength$3(e2) {
  return "number" == typeof e2 && e2 > -1 && e2 % 1 == 0 && e2 <= 9007199254740991;
};
var vr = S;
var _r = hr;
var dr = C;
var yr = {};
yr["[object Float32Array]"] = yr["[object Float64Array]"] = yr["[object Int8Array]"] = yr["[object Int16Array]"] = yr["[object Int32Array]"] = yr["[object Uint8Array]"] = yr["[object Uint8ClampedArray]"] = yr["[object Uint16Array]"] = yr["[object Uint32Array]"] = true, yr["[object Arguments]"] = yr["[object Array]"] = yr["[object ArrayBuffer]"] = yr["[object Boolean]"] = yr["[object DataView]"] = yr["[object Date]"] = yr["[object Error]"] = yr["[object Function]"] = yr["[object Map]"] = yr["[object Number]"] = yr["[object Object]"] = yr["[object RegExp]"] = yr["[object Set]"] = yr["[object String]"] = yr["[object WeakMap]"] = false;
var gr = function baseIsTypedArray$1(e2) {
  return dr(e2) && _r(e2.length) && !!yr[vr(e2)];
};
var mr = function baseUnary$2(e2) {
  return function(t2) {
    return e2(t2);
  };
};
var br = { exports: {} };
!(function(e2, t2) {
  var r2 = f, n2 = t2 && !t2.nodeType && t2, o2 = n2 && e2 && !e2.nodeType && e2, a2 = o2 && o2.exports === n2 && r2.process, i2 = (function() {
    try {
      var e3 = o2 && o2.require && o2.require("util").types;
      return e3 || a2 && a2.binding && a2.binding("util");
    } catch (e4) {
    }
  })();
  e2.exports = i2;
})(br, br.exports);
var kr = gr;
var jr = mr;
var $r = br.exports;
var wr = $r && $r.isTypedArray;
var Or = wr ? jr(wr) : kr;
var Sr = er;
var Cr = cr;
var zr = l;
var Ar = ur.exports;
var xr = pr;
var Mr = Or;
var Ir = Object.prototype.hasOwnProperty;
var Er = function arrayLikeKeys$1(e2, t2) {
  var r2 = zr(e2), n2 = !r2 && Cr(e2), o2 = !r2 && !n2 && Ar(e2), a2 = !r2 && !n2 && !o2 && Mr(e2), i2 = r2 || n2 || o2 || a2, s2 = i2 ? Sr(e2.length, String) : [], c2 = s2.length;
  for (var u2 in e2) !t2 && !Ir.call(e2, u2) || i2 && ("length" == u2 || o2 && ("offset" == u2 || "parent" == u2) || a2 && ("buffer" == u2 || "byteLength" == u2 || "byteOffset" == u2) || xr(u2, c2)) || s2.push(u2);
  return s2;
};
var Pr = Object.prototype;
var qr = function isPrototype$1(e2) {
  var t2 = e2 && e2.constructor;
  return e2 === ("function" == typeof t2 && t2.prototype || Pr);
};
var Hr = /* @__PURE__ */ (function overArg$1(e2, t2) {
  return function(r2) {
    return e2(t2(r2));
  };
})(Object.keys, Object);
var Lr = qr;
var Rr = Hr;
var Tr = Object.prototype.hasOwnProperty;
var Br = B;
var Wr = hr;
var Fr = function isArrayLike$3(e2) {
  return null != e2 && Wr(e2.length) && !Br(e2);
};
var Dr = Er;
var Nr = function baseKeys$1(e2) {
  if (!Lr(e2)) return Rr(e2);
  var t2 = [];
  for (var r2 in Object(e2)) Tr.call(e2, r2) && "constructor" != r2 && t2.push(r2);
  return t2;
};
var Ur = Fr;
var Gr = function keys$3(e2) {
  return Ur(e2) ? Dr(e2) : Nr(e2);
};
var Kr = Qt;
var Qr = Yt;
var Vr = Gr;
var Zr = function getAllKeys$1(e2) {
  return Kr(e2, Vr, Qr);
};
var Jr = Object.prototype.hasOwnProperty;
var Xr = function equalObjects$1(e2, t2, r2, n2, o2, a2) {
  var i2 = 1 & r2, s2 = Zr(e2), c2 = s2.length;
  if (c2 != Zr(t2).length && !i2) return false;
  for (var u2 = c2; u2--; ) {
    var l2 = s2[u2];
    if (!(i2 ? l2 in t2 : Jr.call(t2, l2))) return false;
  }
  var f2 = a2.get(e2), p2 = a2.get(t2);
  if (f2 && p2) return f2 == t2 && p2 == e2;
  var h2 = true;
  a2.set(e2, t2), a2.set(t2, e2);
  for (var v2 = i2; ++u2 < c2; ) {
    var _2 = e2[l2 = s2[u2]], d2 = t2[l2];
    if (n2) var y2 = i2 ? n2(d2, _2, l2, t2, e2, a2) : n2(_2, d2, l2, e2, t2, a2);
    if (!(void 0 === y2 ? _2 === d2 || o2(_2, d2, r2, n2, a2) : y2)) {
      h2 = false;
      break;
    }
    v2 || (v2 = "constructor" == l2);
  }
  if (h2 && !v2) {
    var g2 = e2.constructor, m2 = t2.constructor;
    g2 == m2 || !("constructor" in e2) || !("constructor" in t2) || "function" == typeof g2 && g2 instanceof g2 && "function" == typeof m2 && m2 instanceof m2 || (h2 = false);
  }
  return a2.delete(e2), a2.delete(t2), h2;
};
var Yr = oe(v, "DataView");
var en = He;
var tn = oe(v, "Promise");
var rn = oe(v, "Set");
var nn = oe(v, "WeakMap");
var on = S;
var an = U;
var sn = an(Yr);
var cn = an(en);
var un = an(tn);
var ln = an(rn);
var fn = an(nn);
var pn = on;
(Yr && "[object DataView]" != pn(new Yr(new ArrayBuffer(1))) || en && "[object Map]" != pn(new en()) || tn && "[object Promise]" != pn(tn.resolve()) || rn && "[object Set]" != pn(new rn()) || nn && "[object WeakMap]" != pn(new nn())) && (pn = function(e2) {
  var t2 = on(e2), r2 = "[object Object]" == t2 ? e2.constructor : void 0, n2 = r2 ? an(r2) : "";
  if (n2) switch (n2) {
    case sn:
      return "[object DataView]";
    case cn:
      return "[object Map]";
    case un:
      return "[object Promise]";
    case ln:
      return "[object Set]";
    case fn:
      return "[object WeakMap]";
  }
  return t2;
});
var hn = xt;
var vn = Lt;
var _n = Ut;
var dn = Xr;
var yn = pn;
var gn = l;
var mn = ur.exports;
var bn = Or;
var kn = "[object Object]";
var jn = Object.prototype.hasOwnProperty;
var $n = function baseIsEqualDeep$1(e2, t2, r2, n2, o2, a2) {
  var i2 = gn(e2), s2 = gn(t2), c2 = i2 ? "[object Array]" : yn(e2), u2 = s2 ? "[object Array]" : yn(t2), l2 = (c2 = "[object Arguments]" == c2 ? kn : c2) == kn, f2 = (u2 = "[object Arguments]" == u2 ? kn : u2) == kn, p2 = c2 == u2;
  if (p2 && mn(e2)) {
    if (!mn(t2)) return false;
    i2 = true, l2 = false;
  }
  if (p2 && !l2) return a2 || (a2 = new hn()), i2 || bn(e2) ? vn(e2, t2, r2, n2, o2, a2) : _n(e2, t2, c2, r2, n2, o2, a2);
  if (!(1 & r2)) {
    var h2 = l2 && jn.call(e2, "__wrapped__"), v2 = f2 && jn.call(t2, "__wrapped__");
    if (h2 || v2) {
      var _2 = h2 ? e2.value() : e2, d2 = v2 ? t2.value() : t2;
      return a2 || (a2 = new hn()), o2(_2, d2, r2, n2, a2);
    }
  }
  return !!p2 && (a2 || (a2 = new hn()), dn(e2, t2, r2, n2, o2, a2));
};
var wn = C;
var On = function baseIsEqual$2(e2, t2, r2, n2, o2) {
  return e2 === t2 || (null == e2 || null == t2 || !wn(e2) && !wn(t2) ? e2 != e2 && t2 != t2 : $n(e2, t2, r2, n2, baseIsEqual$2, o2));
};
var Sn = xt;
var Cn = On;
var zn = H;
var An = function isStrictComparable$2(e2) {
  return e2 == e2 && !zn(e2);
};
var xn = An;
var Mn = Gr;
var In = function matchesStrictComparable$2(e2, t2) {
  return function(r2) {
    return null != r2 && (r2[e2] === t2 && (void 0 !== t2 || e2 in Object(r2)));
  };
};
var En = function baseIsMatch$1(e2, t2, r2, n2) {
  var o2 = r2.length, a2 = o2, i2 = !n2;
  if (null == e2) return !a2;
  for (e2 = Object(e2); o2--; ) {
    var s2 = r2[o2];
    if (i2 && s2[2] ? s2[1] !== e2[s2[0]] : !(s2[0] in e2)) return false;
  }
  for (; ++o2 < a2; ) {
    var c2 = (s2 = r2[o2])[0], u2 = e2[c2], l2 = s2[1];
    if (i2 && s2[2]) {
      if (void 0 === u2 && !(c2 in e2)) return false;
    } else {
      var f2 = new Sn();
      if (n2) var p2 = n2(u2, l2, c2, e2, t2, f2);
      if (!(void 0 === p2 ? Cn(l2, u2, 3, n2, f2) : p2)) return false;
    }
  }
  return true;
};
var Pn = function getMatchData$1(e2) {
  for (var t2 = Mn(e2), r2 = t2.length; r2--; ) {
    var n2 = t2[r2], o2 = e2[n2];
    t2[r2] = [n2, o2, xn(o2)];
  }
  return t2;
};
var qn = In;
var Hn = mt;
var Ln = vt;
var Rn = cr;
var Tn = l;
var Bn = pr;
var Wn = hr;
var Fn = dt;
var Dn = function baseHasIn$1(e2, t2) {
  return null != e2 && t2 in Object(e2);
};
var Nn = function hasPath$1(e2, t2, r2) {
  for (var n2 = -1, o2 = (t2 = Ln(t2, e2)).length, a2 = false; ++n2 < o2; ) {
    var i2 = Fn(t2[n2]);
    if (!(a2 = null != e2 && r2(e2, i2))) break;
    e2 = e2[i2];
  }
  return a2 || ++n2 != o2 ? a2 : !!(o2 = null == e2 ? 0 : e2.length) && Wn(o2) && Bn(i2, o2) && (Tn(e2) || Rn(e2));
};
var Un = On;
var Gn = function get$1(e2, t2, r2) {
  var n2 = null == e2 ? void 0 : Hn(e2, t2);
  return void 0 === n2 ? r2 : n2;
};
var Kn = function hasIn$1(e2, t2) {
  return null != e2 && Nn(e2, t2, Dn);
};
var Qn = q;
var Vn = An;
var Zn = In;
var Jn = dt;
var Xn = function identity$2(e2) {
  return e2;
};
var Yn = mt;
var eo = function baseProperty$1(e2) {
  return function(t2) {
    return null == t2 ? void 0 : t2[e2];
  };
};
var to = function basePropertyDeep$1(e2) {
  return function(t2) {
    return Yn(t2, e2);
  };
};
var ro = q;
var no = dt;
var oo = function baseMatches$1(e2) {
  var t2 = Pn(e2);
  return 1 == t2.length && t2[0][2] ? qn(t2[0][0], t2[0][1]) : function(r2) {
    return r2 === e2 || En(r2, e2, t2);
  };
};
var ao = function baseMatchesProperty$1(e2, t2) {
  return Qn(e2) && Vn(t2) ? Zn(Jn(e2), t2) : function(r2) {
    var n2 = Gn(r2, e2);
    return void 0 === n2 && n2 === t2 ? Kn(r2, e2) : Un(t2, n2, 3);
  };
};
var io = Xn;
var so = l;
var co = function property$1(e2) {
  return ro(e2) ? eo(no(e2)) : to(e2);
};
var uo = function baseIteratee$1(e2) {
  return "function" == typeof e2 ? e2 : null == e2 ? io : "object" == typeof e2 ? so(e2) ? ao(e2[0], e2[1]) : oo(e2) : co(e2);
};
var lo = /* @__PURE__ */ (function createBaseFor$1(e2) {
  return function(t2, r2, n2) {
    for (var o2 = -1, a2 = Object(t2), i2 = n2(t2), s2 = i2.length; s2--; ) {
      var c2 = i2[e2 ? s2 : ++o2];
      if (false === r2(a2[c2], c2, a2)) break;
    }
    return t2;
  };
})();
var fo = Gr;
var po = Fr;
var ho = /* @__PURE__ */ (function createBaseEach$1(e2, t2) {
  return function(r2, n2) {
    if (null == r2) return r2;
    if (!po(r2)) return e2(r2, n2);
    for (var o2 = r2.length, a2 = t2 ? o2 : -1, i2 = Object(r2); (t2 ? a2-- : ++a2 < o2) && false !== n2(i2[a2], a2, i2); ) ;
    return r2;
  };
})((function baseForOwn$1(e2, t2) {
  return e2 && lo(e2, t2, fo);
}));
var vo = Fr;
var _o = x;
var yo = function compareAscending$1(e2, t2) {
  if (e2 !== t2) {
    var r2 = void 0 !== e2, n2 = null === e2, o2 = e2 == e2, a2 = _o(e2), i2 = void 0 !== t2, s2 = null === t2, c2 = t2 == t2, u2 = _o(t2);
    if (!s2 && !u2 && !a2 && e2 > t2 || a2 && i2 && c2 && !s2 && !u2 || n2 && i2 && c2 || !r2 && c2 || !o2) return 1;
    if (!n2 && !a2 && !u2 && e2 < t2 || u2 && r2 && o2 && !n2 && !a2 || s2 && r2 && o2 || !i2 && o2 || !c2) return -1;
  }
  return 0;
};
var go = u;
var mo = mt;
var bo = uo;
var ko = function baseMap$1(e2, t2) {
  var r2 = -1, n2 = vo(e2) ? Array(e2.length) : [];
  return ho(e2, (function(e3, o2, a2) {
    n2[++r2] = t2(e3, o2, a2);
  })), n2;
};
var jo = function baseSortBy$1(e2, t2) {
  var r2 = e2.length;
  for (e2.sort(t2); r2--; ) e2[r2] = e2[r2].value;
  return e2;
};
var $o = mr;
var wo = function compareMultiple$1(e2, t2, r2) {
  for (var n2 = -1, o2 = e2.criteria, a2 = t2.criteria, i2 = o2.length, s2 = r2.length; ++n2 < i2; ) {
    var c2 = yo(o2[n2], a2[n2]);
    if (c2) return n2 >= s2 ? c2 : c2 * ("desc" == r2[n2] ? -1 : 1);
  }
  return e2.index - t2.index;
};
var Oo = Xn;
var So = l;
var Co = function baseOrderBy$1(e2, t2, r2) {
  t2 = t2.length ? go(t2, (function(e3) {
    return So(e3) ? function(t3) {
      return mo(t3, 1 === e3.length ? e3[0] : e3);
    } : e3;
  })) : [Oo];
  var n2 = -1;
  t2 = go(t2, $o(bo));
  var o2 = ko(e2, (function(e3, r3, o3) {
    return { criteria: go(t2, (function(t3) {
      return t3(e3);
    })), index: ++n2, value: e3 };
  }));
  return jo(o2, (function(e3, t3) {
    return wo(e3, t3, r2);
  }));
};
var zo = l;
var Ao = function orderBy(e2, t2, r2, n2) {
  return null == e2 ? [] : (zo(t2) || (t2 = null == t2 ? [] : [t2]), zo(r2 = n2 ? void 0 : r2) || (r2 = null == r2 ? [] : [r2]), Co(e2, t2, r2));
};
var xo;
var Mo = { _intersect: function _intersect(e2, t2) {
  if (!e2 || !t2 || 0 === e2.length || 0 === t2.length) return [];
  if (e2.length < 100 && t2.length < 100) return e2.filter(((e3) => t2.includes(e3)));
  const r2 = new Set(t2);
  return e2.filter(((e3) => r2.has(e3)));
}, _intersectWith: function _intersectWith(e2, t2, r2) {
  return e2 && t2 && 0 !== e2.length && 0 !== t2.length ? e2.filter(((e3) => t2.some(((t3) => r2(e3, t3))))) : [];
}, _difference: function _difference(e2, t2) {
  if (!e2) return [];
  if (!t2 || 0 === t2.length) return e2.slice();
  if (e2.length < 100 && t2.length < 100) return e2.filter(((e3) => !t2.includes(e3)));
  const r2 = new Set(t2);
  return e2.filter(((e3) => !r2.has(e3)));
}, _differenceWith: function _differenceWith(e2, t2, r2) {
  return e2 ? t2 && 0 !== t2.length ? e2.filter(((e3) => !t2.some(((t3) => r2(e3, t3))))) : e2.slice() : [];
}, _uniq: function _uniq(e2) {
  return e2 && 0 !== e2.length ? 1 === e2.length ? e2.slice() : [...new Set(e2)] : [];
}, _uniqWith: function _uniqWith(e2, t2) {
  if (!e2 || 0 === e2.length) return [];
  if (1 === e2.length) return e2.slice();
  const r2 = [];
  e: for (let n2 = 0; n2 < e2.length; n2++) {
    const o2 = e2[n2];
    for (let e3 = 0; e3 < r2.length; e3++) if (t2(o2, r2[e3])) continue e;
    r2.push(o2);
  }
  return r2;
}, _partialRight: function _partialRight(e2) {
  const t2 = Array.prototype.slice.call(arguments, 1);
  return function() {
    const r2 = Array.prototype.slice.call(arguments);
    return e2.apply(this, r2.concat(t2));
  };
}, _forEach: function _forEach(e2, t2) {
  if (e2) if (Array.isArray(e2)) for (let r2 = 0; r2 < e2.length; r2++) t2(e2[r2], r2);
  else {
    const r2 = Object.keys(e2);
    for (let n2 = 0; n2 < r2.length; n2++) t2(e2[r2[n2]], r2[n2]);
  }
}, _isArray: Array.isArray };
try {
  xo = "undefined" != typeof Intl && void 0 !== Intl.Collator ? Intl.Collator("generic", { sensitivity: "base" }) : null;
} catch (e2) {
  void 0 !== typeof console && console.warn("Collator could not be initialized and wouldn't be used");
}
var Io;
var Eo = function leven(e2, t2, r2) {
  var n2 = [], o2 = [], a2 = r2 && xo && r2.useCollator, i2 = 1;
  if (r2 && r2.subcost && "number" == typeof r2.subcost && (i2 = r2.subcost), e2 === t2) return 0;
  var s2, c2, u2, l2, f2 = Array.from(e2), p2 = Array.from(t2), h2 = f2.length, v2 = p2.length;
  if (0 === h2) return v2;
  if (0 === v2) return h2;
  for (var _2 = 0, d2 = 0; _2 < h2; ) o2[_2] = f2[_2].codePointAt(0), n2[_2] = ++_2;
  if (a2) for (; d2 < v2; ) for (s2 = p2[d2].codePointAt(0), u2 = d2++, c2 = d2, _2 = 0; _2 < h2; _2++) l2 = 0 === xo.compare(String.fromCodePoint(s2), String.fromCodePoint(o2[_2])) ? u2 : u2 + i2, u2 = n2[_2], c2 = n2[_2] = u2 > c2 ? l2 > c2 ? c2 + 1 : l2 : l2 > u2 ? u2 + 1 : l2;
  else for (; d2 < v2; ) for (s2 = p2[d2].codePointAt(0), u2 = d2++, c2 = d2, _2 = 0; _2 < h2; _2++) l2 = s2 === o2[_2] ? u2 : u2 + i2, u2 = n2[_2], c2 = n2[_2] = u2 > c2 ? l2 > c2 ? c2 + 1 : l2 : l2 > u2 ? u2 + 1 : l2;
  return c2;
};
try {
  Io = "undefined" != typeof Intl && void 0 !== Intl.Collator ? Intl.Collator("generic", { sensitivity: "base" }) : null;
} catch (e2) {
  void 0 !== typeof console && console.warn("Collator could not be initialized and wouldn't be used");
}
var Po;
var qo = function leven2(e2, t2, r2, n2) {
  var o2 = [], a2 = [], i2 = r2 && Io && r2.useCollator, s2 = 1;
  if (r2 && r2.subcost && "number" == typeof r2.subcost && (s2 = r2.subcost), e2 === t2) return 0;
  var c2 = e2.length, u2 = t2.length;
  if (0 === c2) return u2;
  if (0 === u2) return c2;
  if (r2 && r2.wildcards && "string" == typeof r2.wildcards && r2.wildcards.length > 0) {
    var l2, f2, p2, h2, v2, _2;
    if (false === r2.full_process && true !== r2.processed) {
      f2 = (l2 = r2.wildcards[0]).charCodeAt(0);
      var d2 = "[" + (function escapeRegExp(e3) {
        return e3.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      })(r2.wildcards) + "]";
      if ((e2 = e2.replace(new RegExp(d2, "g"), l2)) === (t2 = t2.replace(new RegExp(d2, "g"), l2))) return 0;
    } else f2 = (l2 = r2.wildcards[0].toLowerCase()).charCodeAt(0);
    for (var y2 = 0, g2 = 0; y2 < c2; ) a2[y2] = e2.charCodeAt(y2), o2[y2] = ++y2;
    if (i2) for (; g2 < u2; ) for (p2 = t2.charCodeAt(g2), v2 = g2++, h2 = g2, y2 = 0; y2 < c2; y2++) _2 = 0 === Io.compare(String.fromCharCode(p2), String.fromCharCode(a2[y2])) || p2 === f2 || a2[y2] === f2 ? v2 : v2 + s2, v2 = o2[y2], h2 = o2[y2] = v2 > h2 ? _2 > h2 ? h2 + 1 : _2 : _2 > v2 ? v2 + 1 : _2;
    else for (; g2 < u2; ) for (p2 = t2.charCodeAt(g2), v2 = g2++, h2 = g2, y2 = 0; y2 < c2; y2++) _2 = p2 === a2[y2] || p2 === f2 || a2[y2] === f2 ? v2 : v2 + s2, v2 = o2[y2], h2 = o2[y2] = v2 > h2 ? _2 > h2 ? h2 + 1 : _2 : _2 > v2 ? v2 + 1 : _2;
    return h2;
  }
  return n2(e2, t2, r2);
};
try {
  Po = "undefined" != typeof Intl && void 0 !== Intl.Collator ? Intl.Collator("generic", { sensitivity: "base" }) : null;
} catch (e2) {
  void 0 !== typeof console && console.warn("Collator could not be initialized and wouldn't be used");
}
var Ho = function leven3(e2, t2, r2) {
  var n2 = [], o2 = [], a2 = r2 && Po && r2.useCollator, i2 = 1;
  if (r2 && r2.subcost && "number" == typeof r2.subcost && (i2 = r2.subcost), e2 === t2) return 0;
  var s2, c2, u2, l2, f2 = e2.length, p2 = t2.length;
  if (0 === f2) return p2;
  if (0 === p2) return f2;
  for (var h2 = 0, v2 = 0; h2 < f2; ) o2[h2] = e2.charCodeAt(h2), n2[h2] = ++h2;
  if (a2) for (; v2 < p2; ) for (s2 = t2.charCodeAt(v2), u2 = v2++, c2 = v2, h2 = 0; h2 < f2; h2++) l2 = 0 === Po.compare(String.fromCharCode(s2), String.fromCharCode(o2[h2])) ? u2 : u2 + i2, u2 = n2[h2], c2 = n2[h2] = u2 > c2 ? l2 > c2 ? c2 + 1 : l2 : l2 > u2 ? u2 + 1 : l2;
  else for (; v2 < p2; ) for (s2 = t2.charCodeAt(v2), u2 = v2++, c2 = v2, h2 = 0; h2 < f2; h2++) l2 = s2 === o2[h2] ? u2 : u2 + i2, u2 = n2[h2], c2 = n2[h2] = u2 > c2 ? l2 > c2 ? c2 + 1 : l2 : l2 > u2 ? u2 + 1 : l2;
  return c2;
};
!(function(e2, t2) {
  if (!e2.setImmediate) {
    var r2, n2 = 1, o2 = {}, a2 = false, i2 = e2.document, s2 = Object.getPrototypeOf && Object.getPrototypeOf(e2);
    s2 = s2 && s2.setTimeout ? s2 : e2, "[object process]" === {}.toString.call(e2.process) ? (function installNextTickImplementation() {
      r2 = function(e3) {
        process.nextTick((function() {
          runIfPresent(e3);
        }));
      };
    })() : !(function canUsePostMessage() {
      if (e2.postMessage && !e2.importScripts) {
        var t3 = true, r3 = e2.onmessage;
        return e2.onmessage = function() {
          t3 = false;
        }, e2.postMessage("", "*"), e2.onmessage = r3, t3;
      }
    })() ? e2.MessageChannel ? (function installMessageChannelImplementation() {
      var e3 = new MessageChannel();
      e3.port1.onmessage = function(e4) {
        runIfPresent(e4.data);
      }, r2 = function(t3) {
        e3.port2.postMessage(t3);
      };
    })() : i2 && "onreadystatechange" in i2.createElement("script") ? (function installReadyStateChangeImplementation() {
      var e3 = i2.documentElement;
      r2 = function(t3) {
        var r3 = i2.createElement("script");
        r3.onreadystatechange = function() {
          runIfPresent(t3), r3.onreadystatechange = null, e3.removeChild(r3), r3 = null;
        }, e3.appendChild(r3);
      };
    })() : (function installSetTimeoutImplementation() {
      r2 = function(e3) {
        setTimeout(runIfPresent, 0, e3);
      };
    })() : (function installPostMessageImplementation() {
      var t3 = "setImmediate$" + Math.random() + "$", onGlobalMessage = function(r3) {
        r3.source === e2 && "string" == typeof r3.data && 0 === r3.data.indexOf(t3) && runIfPresent(+r3.data.slice(t3.length));
      };
      e2.addEventListener ? e2.addEventListener("message", onGlobalMessage, false) : e2.attachEvent("onmessage", onGlobalMessage), r2 = function(r3) {
        e2.postMessage(t3 + r3, "*");
      };
    })(), s2.setImmediate = function setImmediate2(e3) {
      "function" != typeof e3 && (e3 = new Function("" + e3));
      for (var t3 = new Array(arguments.length - 1), a3 = 0; a3 < t3.length; a3++) t3[a3] = arguments[a3 + 1];
      var i3 = { callback: e3, args: t3 };
      return o2[n2] = i3, r2(n2), n2++;
    }, s2.clearImmediate = clearImmediate;
  }
  function clearImmediate(e3) {
    delete o2[e3];
  }
  function runIfPresent(e3) {
    if (a2) setTimeout(runIfPresent, 0, e3);
    else {
      var t3 = o2[e3];
      if (t3) {
        a2 = true;
        try {
          !(function run(e4) {
            var t4 = e4.callback, r3 = e4.args;
            switch (r3.length) {
              case 0:
                t4();
                break;
              case 1:
                t4(r3[0]);
                break;
              case 2:
                t4(r3[0], r3[1]);
                break;
              case 3:
                t4(r3[0], r3[1], r3[2]);
                break;
              default:
                t4.apply(void 0, r3);
            }
          })(t3);
        } finally {
          clearImmediate(e3), a2 = false;
        }
      }
    }
  }
})("undefined" == typeof self ? t : self);
var Lo = { exports: {} };
!(function(e2) {
  e2.exports = function(t2, r2, n2, o2) {
    return (e2 = {}).dedupe = function dedupe(e3, a2) {
      var i2, s2 = t2(a2);
      if (!r2(e3) && "object" != typeof e3) throw new Error("contains_dupes must be an array or object");
      if (0 === Object.keys(e3).length) return void 0 !== typeof console && console.warn("contains_dupes is empty"), [];
      s2.limit && (void 0 !== typeof console && console.warn("options.limit will be ignored in dedupe"), s2.limit = 0), s2.cutoff && "number" == typeof s2.cutoff || (void 0 !== typeof console && console.warn("Using default cutoff of 70"), s2.cutoff = 70), s2.scorer || (s2.scorer = n2, void 0 !== typeof console && console.log("Using default scorer 'ratio' for dedupe")), i2 = s2.processor && "function" == typeof s2.processor ? s2.processor : function(e4) {
        return e4;
      };
      var c2 = {};
      for (var u2 in e3) {
        var l2 = i2(e3[u2]);
        if ("string" != typeof l2 && l2 instanceof String == false) throw new Error("Each processed item in dedupe must be a string.");
        var f2 = o2(l2, e3, s2);
        s2.returnObjects ? (1 === f2.length || (f2 = f2.sort((function(e4, t3) {
          var r3 = i2(e4.choice), n3 = i2(t3.choice), o3 = r3.length, a3 = n3.length;
          return o3 === a3 ? r3 < n3 ? -1 : 1 : a3 - o3;
        }))), s2.keepmap ? c2[i2(f2[0].choice)] = { item: f2[0].choice, key: f2[0].key, matches: f2 } : c2[i2(f2[0].choice)] = { item: f2[0].choice, key: f2[0].key }) : (1 === f2.length || (f2 = f2.sort((function(e4, t3) {
          var r3 = i2(e4[0]), n3 = i2(t3[0]), o3 = r3.length, a3 = n3.length;
          return o3 === a3 ? r3 < n3 ? -1 : 1 : a3 - o3;
        }))), s2.keepmap ? c2[i2(f2[0][0])] = [f2[0][0], f2[0][2], f2] : c2[i2(f2[0][0])] = [f2[0][0], f2[0][2]]);
      }
      var p2 = [];
      for (var h2 in c2) p2.push(c2[h2]);
      return p2;
    }, e2;
  };
})(Lo), (function() {
  var e2 = i, t2 = c, n2 = Ao, o2 = Mo._intersect, a2 = Mo._intersectWith, s2 = Mo._difference, u2 = Mo._differenceWith, l2 = Mo._partialRight, f2 = Mo._forEach, p2 = Mo._isArray, h2 = Eo, v2 = qo, _2 = Ho, d2 = (function(e3, t3, r2) {
    var n3 = {}, o3 = qo, a3 = Ho;
    function escapeRegExp(e4) {
      return e4.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }
    function validate(e4) {
      return ("string" == typeof e4 || e4 instanceof String) && e4.length > 0;
    }
    n3.validate = validate, n3.process_and_sort = function process_and_sort(e4) {
      return validate(e4) ? e4.match(/\S+/g).sort().join(" ").trim() : "";
    }, n3.tokenize = function unique_tokens(n4, i3) {
      if (i3 && i3.wildcards && t3 && r2) {
        var s3 = r2(o3, i3, a3);
        return t3(n4.match(/\S+/g), (function(e4, t4) {
          return 0 === s3(e4, t4);
        }));
      }
      return e3(n4.match(/\S+/g));
    };
    const i2 = /[^\p{L}\p{N}]/gu;
    return n3.full_process = function full_process(e4, t4) {
      if (!(e4 instanceof String) && "string" != typeof e4) return "";
      var r3;
      if (t4 && "object" == typeof t4 && t4.wildcards && "string" == typeof t4.wildcards && t4.wildcards.length > 0) {
        var n4 = t4.wildcards.toLowerCase();
        if (e4 = e4.toLowerCase(), t4.force_ascii) {
          var o4 = "[^\0-\x7F" + escapeRegExp(n4) + "]";
          e4 = e4.replace(new RegExp(o4, "g"), "");
          var a4 = "[" + escapeRegExp(n4) + "]", s3 = n4[0];
          e4 = e4.replace(new RegExp(a4, "g"), s3);
          var c2 = "[^A-Za-z0-9" + escapeRegExp(n4) + "]";
          r3 = (e4 = (e4 = e4.replace(new RegExp(c2, "g"), " ")).replace(/_/g, " ")).trim();
        } else {
          var u3 = "[^\\p{L}\\p{N}" + escapeRegExp(n4) + "]";
          e4 = e4.replace(new RegExp(u3, "gu"), " "), a4 = "[" + escapeRegExp(n4) + "]", s3 = n4[0], r3 = (e4 = e4.replace(new RegExp(a4, "g"), s3)).trim();
        }
      } else r3 = t4 && (t4.force_ascii || true === t4) ? (e4 = e4.replace(/[^\x00-\x7F]/g, "")).replace(/\W|_/g, " ").toLowerCase().trim() : e4.replace(i2, " ").toLowerCase().trim();
      return t4 && t4.collapseWhitespace && (r3 = r3.replace(/\s+/g, " ")), r3;
    }, n3.clone_and_set_option_defaults = function(e4) {
      if (e4 && e4.isAClone) return e4;
      var t4 = { isAClone: true };
      if (e4) {
        var r3, n4 = Object.keys(e4);
        for (r3 = 0; r3 < n4.length; r3++) t4[n4[r3]] = e4[n4[r3]];
      }
      return false !== t4.full_process && (t4.full_process = true), true !== t4.force_ascii && (t4.force_ascii = false), false !== t4.normalize && true === t4.astral && (t4.normalize = true), false !== t4.collapseWhitespace && (t4.collapseWhitespace = true), t4;
    }, n3.isCustomFunc = function(e4) {
      return "function" != typeof e4 || "token_set_ratio" !== e4.name && "partial_token_set_ratio" !== e4.name && "token_sort_ratio" !== e4.name && "partial_token_sort_ratio" !== e4.name && "QRatio" !== e4.name && "WRatio" !== e4.name && "distance" !== e4.name && "partial_ratio" !== e4.name;
    }, n3;
  })(Mo._uniq, Mo._uniqWith, l2), y2 = d2.validate, g2 = d2.process_and_sort, m2 = d2.tokenize, b3 = d2.full_process, k2 = d2.clone_and_set_option_defaults, j2 = d2.isCustomFunc, $2 = Lo.exports(k2, p2, QRatio, extract).dedupe;
  function QRatio(e3, t3, r2) {
    var n3 = k2(r2);
    return e3 = n3.normalize ? e3.normalize() : e3, t3 = n3.normalize ? t3.normalize() : t3, e3 = n3.full_process ? b3(e3, n3) : e3, t3 = n3.full_process ? b3(t3, n3) : t3, y2(e3) && y2(t3) ? _ratio(e3, t3, n3) : 0;
  }
  function token_set_ratio(e3, t3, r2) {
    var n3 = k2(r2);
    return e3 = n3.normalize ? e3.normalize() : e3, t3 = n3.normalize ? t3.normalize() : t3, e3 = n3.full_process ? b3(e3, n3) : e3, t3 = n3.full_process ? b3(t3, n3) : t3, y2(e3) && y2(t3) ? _token_set(e3, t3, n3) : 0;
  }
  function partial_token_set_ratio(e3, t3, r2) {
    var n3 = k2(r2);
    return e3 = n3.normalize ? e3.normalize() : e3, t3 = n3.normalize ? t3.normalize() : t3, e3 = n3.full_process ? b3(e3, n3) : e3, t3 = n3.full_process ? b3(t3, n3) : t3, y2(e3) && y2(t3) ? (n3.partial = true, _token_set(e3, t3, n3)) : 0;
  }
  function token_sort_ratio(e3, t3, r2) {
    var n3 = k2(r2);
    return e3 = n3.normalize ? e3.normalize() : e3, t3 = n3.normalize ? t3.normalize() : t3, e3 = n3.full_process ? b3(e3, n3) : e3, t3 = n3.full_process ? b3(t3, n3) : t3, y2(e3) && y2(t3) ? (n3.proc_sorted || (e3 = g2(e3), t3 = g2(t3)), _ratio(e3, t3, n3)) : 0;
  }
  function partial_token_sort_ratio(e3, t3, r2) {
    var n3 = k2(r2);
    return e3 = n3.normalize ? e3.normalize() : e3, t3 = n3.normalize ? t3.normalize() : t3, e3 = n3.full_process ? b3(e3, n3) : e3, t3 = n3.full_process ? b3(t3, n3) : t3, y2(e3) && y2(t3) ? (n3.partial = true, n3.proc_sorted || (e3 = g2(e3), t3 = g2(t3)), _partial_ratio(e3, t3, n3)) : 0;
  }
  function extract(e3, r2, n3) {
    var o3, a3 = k2(n3);
    if (p2(r2)) o3 = r2.length;
    else {
      if (!(r2 instanceof Object)) throw new Error("Invalid choices");
      o3 = Object.keys(r2).length;
    }
    if (!r2 || 0 === o3) return void 0 !== typeof console && console.warn("No choices"), [];
    if (a3.processor && "function" != typeof a3.processor) throw new Error("Invalid Processor");
    if (a3.processor || (a3.processor = function(e4) {
      return e4;
    }), a3.scorer && "function" != typeof a3.scorer) throw new Error("Invalid Scorer");
    a3.scorer || (a3.scorer = QRatio);
    var i2 = j2(a3.scorer);
    a3.cutoff && "number" == typeof a3.cutoff || (a3.cutoff = -1);
    var pre_processor = function(e4, t3) {
      return e4;
    };
    a3.full_process && (pre_processor = b3, i2 || (a3.processed = true));
    var s3 = false;
    i2 || (a3.astral && a3.normalize && (a3.normalize = false, String.prototype.normalize ? (s3 = true, e3 = e3.normalize()) : void 0 !== typeof console && console.warn("Normalization not supported in your environment")), e3 = pre_processor(e3, a3), a3.full_process = false, 0 === e3.length && void 0 !== typeof console && console.warn("Processed query is empty string"));
    var c2, u3, l3, h3, v3 = [], _3 = false, d3 = false, y3 = false;
    if ("token_sort_ratio" === a3.scorer.name || "partial_token_sort_ratio" === a3.scorer.name) {
      var $3 = g2(e3);
      d3 = true;
    } else if ("token_set_ratio" === a3.scorer.name || "partial_token_set_ratio" === a3.scorer.name) {
      var w3 = m2(e3, a3);
      y3 = true;
    }
    return a3.returnObjects ? (l3 = function(e4, t3) {
      return e4.score - t3.score;
    }, h3 = function(e4, t3) {
      return t3.score - e4.score;
    }) : (l3 = function(e4, t3) {
      return e4[1] - t3[1];
    }, h3 = function(e4, t3) {
      return t3[1] - e4[1];
    }), f2(r2, (function(t3, r3) {
      a3.tokens = void 0, a3.proc_sorted = false, d3 ? (a3.proc_sorted = true, t3 && t3.proc_sorted ? u3 = t3.proc_sorted : (u3 = pre_processor(s3 ? a3.processor(t3).normalize() : a3.processor(t3), a3), u3 = g2(u3)), c2 = a3.scorer($3, u3, a3)) : y3 ? (u3 = "x", t3 && t3.tokens ? (a3.tokens = [w3, t3.tokens], a3.trySimple && (u3 = pre_processor(a3.processor(t3), a3))) : (u3 = pre_processor(s3 ? a3.processor(t3).normalize() : a3.processor(t3), a3), a3.tokens = [w3, m2(u3, a3)]), c2 = a3.scorer(e3, u3, a3)) : i2 ? (u3 = a3.processor(t3), c2 = a3.scorer(e3, u3, a3)) : ("string" == typeof (u3 = pre_processor(s3 ? a3.processor(t3).normalize() : a3.processor(t3), a3)) && 0 !== u3.length || (_3 = true), c2 = a3.scorer(e3, u3, a3)), c2 > a3.cutoff && (a3.returnObjects ? v3.push({ choice: t3, score: c2, key: r3 }) : v3.push([t3, c2, r3]));
    })), _3 && void 0 !== typeof console && console.log("One or more choices were empty. (post-processing if applied)"), a3.limit && "number" == typeof a3.limit && a3.limit > 0 && a3.limit < o3 && !a3.unsorted ? v3 = t2.nlargest(v3, a3.limit, l3) : a3.unsorted || (v3 = v3.sort(h3)), v3;
  }
  function extractAsync(e3, r2, n3, o3) {
    var a3, i2, s3 = k2(n3);
    "object" == typeof s3.abortController && (a3 = s3.abortController), "object" == typeof s3.cancelToken && (i2 = s3.cancelToken);
    var c2 = 256;
    "number" == typeof s3.asyncLoopOffset && (c2 = s3.asyncLoopOffset < 1 ? 1 : s3.asyncLoopOffset);
    var u3, l3 = false;
    if (r2 && r2.length && p2(r2)) u3 = r2.length, l3 = true;
    else {
      if (!(r2 instanceof Object)) return void o3(new Error("Invalid choices"));
      u3 = Object.keys(r2).length;
    }
    if (!r2 || 0 === u3) return void 0 !== typeof console && console.warn("No choices"), void o3(null, []);
    if (s3.processor && "function" != typeof s3.processor) o3(new Error("Invalid Processor"));
    else if (s3.processor || (s3.processor = function(e4) {
      return e4;
    }), s3.scorer && "function" != typeof s3.scorer) o3(new Error("Invalid Scorer"));
    else {
      s3.scorer || (s3.scorer = QRatio);
      var f3 = j2(s3.scorer);
      s3.cutoff && "number" == typeof s3.cutoff || (s3.cutoff = -1);
      var pre_processor = function(e4, t3) {
        return e4;
      };
      s3.full_process && (pre_processor = b3, f3 || (s3.processed = true));
      var h3 = false;
      f3 || (s3.astral && s3.normalize && (s3.normalize = false, String.prototype.normalize ? (h3 = true, e3 = e3.normalize()) : void 0 !== typeof console && console.warn("Normalization not supported in your environment")), e3 = pre_processor(e3, s3), s3.full_process = false, 0 === e3.length && void 0 !== typeof console && console.warn("Processed query is empty string"));
      var v3, _3, d3, y3, $3, w3 = [], O3 = false, S3 = false, C2 = false;
      if ("token_sort_ratio" === s3.scorer.name || "partial_token_sort_ratio" === s3.scorer.name) {
        var z2 = g2(e3);
        S3 = true;
      } else if ("token_set_ratio" === s3.scorer.name || "partial_token_set_ratio" === s3.scorer.name) {
        var A2 = m2(e3, s3);
        C2 = true;
      }
      s3.returnObjects ? (y3 = function(e4, t3) {
        return e4.score - t3.score;
      }, $3 = function(e4, t3) {
        return t3.score - e4.score;
      }) : (y3 = function(e4, t3) {
        return e4[1] - t3[1];
      }, $3 = function(e4, t3) {
        return t3[1] - e4[1];
      });
      var x2 = Object.keys(r2);
      l3 ? searchLoop(0) : searchLoop(x2[0], 0);
    }
    function searchLoop(n4, p3) {
      (l3 || r2.hasOwnProperty(n4)) && (s3.tokens = void 0, s3.proc_sorted = false, S3 ? (s3.proc_sorted = true, r2[n4] && r2[n4].proc_sorted ? _3 = r2[n4].proc_sorted : (_3 = pre_processor(h3 ? s3.processor(r2[n4]).normalize() : s3.processor(r2[n4]), s3), _3 = g2(_3)), d3 = s3.scorer(z2, _3, s3)) : C2 ? (_3 = "x", r2[n4] && r2[n4].tokens ? (s3.tokens = [A2, r2[n4].tokens], s3.trySimple && (_3 = pre_processor(s3.processor(r2[n4]), s3))) : (_3 = pre_processor(h3 ? s3.processor(r2[n4]).normalize() : s3.processor(r2[n4]), s3), s3.tokens = [A2, m2(_3, s3)]), d3 = s3.scorer(e3, _3, s3)) : f3 ? (_3 = s3.processor(r2[n4]), d3 = s3.scorer(e3, _3, s3)) : ("string" == typeof (_3 = pre_processor(h3 ? s3.processor(r2[n4]).normalize() : s3.processor(r2[n4]), s3)) && 0 !== _3.length || (O3 = true), d3 = s3.scorer(e3, _3, s3)), v3 = l3 ? parseInt(n4) : n4, d3 > s3.cutoff && (s3.returnObjects ? w3.push({ choice: r2[n4], score: d3, key: v3 }) : w3.push([r2[n4], d3, v3]))), a3 && true === a3.signal.aborted ? o3(new Error("aborted")) : i2 && true === i2.canceled ? o3(new Error("canceled")) : l3 && n4 < r2.length - 1 ? n4 % c2 == 0 ? setImmediate((function() {
        searchLoop(n4 + 1);
      })) : searchLoop(n4 + 1) : p3 < x2.length - 1 ? p3 % c2 == 0 ? setImmediate((function() {
        searchLoop(x2[p3 + 1], p3 + 1);
      })) : searchLoop(x2[p3 + 1], p3 + 1) : (O3 && void 0 !== typeof console && console.log("One or more choices were empty. (post-processing if applied)"), s3.limit && "number" == typeof s3.limit && s3.limit > 0 && s3.limit < u3 && !s3.unsorted ? w3 = t2.nlargest(w3, s3.limit, y3) : s3.unsorted || (w3 = w3.sort($3)), o3(null, w3));
    }
  }
  var w2 = "%*SuperUniqueWildcardKey*%";
  function _getCharacterCounts(e3, t3) {
    var r2 = e3;
    if (t3.astral) var n3 = Array.from(r2);
    else n3 = r2.split("");
    var o3 = {};
    if (t3.wildcards) for (var a3 = 0; a3 < n3.length; a3++) {
      var i2 = n3[a3];
      t3.wildcards.indexOf(i2) > -1 ? o3[w2] ? o3[w2] += 1 : o3[w2] = 1 : o3[i2] ? o3[i2] += 1 : o3[i2] = 1;
    }
    else for (a3 = 0; a3 < n3.length; a3++) {
      o3[i2 = n3[a3]] ? o3[i2] += 1 : o3[i2] = 1;
    }
    return o3;
  }
  function _token_similarity_sort(e3, t3, r2) {
    for (var a3 = t3, i2 = e3.reduce((function(e4, t4) {
      return e4[t4] = _getCharacterCounts(t4, r2), e4;
    }), {}), s3 = a3.reduce((function(e4, t4) {
      return e4[t4] = _getCharacterCounts(t4, r2), e4;
    }), {}), c2 = [], u3 = 0; a3.length && u3 < e3.length; ) {
      var l3 = n2(a3, (function(t4) {
        return r3 = i2[e3[u3]], n3 = s3[t4], a4 = Object.keys(r3), c3 = Object.keys(n3), l4 = o2(a4, c3).map((function(e4) {
          return r3[e4] * n3[e4];
        })).reduce((function(e4, t5) {
          return e4 + t5;
        }), 0), f3 = a4.map((function(e4) {
          return Math.pow(r3[e4], 2);
        })).reduce((function(e4, t5) {
          return e4 + t5;
        }), 0), p3 = c3.map((function(e4) {
          return Math.pow(n3[e4], 2);
        })).reduce((function(e4, t5) {
          return e4 + t5;
        }), 0), l4 / (Math.sqrt(f3) * Math.sqrt(p3));
        var r3, n3, a4, c3, l4, f3, p3;
      }), "desc")[0];
      c2.push(l3), u3++, a3 = a3.filter((function(e4) {
        return e4 !== l3;
      }));
    }
    return c2.concat(a3);
  }
  function _order_token_lists(e3, t3, r2, n3) {
    var o3 = t3, a3 = n3;
    if (t3.length > n3.length) o3 = n3, a3 = t3;
    else if (t3.length === n3.length) {
      if (e3.length > r2.length) o3 = n3, a3 = t3;
      else [e3, r2].sort()[0] === r2 && (o3 = n3, a3 = t3);
    }
    return [o3, a3];
  }
  function _token_similarity_sort_ratio(e3, t3, r2) {
    if (r2.tokens) n3 = r2.tokens[0], o3 = r2.tokens[1];
    else var n3 = m2(e3, r2), o3 = m2(t3, r2);
    var a3 = _order_token_lists(e3, n3.sort(), t3, o3.sort()), i2 = a3[0];
    const s3 = _token_similarity_sort(i2, a3[1], r2);
    return r2.partial ? _partial_ratio(i2.join(" "), s3.join(" "), r2) : _ratio(i2.join(" "), s3.join(" "), r2);
  }
  function _token_set(e3, t3, r2) {
    if (r2.tokens) n3 = r2.tokens[0], i2 = r2.tokens[1];
    else var n3 = m2(e3, r2), i2 = m2(t3, r2);
    if (r2.wildcards) var c2 = l2(v2, r2, _2), wildCompare = function(e4, t4) {
      return 0 === c2(e4, t4);
    }, f3 = a2(n3, i2, wildCompare), p3 = u2(n3, i2, wildCompare), h3 = u2(i2, n3, wildCompare);
    else f3 = o2(n3, i2), p3 = s2(n3, i2), h3 = s2(i2, n3);
    var d3 = f3.sort().join(" "), y3 = p3.sort(), g3 = h3.sort();
    if (r2.sortBySimilarity) var b5 = _order_token_lists(e3, y3, t3, g3), k3 = b5[0], j3 = b5[1], $3 = k3.join(" "), w3 = _token_similarity_sort(k3, j3, r2).join(" ");
    else $3 = y3.join(" "), w3 = g3.join(" ");
    var O3 = d3 + " " + $3, S3 = d3 + " " + w3;
    d3 = d3.trim(), O3 = O3.trim(), S3 = S3.trim();
    var C2 = _ratio;
    if (r2.partial && (C2 = _partial_ratio, d3.length > 0)) return 100;
    var z2 = [C2(d3, O3, r2), C2(d3, S3, r2), C2(O3, S3, r2)];
    return r2.trySimple && z2.push(C2(e3, t3, r2)), Math.max.apply(null, z2);
  }
  function _ratio(t3, r2, n3) {
    if (!y2(t3)) return 0;
    if (!y2(r2)) return 0;
    if (n3.ratio_alg && "difflib" === n3.ratio_alg) {
      var o3 = new e2(null, t3, r2, n3.autojunk).ratio();
      return Math.round(100 * o3);
    }
    var a3, i2;
    return void 0 === n3.subcost && (n3.subcost = 2), n3.astral ? (a3 = h2(t3, r2, n3), i2 = Array.from(t3).length + Array.from(r2).length) : n3.wildcards ? (a3 = v2(t3, r2, n3, _2), i2 = t3.length + r2.length) : (a3 = _2(t3, r2, n3), i2 = t3.length + r2.length), Math.round((i2 - a3) / i2 * 100);
  }
  function _partial_ratio(t3, r2, n3) {
    if (!y2(t3)) return 0;
    if (!y2(r2)) return 0;
    if (t3.length <= r2.length) var o3 = t3, a3 = r2;
    else o3 = r2, a3 = t3;
    for (var i2 = new e2(null, o3, a3, n3.autojunk).getMatchingBlocks(), s3 = [], c2 = 0; c2 < i2.length; c2++) {
      var u3 = i2[c2][1] - i2[c2][0] > 0 ? i2[c2][1] - i2[c2][0] : 0, l3 = u3 + o3.length, f3 = _ratio(o3, a3.substring(u3, l3), n3);
      if (f3 > 99.5) return 100;
      s3.push(f3);
    }
    return Math.max.apply(null, s3);
  }
  Object.keys || (Object.keys = (function() {
    var e3 = Object.prototype.hasOwnProperty, t3 = !{ toString: null }.propertyIsEnumerable("toString"), r2 = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"], n3 = r2.length;
    return function(o3) {
      if ("object" != typeof o3 && ("function" != typeof o3 || null === o3)) throw new TypeError("Object.keys called on non-object");
      var a3, i2, s3 = [];
      for (a3 in o3) e3.call(o3, a3) && s3.push(a3);
      if (t3) for (i2 = 0; i2 < n3; i2++) e3.call(o3, r2[i2]) && s3.push(r2[i2]);
      return s3;
    };
  })());
  var O2 = void 0;
  "undefined" != typeof Promise && (O2 = function(e3, t3, r2) {
    return new Promise((function(n3, o3) {
      extractAsync(e3, t3, r2, (function(e4, t4) {
        e4 ? o3(e4) : n3(t4);
      }));
    }));
  });
  var S2 = { distance: function distance(e3, t3, r2) {
    var n3 = k2(r2);
    return e3 = n3.normalize ? e3.normalize() : e3, t3 = n3.normalize ? t3.normalize() : t3, e3 = n3.full_process ? b3(e3, n3) : e3, t3 = n3.full_process ? b3(t3, n3) : t3, void 0 === n3.subcost && (n3.subcost = 1), n3.astral ? h2(e3, t3, n3) : v2(e3, t3, n3, _2);
  }, ratio: QRatio, partial_ratio: function partial_ratio(e3, t3, r2) {
    var n3 = k2(r2);
    return e3 = n3.normalize ? e3.normalize() : e3, t3 = n3.normalize ? t3.normalize() : t3, e3 = n3.full_process ? b3(e3, n3) : e3, t3 = n3.full_process ? b3(t3, n3) : t3, y2(e3) && y2(t3) ? _partial_ratio(e3, t3, n3) : 0;
  }, token_set_ratio, token_sort_ratio, partial_token_set_ratio, partial_token_sort_ratio, token_similarity_sort_ratio: function token_similarity_sort_ratio(e3, t3, r2) {
    var n3 = k2(r2);
    return e3 = n3.normalize ? e3.normalize() : e3, t3 = n3.normalize ? t3.normalize() : t3, e3 = n3.full_process ? b3(e3, n3) : e3, t3 = n3.full_process ? b3(t3, n3) : t3, y2(e3) && y2(t3) ? _token_similarity_sort_ratio(e3, t3, n3) : 0;
  }, partial_token_similarity_sort_ratio: function partial_token_similarity_sort_ratio(e3, t3, r2) {
    var n3 = k2(r2);
    return e3 = n3.normalize ? e3.normalize() : e3, t3 = n3.normalize ? t3.normalize() : t3, e3 = n3.full_process ? b3(e3, n3) : e3, t3 = n3.full_process ? b3(t3, n3) : t3, y2(e3) && y2(t3) ? (n3.partial = true, _token_similarity_sort_ratio(e3, t3, n3)) : 0;
  }, WRatio: function WRatio(e3, t3, r2) {
    var n3 = k2(r2);
    if (e3 = n3.normalize ? e3.normalize() : e3, t3 = n3.normalize ? t3.normalize() : t3, e3 = n3.full_process ? b3(e3, n3) : e3, t3 = n3.full_process ? b3(t3, n3) : t3, n3.full_process = false, !y2(e3)) return 0;
    if (!y2(t3)) return 0;
    var o3 = true, a3 = 0.95, i2 = 0.9, s3 = _ratio(e3, t3, n3), c2 = Math.max(e3.length, t3.length) / Math.min(e3.length, t3.length);
    if (c2 < 1.5 && (o3 = false), c2 > 8 && (i2 = 0.6), o3) {
      var u3 = _partial_ratio(e3, t3, n3) * i2, l3 = partial_token_sort_ratio(e3, t3, n3) * a3 * i2, f3 = partial_token_set_ratio(e3, t3, n3) * a3 * i2;
      return Math.round(Math.max(s3, u3, l3, f3));
    }
    var p3 = token_sort_ratio(e3, t3, n3) * a3, h3 = token_set_ratio(e3, t3, n3) * a3;
    return Math.round(Math.max(s3, p3, h3));
  }, full_process: b3, extract, extractAsync, extractAsPromised: O2, process_and_sort: g2, unique_tokens: m2, dedupe: $2 };
  r.exports = S2;
})();
var Ro = r.exports;
var To = Ro.distance;
var Bo = Ro.ratio;
var Wo = Ro.partial_ratio;
var Fo = Ro.token_set_ratio;
var Do = Ro.token_sort_ratio;
var No = Ro.partial_token_set_ratio;
var Uo = Ro.partial_token_sort_ratio;
var Go = Ro.token_similarity_sort_ratio;
var Ko = Ro.partial_token_similarity_sort_ratio;
var Qo = Ro.WRatio;
var Vo = Ro.full_process;
var Zo = Ro.extract;
var Jo = Ro.extractAsync;
var Xo = Ro.extractAsPromised;
var Yo = Ro.process_and_sort;
var ea = Ro.unique_tokens;
var ta = Ro.dedupe;

// src/lib/score.ts
function scoreText(query, candidate) {
  let best = 0;
  const qVars = nameVariants(query);
  const cVars = nameVariants(candidate);
  for (const q2 of qVars) {
    if (!q2) continue;
    for (const c2 of cVars) {
      if (!c2) continue;
      best = Math.max(
        best,
        Number(Qo(q2, c2)),
        Number(Fo(q2, c2)),
        Number(Do(q2, c2)),
        Number(Bo(q2, c2))
      );
      if (best >= 99.9) return 100;
    }
  }
  return best;
}
function scoreCandidates(query, candidates, opts = {}) {
  const threshold = opts.threshold ?? 90;
  const margin = opts.margin ?? 8;
  const ranked = [];
  const seen = /* @__PURE__ */ new Set();
  for (const cand of candidates) {
    const text = cand.text || "";
    const key = `${normalizeText(text)}|${cand.selector || ""}`;
    if (!normalizeText(text) || seen.has(key)) continue;
    seen.add(key);
    ranked.push({ ...cand, score: Math.round(scoreText(query, text) * 100) / 100 });
  }
  ranked.sort((a2, b3) => (b3.score || 0) - (a2.score || 0) || a2.text.localeCompare(b3.text));
  const winner = ranked[0] ?? null;
  const runnerUp = ranked[1] ?? null;
  if (!winner) {
    return { accepted: false, reason: "no_candidates", query, winner: null, runner_up: null, ranked: [], threshold, margin };
  }
  const winScore = Number(winner.score || 0);
  const second = runnerUp ? Number(runnerUp.score || 0) : 0;
  const gap = winScore - second;
  if (winScore < threshold) {
    return { accepted: false, reason: "below_threshold", query, winner, runner_up: runnerUp, ranked, threshold, margin };
  }
  if (runnerUp && gap < margin) {
    return { accepted: false, reason: "ambiguous_margin", query, winner, runner_up: runnerUp, ranked, threshold, margin };
  }
  return { accepted: true, reason: "accepted", query, winner, runner_up: runnerUp, ranked, threshold, margin };
}
function queryForStep(step, variables) {
  const raw = step.fuzzy_query || step.target_text || step.selectedText || step.value || step.description || "";
  return String(interpolate(raw, variables) || "").trim();
}

// src/lib/selectors.ts
function strategy(type, value, priority, source, extra = {}) {
  const metadata = { ...extra };
  if (source) metadata.source = source;
  return { type, value, priority, metadata };
}
function quotedPhrases(text) {
  const out = [];
  const re2 = /['"]([^'"]{1,80})['"]/g;
  let m2;
  while (m2 = re2.exec(text)) out.push(m2[1]);
  return out;
}
function buildSelectorPlan(step, cached) {
  const attempts = [];
  const seen = /* @__PURE__ */ new Set();
  const add = (kind, strat) => {
    if (!strat.type) return;
    const key = `${strat.type}|${strat.value}|${String(strat.metadata?.role || "")}`;
    if (seen.has(key)) return;
    seen.add(key);
    attempts.push({ kind, strategy: strat });
  };
  const winner = cached || step.cachedSelector;
  if (winner) add("cached", winner);
  const strategies = [...step.selectorStrategies || []];
  strategies.sort((a2, b3) => (a2.priority ?? 100) - (b3.priority ?? 100));
  for (const s2 of strategies) add("selector", s2);
  if (step.cssSelector) add("selector", strategy("css", step.cssSelector, 500, "legacy_css"));
  if (step.xpath) add("selector", strategy("xpath", step.xpath, 510, "legacy_xpath"));
  if (step.target_text) {
    add("selector", strategy("text_exact", step.target_text, 520, "target_text"));
    add("heuristic", strategy("text_fuzzy", step.target_text, 800, "target_text_fuzzy"));
    add("heuristic", strategy("role_text", step.target_text, 810, "target_role", { role: "button" }));
    add("heuristic", strategy("placeholder", step.target_text, 820, "target_placeholder"));
    add("heuristic", strategy("aria_label", step.target_text, 830, "target_aria"));
  }
  if (step.description) {
    for (const phrase of quotedPhrases(step.description)) {
      add("heuristic", strategy("text_exact", phrase, 850, "description"));
      add("heuristic", strategy("text_fuzzy", phrase, 860, "description_fuzzy"));
    }
  }
  return attempts;
}
function fuzzyApplies(step, enabled = true) {
  if (!enabled) return false;
  return ["click", "double_click", "right_click", "input", "select_change", "key_press"].includes(step.type);
}
function normalizeWikipediaUrl(url) {
  if (!url) return url ?? void 0;
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (!host.includes("wikipedia.org") && !host.includes("wikimedia.org")) return url;
    if (parsed.pathname.startsWith("/wiki/") && parsed.pathname.includes(" ")) {
      parsed.pathname = parsed.pathname.split("/").map((p2) => p2.replaceAll(" ", "_")).join("/");
      return parsed.toString();
    }
  } catch {
    return url;
  }
  return url;
}

// src/background.ts
var currentRun = null;
var hitlWaiter = null;
var pendingRunConfirms = /* @__PURE__ */ new Map();
function settleRunConfirm(requestId, accepted) {
  const pending = pendingRunConfirms.get(requestId);
  if (!pending) return false;
  pendingRunConfirms.delete(requestId);
  if (pending.onRemoved) chrome.windows.onRemoved.removeListener(pending.onRemoved);
  if (pending.windowId != null) {
    void chrome.windows.remove(pending.windowId).catch(() => void 0);
  }
  pending.resolve(accepted);
  return true;
}
async function confirmRunRequest(payload) {
  const requestId = crypto.randomUUID();
  const created = await chrome.windows.create({
    url: chrome.runtime.getURL(`confirm.html?id=${encodeURIComponent(requestId)}`),
    type: "popup",
    width: 420,
    height: 620,
    focused: true
  });
  return await new Promise((resolve) => {
    const windowId = created.id;
    const pending = { payload, resolve, windowId };
    const onRemoved = (id) => {
      if (windowId != null && id === windowId) settleRunConfirm(requestId, false);
    };
    pending.onRemoved = onRemoved;
    pendingRunConfirms.set(requestId, pending);
    chrome.windows.onRemoved.addListener(onRemoved);
  });
}
var injected = /* @__PURE__ */ new Set();
chrome.runtime.onInstalled.addListener(() => {
  void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});
void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
chrome.action.onClicked.addListener((tab) => {
  if (tab.id != null) void chrome.sidePanel.open({ tabId: tab.id });
});
function broadcast(message) {
  chrome.runtime.sendMessage(message).catch(() => void 0);
}
function emitRun() {
  broadcast({ kind: "bp-run", run: currentRun });
}
async function sendAction(tabId, action) {
  await ensureContent(tabId);
  try {
    return await chrome.tabs.sendMessage(tabId, { kind: "bp-action", action });
  } catch {
    injected.delete(tabId);
    await ensureContent(tabId);
    return await chrome.tabs.sendMessage(tabId, { kind: "bp-action", action });
  }
}
async function ensureContent(tabId) {
  if (injected.has(tabId)) {
    try {
      const ping = await chrome.tabs.sendMessage(tabId, { kind: "bp-action", action: { op: "ping" } });
      if (ping?.ok) return;
    } catch {
      injected.delete(tabId);
    }
  }
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  injected.add(tabId);
}
function waitForTabLoad(tabId, timeoutMs = 3e4) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error("Timed out waiting for the page to load"));
    }, timeoutMs);
    const listener = (id, info) => {
      if (id === tabId && info.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then((tab) => {
      if (tab.status === "complete") {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }).catch(() => void 0);
  });
}
async function navigate(tabId, url, waitS) {
  await chrome.tabs.update(tabId, { url });
  injected.delete(tabId);
  await waitForTabLoad(tabId);
  if (waitS) await new Promise((r2) => setTimeout(r2, Math.round(waitS * 1e3)));
  for (let i2 = 0; i2 < 2; i2++) {
    const info2 = await sendAction(tabId, { op: "pageInfo" });
    const data2 = info2.ok ? info2.data : null;
    if (!data2?.wikimediaError) return { url: data2?.url || url };
    await new Promise((r2) => setTimeout(r2, 2e3));
    await chrome.tabs.reload(tabId);
    injected.delete(tabId);
    await waitForTabLoad(tabId);
  }
  const info = await sendAction(tabId, { op: "pageInfo" });
  const data = info.ok ? info.data : null;
  return { url: data?.url || url };
}
async function afterAction(tabId) {
  await new Promise((r2) => setTimeout(r2, 150));
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status && tab.status !== "complete") {
      injected.delete(tabId);
      await waitForTabLoad(tabId);
    }
  } catch {
    injected.delete(tabId);
    await waitForTabLoad(tabId).catch(() => void 0);
  }
  await new Promise((r2) => setTimeout(r2, 400));
}
async function tryPlan(tabId, typ, plan, value, selected, key) {
  let last = "no selector strategies to try";
  for (const attempt of plan) {
    const res = await sendAction(tabId, { op: "act", typ, strategy: attempt.strategy, value, selected, key });
    if (res.ok) return { ok: true, attempt };
    last = res.error;
  }
  return { ok: false, error: last };
}
async function collect(tabId, step) {
  const res = await sendAction(tabId, { op: "collect", typ: step.type, containerHint: step.container_hint, limit: 80 });
  if (!res.ok || !Array.isArray(res.data)) return [];
  return res.data.map((raw, i2) => ({
    id: String(raw.id || `c_${i2}`),
    text: String(raw.text || ""),
    role: raw.role || null,
    selector: raw.selector || null,
    selector_type: "css",
    value: raw.value == null ? null : String(raw.value)
  })).filter((c2) => c2.text);
}
function mergeFuzzy(definition, step) {
  const base = { ...DEFAULT_FUZZY, ...definition.fuzzy || {}, ...step.fuzzy || {} };
  return { enabled: base.enabled !== false, threshold: base.threshold ?? 90, margin: base.margin ?? 8, top_n: base.top_n ?? 5 };
}
function waitForHitl(timeoutS) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      hitlWaiter = null;
      reject(new Error("HITL timed out"));
    }, Math.max(1, timeoutS) * 1e3);
    hitlWaiter = {
      resolve: (c2) => {
        clearTimeout(timer);
        hitlWaiter = null;
        resolve(c2);
      },
      reject: (e2) => {
        clearTimeout(timer);
        hitlWaiter = null;
        reject(e2);
      }
    };
  });
}
async function persistAlias(workflowId, alias) {
  const installed = await getInstalled(workflowId);
  if (!installed) return;
  const aliases = [...installed.definition.aliases || []].filter(
    (a2) => !(a2.step_index === alias.step_index && a2.query_normalized === alias.query_normalized)
  );
  aliases.push(alias);
  const steps = installed.definition.steps.map((step, i2) => {
    if (i2 !== alias.step_index) return step;
    if (alias.cssSelector) return { ...step, cachedSelector: { type: "css", value: alias.cssSelector, priority: 0 } };
    return step;
  });
  await putInstalled({
    ...installed,
    definition: { ...installed.definition, aliases, steps }
  });
}
async function runWorkflow(tabId, installed, variables) {
  const runId = crypto.randomUUID();
  const traces = [];
  currentRun = { runId, workflowId: installed.id, status: "running", currentIndex: 0, traces };
  emitRun();
  const definition = installed.definition;
  try {
    for (let index = 0; index < definition.steps.length; index++) {
      if (currentRun.status === "cancel") throw new Error("Cancelled");
      const rawStep = definition.steps[index];
      const step = {
        ...rawStep,
        url: interpolateUrl(rawStep.url, variables),
        value: interpolate(rawStep.value ?? rawStep.default_value, variables),
        selectedText: interpolate(rawStep.selectedText, variables),
        key: interpolate(rawStep.key, variables),
        target_text: interpolate(rawStep.target_text, variables),
        fuzzy_query: interpolate(rawStep.fuzzy_query, variables),
        cssSelector: interpolate(rawStep.cssSelector, variables),
        xpath: interpolate(rawStep.xpath, variables),
        selectorStrategies: (rawStep.selectorStrategies || []).map((s2) => ({
          ...s2,
          value: String(interpolate(s2.value, variables) ?? s2.value)
        }))
      };
      const trace = {
        index,
        type: step.type,
        description: step.description,
        status: "running",
        startedAt: Date.now()
      };
      traces.push(trace);
      currentRun.currentIndex = index;
      currentRun.traces = [...traces];
      emitRun();
      if (step.type === "navigation") {
        const url = normalizeWikipediaUrl(step.url);
        if (!url) throw new Error("navigation step is missing url");
        const out = await navigate(tabId, url, step.wait_time);
        const asserted = await sendAction(tabId, { op: "assert", expected: step.expected_state });
        if (!asserted.ok) throw new Error(asserted.error);
        trace.status = "ok";
        trace.output = out;
        trace.endedAt = Date.now();
        emitRun();
        continue;
      }
      if (step.type === "go_back" || step.type === "go_forward") {
        if (step.type === "go_back") await chrome.tabs.goBack(tabId).catch(() => void 0);
        else await chrome.tabs.goForward(tabId).catch(() => void 0);
        injected.delete(tabId);
        await waitForTabLoad(tabId).catch(() => void 0);
        const info = await sendAction(tabId, { op: "pageInfo" });
        trace.status = "ok";
        trace.output = info.ok ? info.data : void 0;
        trace.endedAt = Date.now();
        emitRun();
        continue;
      }
      if (step.type === "scroll") {
        const res = await sendAction(tabId, { op: "scroll", scrollX: step.scrollX || 0, scrollY: step.scrollY || 0 });
        if (!res.ok) throw new Error(res.error);
        trace.status = "ok";
        trace.output = res.data;
        trace.endedAt = Date.now();
        emitRun();
        continue;
      }
      if (step.type === "extract" || step.type === "extract_page_content") {
        const res = await sendAction(tabId, { op: "extract", step });
        if (!res.ok) throw new Error(res.error);
        const asserted = await sendAction(tabId, { op: "assert", expected: step.expected_state });
        if (!asserted.ok) throw new Error(asserted.error);
        trace.status = "ok";
        trace.output = res.data;
        trace.endedAt = Date.now();
        emitRun();
        continue;
      }
      if (step.type === "agent") throw new Error("agent steps are not executed in the extension (workflow-use only)");
      if (!["click", "double_click", "right_click", "input", "select_change", "key_press"].includes(step.type)) {
        throw new Error(`unsupported step type: ${step.type}`);
      }
      const plan = buildSelectorPlan(step);
      const det = await tryPlan(tabId, step.type, plan, step.value, step.selectedText, step.key);
      if (!det.ok && step.type === "click") {
        const info = await sendAction(tabId, { op: "pageInfo" });
        const url = String(info.ok && info.data && info.data.url || "");
        const onWikiArticle = /\/wiki\/[^/]+/.test(url) && !/Special:Search|Special:Search|title=Special/i.test(url);
        const openingResult = /first result|search result/i.test(step.description || step.target_text || "");
        if (onWikiArticle && openingResult) {
          trace.status = "ok";
          trace.message = "already on an article page";
          trace.output = { url };
          trace.endedAt = Date.now();
          emitRun();
          continue;
        }
      }
      if (det.ok) {
        if (["click", "double_click", "right_click", "key_press", "input", "select_change"].includes(step.type)) await afterAction(tabId);
        const asserted = await sendAction(tabId, { op: "assert", expected: step.expected_state });
        if (!asserted.ok) throw new Error(asserted.error);
        trace.status = "ok";
        trace.attempt = det.attempt ? { type: det.attempt.strategy.type, value: det.attempt.strategy.value, kind: det.attempt.kind } : void 0;
        trace.endedAt = Date.now();
        emitRun();
        continue;
      }
      const fuzzy = mergeFuzzy(definition, step);
      if (fuzzyApplies(step, fuzzy.enabled)) {
        const query = queryForStep(step, variables);
        const aliases = (await getInstalled(installed.id))?.definition.aliases || definition.aliases;
        const alias = query ? findAlias(aliases, index, query) : null;
        let applied = null;
        let reason = "";
        if (alias) {
          const strat = aliasToStrategy(alias);
          const res = await sendAction(tabId, { op: "act", typ: step.type, strategy: { type: strat.type, value: strat.value, metadata: strat.metadata }, value: step.value, selected: step.selectedText, key: step.key });
          if (res.ok) {
            await afterAction(tabId);
            applied = { id: alias.chosen_id || "alias", text: alias.chosen_text, selector: alias.cssSelector, role: alias.role };
            reason = "alias";
          }
        }
        if (!applied && query) {
          const candidates = await collect(tabId, step);
          const decision = scoreCandidates(query, candidates, { threshold: fuzzy.threshold, margin: fuzzy.margin });
          if (decision.accepted && decision.winner) {
            const res = await sendAction(tabId, {
              op: "apply",
              typ: step.type,
              selector: decision.winner.selector,
              text: decision.winner.text,
              value: decision.winner.value ?? step.value ?? null
            });
            if (!res.ok) throw new Error(res.error);
            await afterAction(tabId);
            applied = decision.winner;
            reason = "fuzzy";
          } else {
            const mode = definition.hitl?.mode || "always_on_uncertain";
            if (mode !== "llm_only") {
              trace.status = "hitl";
              trace.message = decision.reason;
              currentRun.status = "hitl";
              currentRun.hitl = {
                query,
                reason: decision.reason,
                candidates: decision.ranked.slice(0, fuzzy.top_n)
              };
              emitRun();
              const timeout = definition.hitl?.timeout_s ?? 300;
              const chosen = await waitForHitl(timeout);
              if (!chosen) throw new Error("HITL cancelled");
              const res = await sendAction(tabId, {
                op: "apply",
                typ: step.type,
                selector: chosen.selector,
                text: chosen.text,
                value: chosen.value ?? step.value ?? null
              });
              if (!res.ok) throw new Error(res.error);
              await afterAction(tabId);
              applied = chosen;
              reason = "hitl";
              await persistAlias(installed.id, makeAlias(index, query, chosen));
            } else {
              throw new Error(`fuzzy match failed (${decision.reason}); LLM is not used in the extension`);
            }
          }
        }
        if (applied) {
          const asserted = await sendAction(tabId, { op: "assert", expected: step.expected_state });
          if (!asserted.ok) throw new Error(asserted.error);
          trace.status = "ok";
          trace.message = reason;
          trace.output = { text: applied.text, selector: applied.selector };
          trace.endedAt = Date.now();
          currentRun.status = "running";
          currentRun.hitl = void 0;
          emitRun();
          continue;
        }
      }
      throw new Error(`all selector strategies failed for ${step.type}: ${det.error}`);
    }
    currentRun.status = "ok";
    currentRun.hitl = void 0;
    emitRun();
    return currentRun;
  } catch (err2) {
    const message = err2 instanceof Error ? err2.message : String(err2);
    const last = traces[traces.length - 1];
    if (last && (last.status === "running" || last.status === "hitl")) {
      last.status = "fail";
      last.message = message;
      last.endedAt = Date.now();
    }
    currentRun.status = currentRun.status === "cancel" ? "cancel" : "fail";
    currentRun.error = message;
    currentRun.hitl = void 0;
    emitRun();
    return currentRun;
  }
}
async function targetTab() {
  const tabs = await chrome.tabs.query({});
  const usable = tabs.filter((t2) => {
    if (t2.id == null || !t2.url) return false;
    if (t2.url.startsWith("chrome-extension://") || t2.url.startsWith("chrome://") || t2.url.startsWith("chrome-search://") || t2.url.startsWith("devtools://")) return false;
    return /^https?:|^file:|^about:blank/.test(t2.url);
  });
  usable.sort((a2, b3) => {
    if (a2.active !== b3.active) return a2.active ? -1 : 1;
    return (b3.lastAccessed || 0) - (a2.lastAccessed || 0);
  });
  const http = usable.find((t2) => /^https?:/.test(t2.url || ""));
  const page = http || usable[0];
  if (!page?.id) throw new Error("Open a regular web page tab first, then press Run. The extension plays back in your current tab.");
  return page.id;
}
async function installFromListing(listingId) {
  const listings = await listMarket();
  const listing = listings.find((l2) => l2.id === listingId);
  if (!listing) throw new Error("Listing not found.");
  if (listing.type === "pomerado") {
    throw new Error("Pomerado tool packages are not supported in this extension (workflow-use only).");
  }
  const { bytes, sha256Header } = await downloadPackage(listingId);
  const digest = await sha256Hex(bytes);
  if (listing.sha256 && listing.sha256 !== digest) {
    throw new Error("Package sha256 does not match the listing. Install aborted.");
  }
  if (sha256Header && sha256Header !== digest) {
    throw new Error("Package sha256 does not match the download header. Install aborted.");
  }
  const { definition } = parseWorkflowPackage(new Uint8Array(bytes));
  const existing = (await listInstalled()).find((w2) => w2.listingId === listing.id);
  const item = {
    id: existing?.id || crypto.randomUUID(),
    listingId: listing.id,
    name: listing.name || definition.name,
    description: listing.description || definition.description || "",
    type: listing.type || "workflow-use",
    version: listing.version,
    sha256: digest,
    installedAt: (/* @__PURE__ */ new Date()).toISOString(),
    source: "market",
    definition: { ...definition, aliases: existing?.definition.aliases || definition.aliases || [] }
  };
  await putInstalled(item);
  return item;
}
async function importDefinition(definition, sha256 = "", source = "file") {
  const item = {
    id: crypto.randomUUID(),
    name: definition.name,
    description: definition.description || "",
    type: "workflow-use",
    version: String(definition.version || "1"),
    sha256,
    installedAt: (/* @__PURE__ */ new Date()).toISOString(),
    source,
    definition
  };
  await putInstalled(item);
  return item;
}
var recording = { active: false, events: [], startedAt: 0 };
var recorderInjected = /* @__PURE__ */ new Set();
function emitRecord() {
  broadcast({ kind: "bp-record-state", recording: { active: recording.active, count: recording.events.length } });
}
async function backendRoot() {
  const settings = await loadSettings();
  const url = (settings.backendUrl || DEFAULT_BACKEND_URL).replace(/\/+$/, "");
  const token = settings.marketToken || "";
  if (!url) throw new Error("Set the backend URL in Settings.");
  if (!token) throw new Error("Set the site access token in Settings so the recording can be saved to your library.");
  return { url, token };
}
async function backendFetch(path, init = {}) {
  const { url, token } = await backendRoot();
  const headers = new Headers(init.headers || {});
  headers.set("X-Browser-Platform-Token", token);
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  const response = await fetch(`${url}${path}`, { ...init, headers });
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { error: text.slice(0, 300) };
  }
  if (!response.ok) {
    throw new Error(data.detail || data.error || data.message || `Backend HTTP ${response.status}`);
  }
  return data;
}
function rememberEvent(ev) {
  if (!recording.active || !ev || !ev.type) return;
  recording.events.push(ev);
  emitRecord();
}
function withTimeout(promise, ms, label) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${label} timed out`)), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (err2) => {
        clearTimeout(timer);
        reject(err2);
      }
    );
  });
}
var recordingTabId = null;
async function ensureRecorder(tabId) {
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  const url = tab?.url || "";
  if (!/^https?:/i.test(url)) return;
  if (recorderInjected.has(tabId)) {
    try {
      const ping = await withTimeout(chrome.tabs.sendMessage(tabId, { kind: "bp-record-ping" }), 2e3, "recorder ping");
      if (ping) return;
    } catch {
      recorderInjected.delete(tabId);
    }
  }
  await withTimeout(
    chrome.scripting.executeScript({ target: { tabId }, files: ["recorder.js"] }),
    5e3,
    "inject recorder"
  );
  recorderInjected.add(tabId);
}
async function injectRecordingTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (tab?.id == null || !tab.url || !/^https?:/i.test(tab.url)) {
    recordingTabId = null;
    return;
  }
  recordingTabId = tab.id;
  await ensureRecorder(tab.id).catch(() => void 0);
}
async function drainRecordingTab() {
  const extra = [];
  const tabId = recordingTabId;
  if (tabId == null) return extra;
  try {
    await ensureRecorder(tabId);
    const res = await chrome.tabs.sendMessage(tabId, { kind: "bp-record-drain" });
    for (const ev of res?.events || []) {
      if (ev && typeof ev === "object") {
        const copy = { ...ev };
        if (typeof copy.value === "string" && /(password|passwd|secret)/i.test(String(copy.element?.name || ""))) {
          copy.value = null;
        }
        extra.push(copy);
      }
    }
  } catch {
  }
  return extra;
}
function sortEvents(events) {
  return [...events].sort((a2, b3) => (a2.ts || 0) - (b3.ts || 0));
}
async function startRecording() {
  if (currentRun) {
    throw new Error("A workflow run is already in progress.");
  }
  recording.active = true;
  recording.events = [];
  recording.startedAt = Date.now();
  recorderInjected.clear();
  await injectRecordingTab();
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (tab?.id != null && tab.url && /^https?:/i.test(tab.url)) {
    rememberEvent({ type: "navigation", ts: Date.now(), url: tab.url, changed: true });
  }
  void chrome.action.setBadgeText({ text: "REC" });
  void chrome.action.setBadgeBackgroundColor({ color: "#c62828" });
  emitRecord();
}
async function stopRecording() {
  const drained = await drainRecordingTab();
  for (const ev of drained) rememberEvent(ev);
  recording.active = false;
  recordingTabId = null;
  void chrome.action.setBadgeText({ text: "" });
  emitRecord();
  return sortEvents(recording.events);
}
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (!recording.active) return;
  if (info.status === "loading" && info.url && /^https?:/i.test(info.url)) {
    rememberEvent({ type: "navigation", ts: Date.now(), url: info.url, changed: true });
  }
  if (info.status === "complete" && tab.url && /^https?:/i.test(tab.url)) {
    void ensureRecorder(tabId).catch(() => void 0);
  }
});
chrome.tabs.onActivated.addListener((active) => {
  if (!recording.active) return;
  void chrome.tabs.get(active.tabId).then((tab) => {
    if (tab.url && /^https?:/i.test(tab.url)) {
      rememberEvent({ type: "tab_change", ts: Date.now(), url: tab.url, changed: true });
      void ensureRecorder(active.tabId).catch(() => void 0);
    }
  });
});
chrome.tabs.onRemoved.addListener((tabId) => {
  recorderInjected.delete(tabId);
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || typeof message !== "object" || !("kind" in message)) return;
  const kind = message.kind;
  if (kind === "bp-run") return;
  void (async () => {
    try {
      if (kind === "bp-get-state") {
        sendResponse({ ok: true, settings: await loadSettings(), workflows: await listInstalled(), run: currentRun, recording: { active: recording.active, count: recording.events.length } });
        return;
      }
      if (kind === "bp-save-settings") {
        await saveSettings(message.settings);
        sendResponse({ ok: true, settings: await loadSettings() });
        return;
      }
      if (kind === "bp-list-market") {
        const listings = await listMarket();
        const installed = await listInstalled();
        const byListing = new Map(installed.filter((w2) => w2.listingId).map((w2) => [w2.listingId, w2]));
        sendResponse({
          ok: true,
          listings: listings.map((l2) => {
            const local = byListing.get(l2.id);
            return {
              ...l2,
              installed: Boolean(local),
              installedVersion: local?.version,
              updateAvailable: Boolean(local && local.version !== l2.version)
            };
          })
        });
        return;
      }
      if (kind === "bp-publish") {
        const { id, name, description, type, inputs } = message;
        const installed = await getInstalled(id);
        if (!installed) throw new Error("Workflow is not installed.");
        const definition = installed.definition;
        const title = (name || definition.name).trim();
        const listing = await publishWorkflow({
          id: listingIdForName(title),
          name: title,
          description: description ?? definition.description ?? "",
          type: type || installed.type || "workflow-use",
          inputs: inputs || deriveInputs(definition).map((item) => ({
            name: item.name,
            label: item.label,
            type: item.type,
            required: item.required !== false,
            description: item.description
          })),
          workflow: definition
        });
        await putInstalled({
          ...installed,
          listingId: listing.id,
          name: listing.name,
          description: listing.description || installed.description,
          type: listing.type,
          version: listing.version,
          sha256: listing.sha256,
          source: "market"
        });
        sendResponse({ ok: true, listing, workflow: await getInstalled(installed.id) });
        return;
      }
      if (kind === "bp-install") {
        const item = await installFromListing(message.id);
        sendResponse({ ok: true, workflow: item });
        return;
      }
      if (kind === "bp-import") {
        const definition = parseWorkflowJson(message.json);
        const item = await importDefinition(definition);
        sendResponse({ ok: true, workflow: item });
        return;
      }
      if (kind === "bp-remove") {
        const id = message.id;
        const item = await getInstalled(id);
        await removeInstalled(id);
        if (item?.source === "record") {
          try {
            await backendFetch(`/api/workflows/${encodeURIComponent(id)}`, { method: "DELETE" });
          } catch {
          }
        }
        sendResponse({ ok: true });
        return;
      }
      if (kind === "bp-last-inputs") {
        sendResponse({ ok: true, values: await loadLastInputs(message.id) });
        return;
      }
      if (kind === "bp-confirm-details") {
        const requestId = String(message.id || "");
        const pending = pendingRunConfirms.get(requestId);
        if (!pending) {
          sendResponse({ ok: false, error: "\u05DC\u05D0 \u05E0\u05DE\u05E6\u05D0\u05D4 \u05D1\u05E7\u05E9\u05EA \u05D4\u05E8\u05E6\u05D4, \u05D0\u05D5 \u05E9\u05E4\u05D2 \u05EA\u05D5\u05E7\u05E4\u05D4." });
          return;
        }
        sendResponse({
          ok: true,
          name: pending.payload.name || pending.payload.definition?.name || "\u05D6\u05E8\u05D9\u05DE\u05D4",
          description: pending.payload.definition?.description || "",
          values: pending.payload.values || {}
        });
        return;
      }
      if (kind === "bp-confirm-decision") {
        const requestId = String(message.id || "");
        const accepted = Boolean(message.accepted);
        if (!settleRunConfirm(requestId, accepted)) {
          sendResponse({ ok: false, error: "\u05DC\u05D0 \u05E0\u05DE\u05E6\u05D0\u05D4 \u05D1\u05E7\u05E9\u05EA \u05D4\u05E8\u05E6\u05D4, \u05D0\u05D5 \u05E9\u05DB\u05D1\u05E8 \u05D8\u05D5\u05E4\u05DC\u05D4." });
          return;
        }
        sendResponse({ ok: true, accepted });
        return;
      }
      if (kind === "bp-run-request") {
        const payload = message;
        if (!payload.definition) throw new Error("No workflow definition to run.");
        if (pendingRunConfirms.size) throw new Error("A run confirmation is already open.");
        if (currentRun && (currentRun.status === "running" || currentRun.status === "hitl")) {
          throw new Error("A workflow is already running.");
        }
        const accepted = await confirmRunRequest(payload);
        if (!accepted) {
          sendResponse({ ok: false, cancelled: true, error: "\u05D4\u05D4\u05E8\u05E6\u05D4 \u05D1\u05D5\u05D8\u05DC\u05D4." });
          return;
        }
        const installed = {
          id: payload.id || "adhoc",
          name: payload.name || payload.definition.name || "workflow",
          description: payload.definition.description || "",
          type: "workflow-use",
          version: String(payload.definition.version || "1"),
          sha256: "",
          installedAt: (/* @__PURE__ */ new Date()).toISOString(),
          source: "file",
          definition: payload.definition
        };
        const tabId = payload.tabId || await targetTab();
        const run = await runWorkflow(tabId, installed, payload.values || {});
        sendResponse({ ok: run.status === "ok", confirmed: true, run });
        return;
      }
      if (kind === "bp-run-definition") {
        const payload = message;
        if (!payload.definition) throw new Error("No workflow definition to run.");
        const installed = {
          id: payload.id || "adhoc",
          name: payload.name || payload.definition.name || "workflow",
          description: payload.definition.description || "",
          type: "workflow-use",
          version: String(payload.definition.version || "1"),
          sha256: "",
          installedAt: (/* @__PURE__ */ new Date()).toISOString(),
          source: "file",
          definition: payload.definition
        };
        const tabId = message.tabId || await targetTab();
        const run = await runWorkflow(tabId, installed, payload.values || {});
        sendResponse({ ok: run.status === "ok", run });
        return;
      }
      if (kind === "bp-run-workflow") {
        const { id, values } = message;
        const installed = await getInstalled(id);
        if (!installed) throw new Error("Workflow is not installed.");
        await saveLastInputs(id, values);
        const tabId = message.tabId || await targetTab();
        const run = await runWorkflow(tabId, installed, values);
        sendResponse({ ok: run.status === "ok", run });
        return;
      }
      if (kind === "bp-hitl-choice") {
        const cand = message.candidate ?? null;
        if (hitlWaiter) hitlWaiter.resolve(cand);
        sendResponse({ ok: true });
        return;
      }
      if (kind === "bp-cancel") {
        if (currentRun) currentRun.status = "cancel";
        if (hitlWaiter) hitlWaiter.resolve(null);
        sendResponse({ ok: true });
        return;
      }
      if (kind === "bp-web-ping") {
        sendResponse({ ok: true, extension: true, recording: { active: recording.active, count: recording.events.length } });
        return;
      }
      if (kind === "bp-record-event") {
        rememberEvent(message.event);
        sendResponse({ ok: true, count: recording.events.length });
        return;
      }
      if (kind === "bp-record-start") {
        await startRecording();
        sendResponse({ ok: true, count: recording.events.length });
        return;
      }
      if (kind === "bp-record-stop") {
        const events = await stopRecording();
        sendResponse({ ok: true, events, count: events.length });
        return;
      }
      if (kind === "bp-record-state") {
        sendResponse({ ok: true, recording: { active: recording.active, count: recording.events.length } });
        return;
      }
      if (kind === "bp-record-clean") {
        const { events, goal, name, variables } = message;
        const result = await backendFetch("/api/workflows/from-recording", {
          method: "POST",
          body: JSON.stringify({ events, goal: goal || "", name: name || "", variables: variables || {} })
        });
        sendResponse({ ok: true, result });
        return;
      }
      if (kind === "bp-record-save") {
        const payload = message.payload;
        const stored = await backendFetch("/api/workflows/from-recording/save", {
          method: "POST",
          body: JSON.stringify(payload)
        });
        const definition = stored.definition;
        const item = await importDefinition(definition, "", "record");
        if (stored.id && stored.id !== item.id) {
          await removeInstalled(item.id);
          const linked = { ...item, id: String(stored.id), source: "record" };
          await putInstalled(linked);
          sendResponse({ ok: true, workflow: linked, stored });
          return;
        }
        sendResponse({ ok: true, workflow: item, stored });
        return;
      }
      sendResponse({ ok: false, error: "unknown message" });
    } catch (err2) {
      sendResponse({ ok: false, error: err2 instanceof Error ? err2.message : String(err2) });
    }
  })();
  return true;
});
